import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import https from "node:https";
import { Readable } from "node:stream";
export function publicURL(value: string) {
  let u: URL;
  try {
    u = new URL(value);
  } catch {
    throw Error("A public HTTPS source URL is required");
  }
  if (
    u.protocol !== "https:" ||
    u.username ||
    u.password ||
    u.port ||
    isIP(u.hostname) ||
    !/^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(u.hostname) ||
    /localhost|\.local$|\.internal$/i.test(u.hostname)
  )
    throw Error("A public HTTPS source URL is required");
  return u;
}
function blocked(ip: string) {
  if (isIP(ip) === 4) {
    const a = ip.split(".").map(Number);
    return (
      a[0] === 0 ||
      a[0] === 10 ||
      a[0] === 127 ||
      a[0] >= 224 ||
      (a[0] === 169 && a[1] === 254) ||
      (a[0] === 172 && a[1] >= 16 && a[1] <= 31) ||
      (a[0] === 192 && (a[1] === 168 || a[1] === 0)) ||
      (a[0] === 100 && a[1] >= 64 && a[1] <= 127) ||
      (a[0] === 198 && [18, 19].includes(a[1]))
    );
  }
  return (
    ip === "::" || ip === "::1" || /^(fc|fd|fe[89ab]|ff|::ffff:)/i.test(ip)
  );
}
export async function publicFetch(
  value: string | URL,
  timeout = 12000,
  options: {
    method?: string;
    headers?: Record<string, string>;
    body?: string | Uint8Array;
  } = {},
) {
  let u = publicURL(String(value));
  for (let n = 0; n < 4; n++) {
    const addresses = await lookup(u.hostname, { all: true });
    if (!addresses.length || addresses.some((a) => blocked(a.address)))
      throw Error("Private network sources are not allowed");
    const pinned = addresses[0];
    const r = await new Promise<Response>((resolve, reject) => {
      const request = https.request(
        u,
        {
          method: options.method || "GET",
          headers: {
            Accept:
              "application/rss+xml, application/atom+xml, application/xml, text/xml, audio/*, video/*",
            "User-Agent": "NamLens/4.1",
            ...options.headers,
          },
          lookup: ((_host: any, _opts: any, callback: any) =>
            callback(
              null,
              _opts?.all ? [pinned] : pinned.address,
              pinned.family,
            )) as any,
        },
        (incoming) => {
          const headers = new Headers();
          for (const [k, v] of Object.entries(incoming.headers))
            if (v) headers.set(k, Array.isArray(v) ? v.join(", ") : v);
          const response = new Response(
            [204, 205, 304].includes(incoming.statusCode || 0)
              ? null
              : (Readable.toWeb(incoming) as any),
            { status: incoming.statusCode || 502, headers },
          );
          Object.defineProperty(response, "url", { value: u.href });
          resolve(response);
        },
      );
      const timer = setTimeout(
        () => request.destroy(Error("Source request timed out")),
        timeout,
      );
      request.on("close", () => clearTimeout(timer));
      request.on("error", reject);
      if (options.body) request.write(options.body);
      request.end();
    });
    if (
      [301, 302, 303, 307, 308].includes(r.status) &&
      r.headers.get("location")
    ) {
      if (options.method && options.method !== "GET") {
        await r.body?.cancel();
        throw Error("Notification redirects are not allowed");
      }
      u = publicURL(new URL(r.headers.get("location")!, u).href);
      await r.body?.cancel();
      continue;
    }
    return r;
  }
  throw Error("Source redirects too many times");
}
export async function limitedBytes(r: Response, limit: number) {
  if (Number(r.headers.get("content-length") || 0) > limit) {
    await r.body?.cancel();
    throw Error("Download exceeds size limit");
  }
  const reader = r.body?.getReader();
  if (!reader) throw Error("Empty response");
  let size = 0;
  const chunks: Uint8Array[] = [];
  try {
    while (true) {
      const x = await reader.read();
      if (x.done) break;
      size += x.value.length;
      if (size > limit) throw Error("Download exceeds size limit");
      chunks.push(x.value);
    }
  } catch (e) {
    await reader.cancel();
    throw e;
  }
  return Buffer.concat(chunks);
}
