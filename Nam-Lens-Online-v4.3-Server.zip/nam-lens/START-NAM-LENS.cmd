@echo off
setlocal
cd /d "%~dp0"
title Nam Lens
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or is not on PATH.
  echo Install Node.js from https://nodejs.org, reopen this folder, and try again.
  pause
  exit /b 1
)
echo Opening your Nam Lens...
echo No package installation or database commands are needed.
echo.
node.exe launcher.mjs
if errorlevel 1 (
  echo.
  echo Please send the details in data\startup.log if you need help.
  pause
)
endlocal
