import LanguageStudio, { SpeechConnection } from "@/components/language-studio";
import StepFields from "@/components/step-fields";
("use client");
import { useEffect, useRef, useState } from "react";
import {
  Camera,
  Mic,
  Square,
  Upload,
  FileText,
  LoaderCircle,
  Plus,
  Trash2,
  Settings2,
  Check,
  ExternalLink,
  ShieldCheck,
  Radio,
  RefreshCw,
  Activity,
  Flag,
  Users,
  Search,
  Bell,
  ArrowDownToLine,
  Globe2,
  ChartNoAxesCombined,
} from "lucide-react";
import { duplicateGroups, topicTrends } from "@/lib/intelligence";
type Props = {
  page: string;
  data: any[];
  refresh: () => Promise<void>;
  notice: (s: string) => void;
  save: (r: any, close?: boolean) => Promise<any>;
  openStory: (s: any) => void;
  addCaptured: (s: any) => void;
};
async function request(url: string, data?: any) {
  const r = await fetch(
    url,
    data
      ? {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }
      : undefined,
  );
  const j: any = await r.json();
  if (!r.ok) throw Error(j.error || "Request failed");
  return j;
}
const stamp = (d: string) =>
  d
    ? new Date(d).toLocaleString("en-GB", { timeZone: "Africa/Windhoek" })
    : "—";
const terms = (x: string) =>
  (x || "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean);
export default function WorkspaceTools({
  page,
  data,
  refresh,
  notice,
  save,
  openStory,
  addCaptured,
}: Props) {
  const stories = data.filter((x) => x.kind === "story");
  const session = data.find((x) => x.kind === "session");
  const admin = session?.role === "Admin";
  const canEdit = ["Admin", "Analyst", "Reviewer"].includes(session?.role);
  const [busy, setBusy] = useState(false),
    [draft, setDraft] = useState<any>(null),
    [editKind, setEditKind] = useState(""),
    [integrations, setIntegrations] = useState<any[]>([]),
    [jobState, setJobState] = useState<any>(null),
    [text, setText] = useState(""),
    [progress, setProgress] = useState(""),
    [language, setLanguage] = useState("eng"),
    [file, setFile] = useState<File | null>(null),
    [recording, setRecording] = useState(false),
    [recordUrl, setRecordUrl] = useState(""),
    [remoteUrl, setRemoteUrl] = useState(""),
    [notifications, setNotifications] = useState(false);
  const recorder = useRef<MediaRecorder | null>(null),
    media = useRef<MediaStream | null>(null),
    speech = useRef<any>(null),
    chunks = useRef<Blob[]>([]);
  const prefix = useRef("");
  useEffect(() => {
    if (page === "Integrations")
      request("/api/integrations")
        .then(setIntegrations)
        .catch((e) => notice(e.message));
    if (page === "Automation")
      request("/api/jobs")
        .then(setJobState)
        .catch((e) => notice(e.message));
  }, [page]);
  useEffect(
    () => () => {
      recorder.current?.state === "recording" && recorder.current.stop();
      media.current?.getTracks().forEach((t) => t.stop());
      speech.current?.stop();
    },
    [],
  );
  async function act(fn: () => Promise<any>) {
    setBusy(true);
    try {
      return await fn();
    } catch (e) {
      notice((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function edit(kind: string, row?: any) {
    setEditKind(kind);
    setDraft(
      row ||
        (
          {
            entity: {
              name: "",
              type: "Organisation",
              aliases: "",
              description: "",
            },
            campaign: {
              name: "",
              keywords: "",
              start: new Date().toISOString().slice(0, 10),
              end: "",
              target: 10,
              description: "",
            },
            action: {
              title: "",
              institution: "",
              assignee: "",
              due: new Date().toISOString().slice(0, 10),
              status: "Open",
              storyId: "",
              recommendation: "",
              response: "",
              outcome: "",
            },
            member: { email: "", name: "", role: "Analyst", enabled: true },
          } as any
        )[kind],
    );
  }
  async function ocr(input: File) {
    if (input.size > 10485760) {
      notice("Choose a file below 10 MB");
      return;
    }
    setBusy(true);
    setFile(input);
    setText("");
    let worker: any;
    try {
      const { createWorker } = await import("tesseract.js");
      const make = async () => {
        if (!worker)
          worker = await createWorker(language, 1, {
            workerPath: "/ocr/worker.min.js",
            corePath: "/ocr/core",
            langPath: "/ocr/lang",
            logger: (m: any) =>
              setProgress(
                m.status +
                  (m.progress !== undefined
                    ? " " + Math.round(m.progress * 100) + "%"
                    : ""),
              ),
          });
        return worker;
      };
      let result = "";
      if (input.type === "application/pdf") {
        const pdfjs = await import("pdfjs-dist");
        pdfjs.GlobalWorkerOptions.workerSrc = "/pdf/pdf.worker.min.mjs";
        const pdfTask = pdfjs.getDocument({
          data: await input.arrayBuffer(),
          wasmUrl: "/pdf/wasm/",
          cMapUrl: "/pdf/cmaps/",
          cMapPacked: true,
          standardFontDataUrl: "/pdf/standard_fonts/",
        });
        const pdf = await pdfTask.promise;
        if (pdf.numPages > 15)
          throw Error("Please split this PDF into batches of up to 15 pages");
        for (let n = 1; n <= pdf.numPages; n++) {
          setProgress("Reading PDF page " + n + " of " + pdf.numPages);
          const p = await pdf.getPage(n);
          const content = await p.getTextContent();
          const extracted = content.items
            .map((i: any) => i.str || "")
            .join(" ");
          if (extracted.trim().length > 50) result += extracted + "\n\n";
          else {
            const viewport = p.getViewport({ scale: 1.7 });
            const canvas = document.createElement("canvas");
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const context = canvas.getContext("2d")!;
            await p.render({ canvas, canvasContext: context, viewport })
              .promise;
            const w = await make();
            const recognised = await w.recognize(canvas);
            result += recognised.data.text + "\n\n";
            canvas.width = 0;
            canvas.height = 0;
          }
        }
        await pdfTask.destroy();
      } else {
        const w = await make();
        const resultData = await w.recognize(input);
        result = resultData.data.text;
      }
      setText(result.trim());
      setProgress("Text extracted. Correct errors before saving.");
      notice("Extraction complete — review the text before saving");
    } catch (e) {
      setProgress("Extraction failed");
      notice((e as Error).message);
    } finally {
      await worker?.terminate();
      setBusy(false);
    }
  }
  async function transcribe() {
    if (!file) {
      notice("Choose or record audio first");
      return;
    }
    await act(async () => {
      setProgress("Transcribing the recording…");
      const form = new FormData();
      form.append("file", file);
      form.append(
        "language",
        language === "deu" ? "de" : language === "afr" ? "af" : "en",
      );
      const r = await fetch("/api/transcribe", { method: "POST", body: form });
      const j: any = await r.json();
      if (!r.ok) throw Error(j.error);
      setText(j.text);
      setProgress("Transcript ready; review speaker names and wording.");
      notice("Transcript ready");
    });
  }
  async function startRecording() {
    await act(async () => {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      media.current = stream;
      chunks.current = [];
      const rec = new MediaRecorder(stream);
      recorder.current = rec;
      rec.ondataavailable = (e) => {
        if (e.data.size) chunks.current.push(e.data);
      };
      rec.onstop = () => {
        const blob = new Blob(chunks.current, { type: rec.mimeType });
        const f = new File(
          [blob],
          "broadcast-recording." +
            (rec.mimeType.includes("mp4") ? "m4a" : "webm"),
          { type: rec.mimeType.split(";")[0] },
        );
        setFile(f);
        setRecordUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((t) => t.stop());
        setRecording(false);
      };
      rec.start();
      setRecording(true);
      const SR =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition;
      if (SR) {
        const sr = new SR();
        speech.current = sr;
        sr.lang =
          language === "afr" ? "af-ZA" : language === "deu" ? "de-DE" : "en-ZA";
        sr.continuous = true;
        sr.interimResults = true;
        prefix.current = text;
        sr.onresult = (e: any) => {
          let transcript = "";
          for (let i = 0; i < e.results.length; i++)
            transcript += e.results[i][0].transcript + " ";
          setText(prefix.current + (prefix.current ? "\n" : "") + transcript);
        };
        sr.onerror = () =>
          notice(
            "Browser speech recognition unavailable; audio recording continues",
          );
        sr.start();
      } else
        notice(
          "Audio recording started. Connect transcription or type the transcript afterwards.",
        );
    });
  }
  function stopRecording() {
    recorder.current?.stop();
    speech.current?.stop();
    media.current?.getTracks().forEach((t) => t.stop());
    setRecording(false);
  }
  async function useCapture() {
    if (!text.trim()) {
      notice("Enter or extract story text first");
      return;
    }
    await act(async () => {
      let evidence: any = null;
      if (file) {
        const form = new FormData();
        form.append("file", file);
        const r = await fetch("/api/evidence", { method: "POST", body: form });
        const j: any = await r.json();
        if (!r.ok) throw Error(j.error);
        evidence = j;
      }
      addCaptured({
        title: file?.name.replace(/\.[^.]+$/, "") || "New captured stories",
        body: text,
        evidence,
        language:
          language === "afr"
            ? "Afrikaans"
            : language === "deu"
              ? "German"
              : "English",
        channel: file?.type.startsWith("video")
          ? "Television"
          : file?.type.startsWith("audio")
            ? "Radio"
            : "Print",
      });
    });
  }
  const editor = draft && (
    <section className="panel tool-editor">
      <div className="panel-heading">
        <h3>
          {draft.id ? "Edit" : "Create"}{" "}
          {
            {
              entity: "person or organisation",
              campaign: "campaign",
              member: "team account",
              action: "follow-up action",
            }[editKind]
          }
        </h3>
        <button className="text-button" onClick={() => setDraft(null)}>
          Cancel
        </button>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          act(async () => {
            if (
              await save(
                {
                  ...draft,
                  id: draft.id || crypto.randomUUID(),
                  kind: editKind,
                },
                false,
              )
            )
              setDraft(null);
          });
        }}
      >
        <StepFields
          names={["The basics", "More details", "Review & finish"]}
          size={5}
        >
          {editKind === "entity" && (
            <>
              <label>
                Name
                <input
                  aria-label="Name"
                  required
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </label>
              <label>
                Person or organisation type
                <select
                  aria-label="Person or organisation type"
                  value={draft.type}
                  onChange={(e) => setDraft({ ...draft, type: e.target.value })}
                >
                  {[
                    "Organisation",
                    "Institution",
                    "Person",
                    "Campaign",
                    "Public service",
                  ].map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <label className="full">
                Aliases, separated by commas
                <input
                  aria-label="Aliases, separated by commas"
                  value={draft.aliases}
                  onChange={(e) =>
                    setDraft({ ...draft, aliases: e.target.value })
                  }
                />
              </label>
              <label className="full">
                Description
                <textarea
                  aria-label="Description"
                  value={draft.description}
                  onChange={(e) =>
                    setDraft({ ...draft, description: e.target.value })
                  }
                />
              </label>
            </>
          )}
          {editKind === "campaign" && (
            <>
              <label>
                Campaign / initiative name
                <input
                  aria-label="Campaign / initiative name"
                  required
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </label>
              <label>
                Target media mentions
                <input
                  aria-label="Target media mentions"
                  required
                  type="number"
                  min="1"
                  value={draft.target}
                  onChange={(e) =>
                    setDraft({ ...draft, target: Number(e.target.value) })
                  }
                />
              </label>
              <label>
                Start date
                <input
                  aria-label="Start date"
                  required
                  type="date"
                  value={draft.start}
                  onChange={(e) =>
                    setDraft({ ...draft, start: e.target.value })
                  }
                />
              </label>
              <label>
                End date (optional)
                <input
                  aria-label="End date (optional)"
                  type="date"
                  min={draft.start}
                  value={draft.end}
                  onChange={(e) => setDraft({ ...draft, end: e.target.value })}
                />
              </label>
              <label className="full">
                Keywords, separated by commas
                <input
                  aria-label="Keywords, separated by commas"
                  required
                  value={draft.keywords}
                  onChange={(e) =>
                    setDraft({ ...draft, keywords: e.target.value })
                  }
                />
              </label>
              <label className="full">
                Goals and context
                <textarea
                  aria-label="Goals and context"
                  value={draft.description}
                  onChange={(e) =>
                    setDraft({ ...draft, description: e.target.value })
                  }
                />
              </label>
            </>
          )}
          {editKind === "member" && (
            <>
              <label>
                Name
                <input
                  aria-label="Name"
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </label>
              <label>
                Account email
                <input
                  aria-label="Account email"
                  required
                  type="email"
                  value={draft.email}
                  onChange={(e) =>
                    setDraft({ ...draft, email: e.target.value })
                  }
                />
              </label>
              <label>
                Password
                <input
                  aria-label="Password"
                  type="password"
                  minLength={8}
                  maxLength={200}
                  autoComplete="new-password"
                  required={!draft.id}
                  placeholder={
                    draft.id
                      ? "Leave blank to keep password"
                      : "At least 8 characters"
                  }
                  value={draft.password || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, password: e.target.value })
                  }
                />
              </label>
              <label>
                Workspace role
                <select
                  aria-label="Workspace role"
                  value={draft.role}
                  onChange={(e) => setDraft({ ...draft, role: e.target.value })}
                >
                  {["Viewer", "Analyst", "Reviewer", "Admin"].map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={draft.enabled}
                  onChange={(e) =>
                    setDraft({ ...draft, enabled: e.target.checked })
                  }
                />{" "}
                Allow workspace access
              </label>
            </>
          )}
          {editKind === "action" && (
            <>
              <label className="full">
                Follow-up action title
                <input
                  aria-label="Follow-up action title"
                  required
                  value={draft.title}
                  onChange={(e) =>
                    setDraft({ ...draft, title: e.target.value })
                  }
                />
              </label>
              <label>
                Responsible institution
                <input
                  aria-label="Responsible institution"
                  value={draft.institution}
                  onChange={(e) =>
                    setDraft({ ...draft, institution: e.target.value })
                  }
                />
              </label>
              <label>
                Assigned analyst / team
                <input
                  aria-label="Assigned analyst / team"
                  value={draft.assignee}
                  onChange={(e) =>
                    setDraft({ ...draft, assignee: e.target.value })
                  }
                />
              </label>
              <label>
                Due date
                <input
                  aria-label="Due date"
                  type="date"
                  value={draft.due}
                  onChange={(e) => setDraft({ ...draft, due: e.target.value })}
                />
              </label>
              <label>
                Status
                <select
                  aria-label="Status"
                  value={draft.status}
                  onChange={(e) =>
                    setDraft({ ...draft, status: e.target.value })
                  }
                >
                  {[
                    "Open",
                    "In progress",
                    "Awaiting response",
                    "Completed",
                  ].map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <label className="full">
                Related story
                <select
                  aria-label="Related story"
                  value={draft.storyId || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, storyId: e.target.value })
                  }
                >
                  <option value="">No linked story</option>
                  {stories.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </label>
              {["recommendation", "response", "outcome"].map((k) => (
                <label className="full" key={k}>
                  {k[0].toUpperCase() + k.slice(1)}
                  <textarea
                    value={draft[k] || ""}
                    onChange={(e) =>
                      setDraft({ ...draft, [k]: e.target.value })
                    }
                  />
                </label>
              ))}
            </>
          )}
        </StepFields>
        <div className="modal-actions">
          {draft.id && (
            <button
              type="button"
              className="danger-button"
              disabled={busy}
              onClick={() => {
                if (window.confirm("Delete this " + editKind + "?"))
                  act(async () => {
                    if (
                      await save(
                        { id: draft.id, kind: editKind, action: "delete" },
                        false,
                      )
                    )
                      setDraft(null);
                  });
              }}
            >
              <Trash2 size={14} /> Delete
            </button>
          )}
          <button className="primary" disabled={busy}>
            {busy ? (
              <LoaderCircle className="spin" size={15} />
            ) : (
              <Check size={15} />
            )}{" "}
            Save details
          </button>
        </div>
      </form>
    </section>
  );
  return (
    <div className="tools-page">
      {page === "Capture studio" && (
        <>
          <div className="insight-banner">
            <Camera />
            <div>
              <h3>Listen to Namibia’s many voices.</h3>
              <p>
                Bring a recording or a document. Check the extracted words
                before saving a story.
              </p>
            </div>
          </div>
          <div className="two-col">
            <section className="panel capture-panel">
              <h3>Print & document extraction</h3>
              <label className="capture-label">
                Extraction language
                <select
                  aria-label="Extraction language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  <option value="eng">English</option>
                  <option value="afr">Afrikaans</option>
                  <option value="deu">German</option>
                </select>
              </label>
              <label className="upload-zone">
                <Camera size={30} />
                <strong>Select a newspaper scan or PDF</strong>
                <span>JPG, PNG, WebP, PDF · 10 MB · up to 15 PDF pages</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp,application/pdf"
                  disabled={busy || !canEdit}
                  onChange={(e) =>
                    e.target.files?.[0] && ocr(e.target.files[0])
                  }
                />
              </label>
            </section>
            <LanguageStudio
              notice={notice}
              addCaptured={addCaptured}
              canEdit={canEdit}
            />
          </div>
          <section className="panel capture-panel section-gap">
            <div className="capture-toolbar">
              <h3>Text from your document</h3>
              <span>{progress}</span>
            </div>
            <textarea
              className="extraction-output"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Extracted text will appear here. You can also paste a transcript."
              rows={12}
            />
            <div className="section-toolbar">
              <span>
                {file?.name || "No file attached"} · {text.length} characters
              </span>
              <button
                className="primary"
                disabled={busy || recording || !canEdit}
                onClick={useCapture}
              >
                <Plus size={16} /> Review as a story
              </button>
            </div>
          </section>
        </>
      )}
      {page === "Entities" && (
        <>
          <div className="section-toolbar">
            <span>
              Track organisations, institutions and people across stories.
            </span>
            {canEdit && (
              <button className="primary" onClick={() => edit("entity")}>
                <Plus size={16} /> Add person or organisation
              </button>
            )}
          </div>
          {editor}
          <div className="sources-grid">
            {data
              .filter((x) => x.kind === "entity")
              .map((e) => {
                const aliases = terms(e.name + "," + (e.aliases || ""));
                const matches = stories.filter((s) =>
                  aliases.some((t) =>
                    (s.title + " " + s.body).toLowerCase().includes(t),
                  ),
                );
                return (
                  <section className="panel entity-card" key={e.id}>
                    <div className="source-top">
                      <div className="channel-box online">
                        <Users size={20} />
                      </div>
                      <span className="badge neutral">{e.type}</span>
                    </div>
                    <h3>{e.name}</h3>
                    <p>{e.description}</p>
                    <div className="entity-count">
                      <b>{matches.length}</b>
                      <span>matching stories</span>
                    </div>
                    <div className="keyword-tags">
                      {terms(e.aliases).map((t) => (
                        <span key={t}>{t}</span>
                      ))}
                    </div>
                    {matches.slice(0, 3).map((s) => (
                      <button
                        className="entity-story"
                        key={s.id}
                        onClick={() => openStory(s)}
                      >
                        {s.title}
                      </button>
                    ))}
                    {canEdit && (
                      <button
                        className="button"
                        onClick={() => edit("entity", e)}
                      >
                        Edit details
                      </button>
                    )}
                  </section>
                );
              })}
          </div>
          {!data.some((x) => x.kind === "entity") && (
            <section className="panel empty">
              <Users size={30} />
              <h3>Add the people and organisations you need to follow.</h3>
              <p>
                Entity matches use names and aliases, with manual correction
                available in each story.
              </p>
            </section>
          )}
        </>
      )}
      {page === "Campaigns" && (
        <>
          <div className="section-toolbar">
            <span>Measure recorded media stories against campaign goals.</span>
            {canEdit && (
              <button className="primary" onClick={() => edit("campaign")}>
                <Plus size={16} /> Add campaign
              </button>
            )}
          </div>
          {editor}
          <div className="two-col">
            {data
              .filter((x) => x.kind === "campaign")
              .map((c) => {
                const match = stories.filter(
                  (s) =>
                    !s.sample &&
                    terms(c.keywords).some((t) =>
                      (s.title + " " + s.body).toLowerCase().includes(t),
                    ) &&
                    new Date(s.date).toLocaleDateString("en-CA", {
                      timeZone: "Africa/Windhoek",
                    }) >= c.start &&
                    (!c.end ||
                      new Date(s.date).toLocaleDateString("en-CA", {
                        timeZone: "Africa/Windhoek",
                      }) <= c.end),
                );
                const positive = match.filter(
                  (s) => s.sentiment === "Positive",
                ).length;
                return (
                  <section className="panel campaign-card" key={c.id}>
                    <div className="panel-heading">
                      <div>
                        <h3>{c.name}</h3>
                        <p>
                          {c.start} → {c.end || "Ongoing"}
                        </p>
                      </div>
                      {canEdit && (
                        <button
                          className="text-button"
                          onClick={() => edit("campaign", c)}
                        >
                          Edit
                        </button>
                      )}
                    </div>
                    <p>{c.description}</p>
                    <div className="campaign-stats">
                      <div>
                        <b>{match.length}</b>
                        <span>Recorded mentions</span>
                      </div>
                      <div>
                        <b>
                          {match.length
                            ? Math.round((positive / match.length) * 100)
                            : 0}
                          %
                        </b>
                        <span>Positive stories</span>
                      </div>
                      <div>
                        <b>{new Set(match.map((s) => s.source)).size}</b>
                        <span>Sources</span>
                      </div>
                    </div>
                    <div className="campaign-goal">
                      <span>
                        Stories goal: {match.length} / {c.target}
                      </span>
                      <div className="bar-track">
                        <i
                          style={{
                            width:
                              Math.min(
                                100,
                                (match.length / Math.max(1, c.target)) * 100,
                              ) + "%",
                          }}
                        />
                      </div>
                    </div>
                    <div className="keyword-tags">
                      {terms(c.keywords).map((t) => (
                        <span key={t}>{t}</span>
                      ))}
                    </div>
                    <p className="fine-print">
                      Stories volume measures recorded mentions, not campaign
                      impact or public opinion.
                    </p>
                  </section>
                );
              })}
          </div>
          {!data.some((x) => x.kind === "campaign") && (
            <section className="panel empty">
              <Flag size={30} />
              <h3>Give your initiatives a measurable media view.</h3>
              <p>Add a campaign’s dates, keywords and stories target.</p>
            </section>
          )}
        </>
      )}
      {page === "Follow-up actions" && (
        <>
          <div className="section-toolbar">
            <span>Recommendations, responses and outcomes in one place.</span>
            {canEdit && (
              <button className="primary" onClick={() => edit("action")}>
                <Plus size={16} /> New follow-up
              </button>
            )}
          </div>
          {editor}
          <div className="action-board">
            {["Open", "In progress", "Awaiting response", "Completed"].map(
              (status) => (
                <section className="action-column" key={status}>
                  <h3>
                    {status}
                    <b>
                      {
                        data.filter(
                          (x) => x.kind === "action" && x.status === status,
                        ).length
                      }
                    </b>
                  </h3>
                  {data
                    .filter((x) => x.kind === "action" && x.status === status)
                    .map((a) => (
                      <article className="panel action-card" key={a.id}>
                        <span className="eyebrow">
                          {a.institution || "Institution not assigned"}
                        </span>
                        <h3>{a.title}</h3>
                        <p>
                          {a.recommendation || "No recommendation recorded"}
                        </p>
                        <div className="action-meta">
                          <span>{a.assignee || "Unassigned"}</span>
                          <span
                            className={
                              a.due &&
                              a.due < new Date().toISOString().slice(0, 10) &&
                              status !== "Completed"
                                ? "overdue"
                                : ""
                            }
                          >
                            Due {a.due || "not set"}
                          </span>
                        </div>
                        {a.storyId && (
                          <button
                            className="text-button"
                            onClick={() => {
                              const s = stories.find((s) => s.id === a.storyId);
                              if (s) openStory(s);
                            }}
                          >
                            Open linked stories
                          </button>
                        )}
                        {a.response && (
                          <div className="response-note">
                            <strong>Response</strong>
                            <p>{a.response}</p>
                          </div>
                        )}
                        {a.outcome && (
                          <div className="response-note">
                            <strong>Outcome</strong>
                            <p>{a.outcome}</p>
                          </div>
                        )}
                        {canEdit && (
                          <button
                            className="button"
                            onClick={() => edit("action", a)}
                          >
                            Update action
                          </button>
                        )}
                      </article>
                    ))}
                </section>
              ),
            )}
          </div>
        </>
      )}
      {page === "Trends & duplicates" && (
        <>
          <div className="insight-banner">
            <ChartNoAxesCombined />
            <div>
              <h3>Spot repetition. Notice change.</h3>
              <p>
                Emerging topics compare the latest 24 hours with the prior
                six-day daily average, excluding samples. Duplicate suggestions
                use headline similarity within seven days and require review.
              </p>
            </div>
          </div>
          <section className="panel">
            <div className="panel-heading">
              <h3>Topic acceleration</h3>
              <span>Last 24 hours vs previous baseline</span>
            </div>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Topic</th>
                    <th>24-hour mentions</th>
                    <th>Previous daily average</th>
                    <th>Change</th>
                    <th>Signal</th>
                  </tr>
                </thead>
                <tbody>
                  {topicTrends(stories).map((t) => (
                    <tr key={t.topic}>
                      <td>{t.topic}</td>
                      <td>{t.current}</td>
                      <td>{t.baseline}</td>
                      <td>
                        {t.change === null ? "New topic" : t.change + "%"}
                      </td>
                      <td>
                        <span
                          className={
                            "badge " + (t.emerging ? "negative" : "neutral")
                          }
                        >
                          {t.emerging ? "Emerging" : "Within baseline"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!topicTrends(stories).length && (
              <div className="empty">
                <Activity />
                <p>No recent non-sample stories to compare yet.</p>
              </div>
            )}
          </section>
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Potential duplicate story groups</h3>
              <span>{duplicateGroups(stories).length} groups</span>
            </div>
            {duplicateGroups(stories).map((g) => (
              <div className="duplicate-group" key={g.id}>
                <h3>{g.title}</h3>
                <span>
                  {g.stories.length} records · {g.sources} sources
                </span>
                {g.stories.map((s) => (
                  <button
                    className="entity-story"
                    key={s.id}
                    onClick={() => openStory(s)}
                  >
                    {s.source}: {s.title}
                  </button>
                ))}
              </div>
            ))}
            {!duplicateGroups(stories).length && (
              <div className="empty">
                <Check />
                <p>No duplicate groups detected.</p>
              </div>
            )}
          </section>
        </>
      )}
      {page === "Team & approvals" && (
        <>
          <div className="insight-banner">
            <ShieldCheck />
            <div>
              <h3>Accountable analysis, from capture to approval.</h3>
              <p>
                Your role: {session?.role || "Viewer"}. Approve new accounts,
                assign access and review stories below.
              </p>
            </div>
          </div>
          {admin && (
            <>
              <div className="section-toolbar">
                <span>
                  Each local account has its own password and enforced workspace
                  role.
                </span>
                <button className="primary" onClick={() => edit("member")}>
                  <Plus size={16} /> Add team member
                </button>
              </div>
              {editor}
              <section className="panel">
                <div className="panel-heading">
                  <h3>Membership</h3>
                </div>
                <div className="table-scroll">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Name / email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          {session?.name}
                          <small>{session?.email}</small>
                        </td>
                        <td>{session?.role}</td>
                        <td>Active</td>
                        <td>Current account</td>
                      </tr>
                      {data
                        .filter((x) => x.kind === "member")
                        .map((m) => (
                          <tr key={m.id}>
                            <td>
                              {m.name || m.email}
                              <small>{m.email}</small>
                            </td>
                            <td>{m.role}</td>
                            <td>
                              {m.pending
                                ? "Waiting for approval"
                                : m.enabled
                                  ? "Active"
                                  : "Disabled"}
                            </td>
                            <td>
                              <button
                                className="text-button"
                                onClick={() => edit("member", m)}
                              >
                                Manage access
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </>
          )}
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Story review queue</h3>
              <span>Approval is separate from sentiment classification.</span>
            </div>
            {stories
              .filter((s) => s.approval !== "Approved")
              .map((s) => (
                <div className="review-row" key={s.id}>
                  <button className="story-title" onClick={() => openStory(s)}>
                    {s.title}
                  </button>
                  <span className="badge neutral">{s.approval || "Draft"}</span>
                  <button className="button" onClick={() => openStory(s)}>
                    Review
                  </button>
                </div>
              ))}
          </section>
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Briefing approval queue</h3>
            </div>
            {data
              .filter((x) => x.kind === "report" && x.approval !== "Approved")
              .map((r) => (
                <div className="review-row" key={r.id}>
                  <strong>
                    {r.title} — {r.date}
                  </strong>
                  <span className="badge neutral">{r.approval || "Draft"}</span>
                  {["Admin", "Reviewer"].includes(session?.role) && (
                    <button
                      className="primary"
                      disabled={busy}
                      onClick={() =>
                        act(() => save({ ...r, approval: "Approved" }, false))
                      }
                    >
                      <Check size={15} /> Approve report
                    </button>
                  )}
                </div>
              ))}
          </section>
        </>
      )}
      {page === "Integrations" && (
        <>
          <SpeechConnection notice={notice} admin={admin} />
          <div className="insight-banner">
            <Globe2 />
            <div>
              <h3>Connect only the services you need.</h3>
              <p>
                Secrets are encrypted server-side and never returned to the
                browser. Provider usage may incur charges. Each connection has a
                real test, and failures are reported rather than hidden.
              </p>
            </div>
          </div>
          <div className="two-col">
            {integrations.map((p) => (
              <section className="panel integration-card" key={p.id}>
                <div className="source-top">
                  <h3>{p.name}</h3>
                  <span
                    className={
                      "badge " +
                      (p.health === "Connected"
                        ? "positive"
                        : p.configured
                          ? "neutral"
                          : "unclassified")
                    }
                  >
                    {p.health === "Connected"
                      ? "Connected"
                      : p.configured
                        ? "Ready to test"
                        : "Key required"}
                  </span>
                </div>
                <p>{p.purpose}</p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    act(async () => {
                      await request("/api/integrations", {
                        id: p.id,
                        token: fd.get("token") || "",
                        query: fd.get("query"),
                        pageId: fd.get("pageId"),
                        enabled: fd.get("enabled") === "on",
                      });
                      setIntegrations(await request("/api/integrations"));
                      notice("Connection saved securely");
                    });
                  }}
                >
                  {p.needsKey && (
                    <label className="capture-label">
                      {p.configured
                        ? "Replace connection key (leave blank to keep)"
                        : "Connection key"}
                      <input
                        type="password"
                        name="token"
                        autoComplete="new-password"
                        disabled={!admin}
                        placeholder={
                          p.configured
                            ? "Saved securely"
                            : "Paste your provider key"
                        }
                      />
                    </label>
                  )}
                  {["bluesky", "youtube", "x"].includes(p.id) && (
                    <label className="capture-label">
                      Search keywords
                      <input
                        aria-label="Search keywords"
                        name="query"
                        defaultValue={p.query}
                        disabled={!admin}
                      />
                    </label>
                  )}
                  {p.id === "facebook" && (
                    <label className="capture-label">
                      Numeric Facebook Page ID
                      <input
                        aria-label="Numeric Facebook Page ID"
                        name="pageId"
                        defaultValue={p.pageId}
                        disabled={!admin}
                      />
                    </label>
                  )}
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="enabled"
                      defaultChecked={p.enabled}
                      disabled={!admin}
                    />{" "}
                    Enable{" "}
                    {["deepgram", "huggingface"].includes(p.id)
                      ? "connection"
                      : "background imports"}
                  </label>
                  <div className="record-actions">
                    {admin && (
                      <button className="primary" disabled={busy}>
                        Save connection
                      </button>
                    )}
                    {admin && (
                      <button
                        type="button"
                        className="button"
                        disabled={busy || !p.configured}
                        onClick={() =>
                          act(async () => {
                            await request("/api/integrations", {
                              id: p.id,
                              action: "test",
                            });
                            setIntegrations(await request("/api/integrations"));
                            notice("Connection test passed");
                          })
                        }
                      >
                        <RefreshCw size={14} /> Test connection
                      </button>
                    )}
                  </div>
                </form>
                <p className="fine-print">Last test: {stamp(p.lastTest)}</p>
                {p.lastError && (
                  <div className="connection-error">{p.lastError}</div>
                )}
                {p.id === "huggingface" && (
                  <p className="fine-print">
                    Local lexicons support English, Afrikaans and German. The
                    model is restricted to its eight fine-tuned languages;
                    Oshiwambo, Otjiherero and other local languages require
                    human review.
                  </p>
                )}
              </section>
            ))}
          </div>
        </>
      )}
      {page === "Automation" && (
        <>
          <div className="insight-banner">
            <RefreshCw />
            <div>
              <h3>A monitoring desk that can work while you’re away.</h3>
              <p>
                The updater runs at your selected interval while the local app
                or hosted service is running. It checks enabled feeds and social
                connections, creates priority notifications and maintains
                yesterday’s briefing. Approved snapshots are preserved.
              </p>
            </div>
          </div>
          <div className="two-col">
            <section className="panel capture-panel">
              <h3>Monitoring controls</h3>
              <p>
                Sources need valid feed URLs or an enabled social connection
                before unattended collection can retrieve real content.
              </p>
              <div className="record-actions">
                {admin && (
                  <button
                    className="primary"
                    disabled={busy}
                    onClick={() =>
                      act(async () => {
                        const result = await request("/api/jobs", {
                          action: "run",
                        });
                        notice(
                          result.paused
                            ? "Monitoring is paused"
                            : result.busy
                              ? "Another job is running"
                              : "Monitoring run completed",
                        );
                        setJobState(await request("/api/jobs"));
                        await refresh();
                      })
                    }
                  >
                    {busy ? (
                      <LoaderCircle size={16} className="spin" />
                    ) : (
                      <RefreshCw size={16} />
                    )}{" "}
                    Run monitoring now
                  </button>
                )}
                {admin && (
                  <button
                    className="button"
                    disabled={busy}
                    onClick={() =>
                      act(async () => {
                        await request("/api/jobs", {
                          action: "settings",
                          paused: !jobState?.settings?.paused,
                        });
                        setJobState(await request("/api/jobs"));
                        notice("Monitoring settings updated");
                      })
                    }
                  >
                    {jobState?.settings?.paused
                      ? "Resume monitoring"
                      : "Pause monitoring"}
                  </button>
                )}
              </div>
              <div className="help-note">
                Schedule status:{" "}
                {jobState?.settings?.paused
                  ? "Paused"
                  : "Schedule active while the app or hosting service runs"}
                . Last run:{" "}
                {jobState?.runs?.[0]
                  ? stamp(jobState.runs[0].date)
                  : "No runs recorded yet"}
                .
              </div>
              <p className="fine-print">
                Change the interval in Workspace. In local mode, monitoring
                stops when the computer sleeps or the window closes. Hosting
                keeps it running independently.
              </p>
            </section>
            <section className="panel capture-panel">
              <h3>Notifications</h3>
              <p>
                Priority and emerging-topic notifications are saved while the
                local server is running, even when the browser page is closed.
                Browser pop-up notifications need this page open and your
                permission.
              </p>
              <button
                className="button"
                onClick={() =>
                  act(async () => {
                    if (!("Notification" in window))
                      throw Error(
                        "This browser does not support desktop notifications",
                      );
                    const permission = await Notification.requestPermission();
                    setNotifications(permission === "granted");
                    notice(
                      permission === "granted"
                        ? "Desktop notifications enabled for this browser"
                        : "Desktop notifications were not enabled",
                    );
                  })
                }
              >
                <Bell size={16} />{" "}
                {notifications
                  ? "Browser notifications enabled"
                  : "Enable browser notifications"}
              </button>
              <div className="notification-list">
                {data
                  .filter((x) => x.kind === "notification")
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .slice(0, 10)
                  .map((n) => (
                    <button
                      key={n.id}
                      onClick={() => {
                        const s = stories.find((s) => s.id === n.storyId);
                        if (s) openStory(s);
                      }}
                    >
                      <span>{n.type}</span>
                      <strong>{n.title}</strong>
                      <small>{stamp(n.date)}</small>
                    </button>
                  ))}
                {!data.some((x) => x.kind === "notification") && (
                  <p>No priority notifications yet.</p>
                )}
              </div>
            </section>
          </div>
          <section className="panel section-gap">
            <div className="panel-heading">
              <h3>Job history and collection errors</h3>
            </div>
            {jobState?.runs?.map((j: any) => (
              <div className="job-run" key={j.id}>
                <div>
                  <strong>{stamp(j.date)}</strong>
                  <span
                    className={"badge " + (j.success ? "positive" : "negative")}
                  >
                    {j.success ? "Completed" : "Some sources failed"}
                  </span>
                </div>
                <p>
                  {j.configuredSources} configured feeds · {j.notifications} new
                  notifications · Briefing {j.reportDate}: {j.reportCount}{" "}
                  stories
                </p>
                {j.results?.map((r: any, i: number) => (
                  <p className={r.error ? "connection-error" : ""} key={i}>
                    {r.source}:{" "}
                    {r.error ||
                      `${r.count} new records${r.attempts ? " · " + r.attempts + " attempt(s)" : ""}`}
                  </p>
                ))}
              </div>
            ))}
          </section>
        </>
      )}
      {page === "Audit trail" && (
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h3>Workspace audit trail</h3>
              <p>
                Append-only records of changes, approvals, exports, collection
                and connection management.
              </p>
            </div>
            <button
              className="button"
              onClick={() => {
                const rows = data.filter((x) => x.kind === "audit");
                const url = URL.createObjectURL(
                  new Blob(
                    [
                      ["Date", "Name", "Access", "Action", "Details"].join(
                        ",",
                      ) +
                        "\n" +
                        rows
                          .map((r) =>
                            [r.date, r.actor, r.role, r.action, r.details]
                              .map(
                                (v) =>
                                  '"' +
                                  String(v || "").replaceAll('"', '""') +
                                  '"',
                              )
                              .join(","),
                          )
                          .join("\n"),
                    ],
                    { type: "text/csv;charset=utf-8" },
                  ),
                );
                const a = document.createElement("a");
                a.href = url;
                a.download = "Nam-Lens-activity.csv";
                a.click();
                setTimeout(() => URL.revokeObjectURL(url), 1000);
              }}
            >
              <ArrowDownToLine size={14} /> Download spreadsheet
            </button>
          </div>
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date (CAT)</th>
                  <th>Actor</th>
                  <th>Role</th>
                  <th>Action</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {data
                  .filter((x) => x.kind === "audit")
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .map((a) => (
                    <tr key={a.id}>
                      <td>{stamp(a.date)}</td>
                      <td>
                        {a.actor}
                        <small>{a.email}</small>
                      </td>
                      <td>{a.role}</td>
                      <td>{a.action}</td>
                      <td>{a.details}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          {!data.some((x) => x.kind === "audit") && (
            <div className="empty">
              <ShieldCheck />
              <p>Changes will appear here as your team works.</p>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
