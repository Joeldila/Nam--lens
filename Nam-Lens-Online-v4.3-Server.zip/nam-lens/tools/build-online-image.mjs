import {spawn,spawnSync} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');process.chdir(root);
const rl=readline.createInterface({input:process.stdin,output:process.stdout});
try {
 const docker=spawnSync('docker',['info'],{stdio:'ignore'});if(docker.status!==0)throw Error('Open Docker Desktop first. If it is not installed, install it from https://www.docker.com/products/docker-desktop/ .');
 const name=(process.argv[2]||await rl.question('Your Docker Hub username (no password): ')).trim().toLowerCase();if(!/^[a-z0-9][a-z0-9_-]{1,38}$/.test(name))throw Error('Enter a valid Docker Hub username.');
 const tag='docker.io/'+name+'/nam-lens:4.3';
 console.log('Building the online image on this computer. Your data folder and passwords are excluded.');
 await new Promise((resolve,reject)=>{const p=spawn('docker',['buildx','build','--platform','linux/amd64','--load','--tag',tag,'.'],{cwd:root,stdio:'inherit'});p.on('error',reject);p.on('exit',c=>c===0?resolve():reject(Error('Image build failed. Review the message above.')))});
 console.log('\nImage built locally: '+tag+'\nNo online upload or hosting charge has been made.');
 console.log('Next: create a PRIVATE nam-lens repository in Docker Hub. Then run docker login and docker push '+tag+'. Use the image address above in Render → New Web Service → Existing Image. Read ONLINE-SETUP.txt for the persistent storage and account settings.');
}catch(e){console.error(e.message);process.exitCode=1}finally{rl.close()}
