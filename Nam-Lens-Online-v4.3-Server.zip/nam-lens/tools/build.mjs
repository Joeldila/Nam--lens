// Optional developer rebuild. The app is already built for normal use.
import * as esbuild from "esbuild";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."),
  source = path.join(root, "source");
const common = {
  bundle: true,
  alias: { "@": source },
  logLevel: "info",
  legalComments: "linked",
};
fs.rmSync(path.join(root, "public/assets"), { recursive: true, force: true });
await esbuild.build({
  ...common,
  entryPoints: [path.join(source, "main.tsx")],
  outdir: path.join(root, "public/assets"),
  entryNames: "main",
  chunkNames: "[name]-[hash]",
  format: "esm",
  platform: "browser",
  splitting: true,
  target: ["chrome109", "edge109", "firefox115", "safari16.4"],
  jsx: "automatic",
  minify: true,
  define: { "process.env.NODE_ENV": '"production"' },
});
await esbuild.build({
  ...common,
  entryPoints: [path.join(source, "server.ts")],
  outfile: path.join(root, "server.mjs"),
  format: "esm",
  platform: "node",
  target: "node22",
});
fs.copyFileSync(
  path.join(source, "app/globals.css"),
  path.join(root, "public/style.css"),
);
fs.copyFileSync(path.join(source,"components/experience.css"),path.join(root,"public/experience.css"));
const deps = path.join(root, "node_modules");
for (const name of ["ocr", "pdf", "fonts"])
  fs.mkdirSync(path.join(root, "public", name), { recursive: true });
fs.copyFileSync(
  path.join(deps, "tesseract.js/dist/worker.min.js"),
  path.join(root, "public/ocr/worker.min.js"),
);
for (const name of fs.readdirSync(path.join(deps, "tesseract.js-core")))
  if (/lstm\.wasm(?:\.js)?$/.test(name))
    fs.copyFileSync(
      path.join(deps, "tesseract.js-core", name),
      path.join(root, "public/ocr/core", name),
    );
for (const lang of ["eng", "afr", "deu"]) {
  const f = path.join(
    deps,
    "@tesseract.js-data",
    lang,
    "4.0.0_best_int",
    lang + ".traineddata.gz",
  );
  if(fs.existsSync(f)) fs.copyFileSync(
    f,
    path.join(root, "public/ocr/lang", lang + ".traineddata.gz"),
  );
}
fs.copyFileSync(
  path.join(deps, "pdfjs-dist/build/pdf.worker.min.mjs"),
  path.join(root, "public/pdf/pdf.worker.min.mjs"),
);
for (const name of ["wasm", "cmaps", "standard_fonts"])
  fs.cpSync(
    path.join(deps, "pdfjs-dist", name),
    path.join(root, "public/pdf", name),
    { recursive: true },
  );
console.log("Rebuilt. Start normally with START-NAMIBIA.cmd.");
