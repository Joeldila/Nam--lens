import StepFields from "@/components/step-fields";
("use client");
import { useEffect, useMemo, useState, useRef } from "react";
import {
  Activity,
  ArrowDownToLine,
  ArrowRight,
  AudioLines,
  Bell,
  Bookmark,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  FileText,
  Globe2,
  LayoutDashboard,
  Menu,
  MoreHorizontal,
  Newspaper,
  Plus,
  Radio,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Signal,
  SlidersHorizontal,
  Sparkles,
  Sun,
  Trash2,
  TrendingUp,
  Tv,
  Upload,
  X,
  ExternalLink,
  MapPin,
  Flag,
  ChartNoAxesCombined,
  CalendarDays,
  LoaderCircle,
} from "lucide-react";
import WorkspaceTools from "@/components/workspace-tools";
import LocalPanel from "@/components/local-panel";
import Operations from "@/components/operations";
import { buildBriefing } from "@/lib/intelligence";
import { reportSections } from "@/lib/exports";
import { analyse, regions, channels, languages } from "@/lib/analysis";
type RecordData = { id: string; kind: string; [key: string]: any };
const nav = [
  ["Overview", LayoutDashboard],
  ["Media feed", Newspaper],
  ["Insights", ChartNoAxesCombined],
  ["Issues & alerts", Bell],
  ["Daily briefings", FileText],
  ["Sources", Globe2],
  ["Watchlists", Bookmark],
  ["Capture studio", Upload],
  ["Broadcast desk", Radio],
  ["Language quality", Globe2],
  ["Service status", Activity],
  ["Trends & duplicates", TrendingUp],
  ["Entities", Globe2],
  ["Campaigns", Flag],
  ["Follow-up actions", ShieldCheck],
  ["Team & approvals", ShieldCheck],
  ["Integrations", Signal],
  ["Automation", RefreshCw],
  ["Audit trail", FileText],
  ["Workspace", Settings2],
] as const;
const pageLabels: Record<string, string> = {
  "Media feed": "News & stories",
  "Daily briefings": "Daily reports",
  "Capture studio": "Language studio",
  "Broadcast desk": "Radio & TV",
  "Language quality": "Language review",
  "Service status": "Connection status",
  Entities: "People & organisations",
  Integrations: "Connections",
  Workspace: "Settings",
};
const labelPage = (name: string) => pageLabels[name] || name;
const channelIcons: any = {
  Print: Newspaper,
  Radio: Radio,
  Television: Tv,
  Online: Globe2,
  Social: AudioLines,
};
const palette: any = {
  Positive: "#218d68",
  Negative: "#d85a62",
  Neutral: "#aeb9c4",
  Unclassified: "#e8ba4e",
};
function Logo() {
  return (
    <img
      className="brand-icon"
      src="/favicon.svg"
      alt="Nam Lens logo"
      width="48"
      height="48"
    />
  );
}
function NamibiaMap() {
  return (
    <svg className="namibia-map" viewBox="0 0 420 290" aria-hidden="true">
      <defs>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M20 0H0V20" fill="none" stroke="#fff" strokeOpacity=".06" />
        </pattern>
      </defs>
      <rect width="420" height="290" fill="url(#grid)" />
      <path
        d="M149 30 219 30 219 51 262 51 275 39 350 35 376 49 331 56 286 56 269 67 228 69 229 253 214 273 198 265 188 242 163 229 150 206 138 186 120 151 109 121 104 91 123 76 131 51Z"
        fill="#2a5671"
        stroke="#60829a"
        strokeWidth="1.5"
      />
      <path
        d="M126 88h97m-105 42h108m-88 49h91m-64 42h64m-53-183 2 189m25-227v217"
        stroke="#83a0b2"
        strokeOpacity=".3"
        fill="none"
      />
      <g fill="#f0c558">
        <circle cx="192" cy="160" r="5" />
        <circle cx="153" cy="167" r="4" />
        <circle cx="168" cy="58" r="4" />
        <circle cx="301" cy="48" r="4" />
        <circle cx="182" cy="231" r="4" />
      </g>
      <circle
        cx="192"
        cy="160"
        r="15"
        fill="none"
        stroke="#f0c558"
        strokeOpacity=".4"
      />
      <g fill="#b8cedb" fontSize="10" fontFamily="sans-serif">
        <text x="203" y="164">
          WINDHOEK
        </text>
        <text x="40" y="171">
          SWAKOPMUND
        </text>
        <text x="119" y="45">
          OSHAKATI
        </text>
        <text x="300" y="29">
          KATIMA MULILO
        </text>
        <text x="194" y="237">
          KEETMANSHOOP
        </text>
      </g>
    </svg>
  );
}
const fmt = (d: string) =>
  new Date(d).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    timeZone: "Africa/Windhoek",
  });
function download(name: string, text: string, type = "text/plain") {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
const csvCell = (v: any) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
function parseCSV(text: string) {
  const rows: string[][] = [];
  let row: string[] = [],
    field = "",
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === "," && !quoted) {
      row.push(field);
      field = "";
    } else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (quoted)
    throw Error("The spreadsheet contains an unclosed quotation mark");
  row.push(field);
  if (row.some(Boolean)) rows.push(row);
  const aliases: Record<string, string> = {
    headline: "title",
    "story text": "body",
    "media channel": "channel",
    "source link": "url",
  };
  const header =
    rows
      .shift()
      ?.map((x) => aliases[x.trim().toLowerCase()] || x.trim().toLowerCase()) ||
    [];
  if (!header.includes("title") || !header.includes("body"))
    throw Error("The spreadsheet needs headline and story text columns");
  return rows.map((r) =>
    Object.fromEntries(header.map((h, i) => [h, r[i] || ""])),
  );
}
export default function Home() {
  const [data, setData] = useState<RecordData[]>([]),
    [page, setPage] = useState("Overview"),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [mobile, setMobile] = useState(false);
  const [pinned, setPinned] = useState(false);
  useEffect(() => {
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMobile(false);
        document.querySelector<HTMLButtonElement>(".mobile-menu")?.focus();
      }
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, []);
  const [query, setQuery] = useState(""),
    [channel, setChannel] = useState("All media"),
    [sentiment, setSentiment] = useState("All sentiment"),
    [region, setRegion] = useState("All regions"),
    [period, setPeriod] = useState("7"),
    [savedOnly, setSavedOnly] = useState(false);
  const [modal, setModal] = useState(""),
    [selected, setSelected] = useState<RecordData | null>(null),
    [draft, setDraft] = useState<any>({}),
    [reportDate, setReportDate] = useState(
      new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Windhoek" }),
    ),
    [feedBusy, setFeedBusy] = useState("");
  const session = data.find((x) => x.kind === "session");
  const knownNotifications = useRef<Set<string> | null>(null);
  const stories = data.filter((x) => x.kind === "story"),
    sources = data.filter((x) => x.kind === "source"),
    rules = data.filter((x) => x.kind === "rule"),
    reports = data.filter((x) => x.kind === "report");
  async function refresh() {
    setError("");
    try {
      const r = await fetch("/api/workspace");
      const j: any = await r.json();
      if (r.status === 401)
        window.dispatchEvent(new Event("nmo-auth-required"));
      if (!r.ok) throw Error(j.error);
      const alertsNow = j.filter((x: any) => x.kind === "notification");
      if (
        knownNotifications.current &&
        typeof Notification !== "undefined" &&
        Notification.permission === "granted"
      ) {
        for (const n of alertsNow)
          if (!knownNotifications.current.has(n.id))
            new Notification("Nam Lens", { body: n.title, tag: n.id });
      }
      knownNotifications.current = new Set(alertsNow.map((x: any) => x.id));
      setData(j);
    } catch (e) {
      setError(String((e as Error).message));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    refresh();
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") refresh();
    }, 60000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(""), 4500);
      return () => clearTimeout(t);
    }
  }, [notice]);
  useEffect(() => {
    const f = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setModal("");
        setSelected(null);
      }
    };
    window.addEventListener("keydown", f);
    return () => window.removeEventListener("keydown", f);
  }, []);
  async function save(record: any, close = true) {
    setBusy(true);
    try {
      const r = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(record),
      });
      const j: any = await r.json();
      if (!r.ok) throw Error(j.error);
      await refresh();
      if (close) {
        setModal("");
        setSelected(null);
      }
      setNotice(
        record.action === "delete"
          ? "Record deleted"
          : "Saved to your workspace",
      );
      return true;
    } catch (e) {
      setNotice((e as Error).message);
      return false;
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    if (!modal) return;
    const previous = document.activeElement as HTMLElement | null;
    const box = document.querySelector(".modal") as HTMLElement | null;
    const focusables = () =>
      Array.from(
        box?.querySelectorAll<HTMLElement>(
          "button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled)",
        ) || [],
      ).filter((el) => el.getClientRects().length > 0);
    focusables()[0]?.focus();
    const trap = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const list = focusables();
      const first = list[0],
        last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last?.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", trap);
    const old = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", trap);
      document.body.style.overflow = old;
      previous?.focus();
    };
  }, [modal]);
  const filtered = useMemo(
    () =>
      stories.filter(
        (s) =>
          (!query ||
            (s.title + " " + s.body + " " + s.source + " " + s.topic)
              .toLowerCase()
              .includes(query.toLowerCase())) &&
          (channel === "All media" || s.channel === channel) &&
          (sentiment === "All sentiment" || s.sentiment === sentiment) &&
          (region === "All regions" || s.region === region) &&
          (!savedOnly || s.saved) &&
          (period === "all" ||
            Date.now() - Date.parse(s.date) <= Number(period) * 86400000),
      ),
    [data, query, channel, sentiment, region, period, savedOnly],
  );
  const topics = Object.entries(
    filtered.reduce((a: any, s) => {
      a[s.topic] = (a[s.topic] || 0) + 1;
      return a;
    }, {}),
  ).sort((a: any, b: any) => b[1] - a[1]) as [string, number][];
  const counts = Object.fromEntries(
    ["Positive", "Negative", "Neutral", "Unclassified"].map((k) => [
      k,
      filtered.filter((s) => s.sentiment === k).length,
    ]),
  );
  const alerts = filtered.filter(
    (s) =>
      (s.risk === "High" ||
        s.risk === "Medium" ||
        s.verification === "Unverified") &&
      s.status !== "Resolved",
  );
  function navigate(p: string) {
    setPage(p);
    setMobile(false);
    requestAnimationFrame(() =>
      document
        .querySelector<HTMLElement>("main h1")
        ?.focus({ preventScroll: true }),
    );
    setQuery("");
    setSavedOnly(false);
  }
  function openStory(s: RecordData) {
    setSelected(s);
    setDraft({ ...s });
    setModal("detail");
  }
  function addStory() {
    setDraft({
      title: "",
      body: "",
      source: sources[0]?.name || "Manual submission",
      channel: "Print",
      region: "National",
      language: "English",
      date: new Date().toISOString(),
      url: "",
      verification: "Not assessed",
      notes: "",
      sample: false,
    });
    setModal("story");
  }
  function exportStories() {
    const cols = [
      "title",
      "body",
      "source",
      "channel",
      "region",
      "language",
      "date",
      "sentiment",
      "risk",
      "topic",
      "verification",
      "reviewed",
      "url",
      "notes",
      "sample",
    ];
    download(
      "namibia-media-export.csv",
      [
        cols.join(","),
        ...filtered.map((s) =>
          cols
            .map((c) =>
              csvCell(String(s[c] ?? "").replace(/^(\s*[=+@-])/, "'$1")),
            )
            .join(","),
        ),
      ].join("\r\n"),
      "text/csv",
    );
    setNotice("Filtered media exported");
  }
  async function importFile(file: File) {
    setBusy(true);
    try {
      if (file.size > 2 * 1024 * 1024)
        throw Error("Import files must be under 2 MB");
      const text = await file.text();
      if (file.name.endsWith(".txt")) {
        setDraft({
          title: file.name.replace(/\.txt$/, ""),
          body: text,
          source: "Manual submission",
          channel: "Radio",
          region: "National",
          language: "English",
          date: new Date().toISOString(),
          verification: "Not assessed",
        });
        setModal("story");
        return;
      }
      const rows = file.name.endsWith(".json")
        ? JSON.parse(text)
        : parseCSV(text);
      if (!Array.isArray(rows) || rows.length > 100)
        throw Error("Import a file with at most 100 stories");
      for (const row of rows) {
        if (!row.title?.trim() || !row.body?.trim())
          throw Error("Every story requires title and body");
      }
      let n = 0;
      for (const row of rows) {
        const lang = languages.includes(row.language)
          ? row.language
          : "English";
        const date = !isNaN(Date.parse(row.date))
          ? new Date(row.date).toISOString()
          : new Date().toISOString();
        const record = {
          id: crypto.randomUUID(),
          kind: "story",
          title: row.title,
          body: row.body,
          source: row.source || "Imported file",
          channel: channels.includes(row.channel) ? row.channel : "Print",
          region: regions.includes(row.region) ? row.region : "National",
          language: lang,
          date,
          url: /^https?:\/\//.test(row.url || "") ? row.url : "",
          ...analyse(row.title + " " + row.body, lang),
          sample: false,
          saved: false,
          verification: "Not assessed",
          status: "Open",
          notes: "",
        };
        const r = await fetch("/api/workspace", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(record),
        });
        if (!r.ok) throw Error("Import stopped after " + n + " records");
        n++;
      }
      await refresh();
      setModal("");
      setNotice(n + " stories imported and analysed");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function syncSource(s: RecordData) {
    setFeedBusy(s.id);
    try {
      const r = await fetch("/api/feeds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: s.id }),
      });
      const j: any = await r.json();
      if (!r.ok) throw Error(j.error);
      await refresh();
      setNotice(j.count + " new stories imported");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setFeedBusy("");
    }
  }
  async function uploadEvidence(file: File) {
    setBusy(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const r = await fetch("/api/evidence", { method: "POST", body: form });
      const j: any = await r.json();
      if (!r.ok) throw Error(j.error);
      setDraft((d: any) => ({ ...d, evidence: j }));
      setNotice("Evidence uploaded. Save the story to attach it.");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function generateReport() {
    const report = buildBriefing(stories, reportDate);
    if (!report.count) {
      setNotice("No stories recorded on this date. Choose another date.");
      return;
    }
    const row = { ...report, id: crypto.randomUUID(), kind: "report" };
    if (await save(row, false)) {
      setSelected(row);
      setModal("report");
    }
  }
  async function pdfReport() {
    if (!selected?.items) {
      setNotice("Regenerate this older report to use table exports");
      return;
    }
    setBusy(true);
    try {
      const { createPDF } = await import("@/lib/exports");
      const font = await fetch("/fonts/DejaVuSans.ttf");
      if (!font.ok) throw Error("PDF font could not be loaded");
      const bytes = await createPDF(selected, await font.arrayBuffer());
      const url = URL.createObjectURL(
        new Blob([new Uint8Array(bytes)], { type: "application/pdf" }),
      );
      const a = document.createElement("a");
      a.href = url;
      a.download = "NamLens-" + selected.date + ".pdf";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNotice("PDF report exported");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const dayCounts = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const key = d.toLocaleDateString("en-CA", { timeZone: "Africa/Windhoek" });
    return {
      label: d.toLocaleDateString("en-GB", {
        weekday: "short",
        timeZone: "Africa/Windhoek",
      }),
      count: filtered.filter(
        (s) =>
          new Date(s.date).toLocaleDateString("en-CA", {
            timeZone: "Africa/Windhoek",
          }) === key,
      ).length,
    };
  });
  const maxDay = Math.max(1, ...dayCounts.map((d) => d.count));
  const points = dayCounts
    .map((d, i) => `${25 + i * 65},${145 - (d.count / maxDay) * 110}`)
    .join(" ");
  const sampleCount = stories.filter((s) => s.sample).length;
  function renderList(rows: RecordData[], compact = false) {
    return (
      <div className={"story-list " + (compact ? "compact" : "")}>
        {!rows.length ? (
          <div className="empty">
            <Search size={28} />
            <h3>No stories here yet</h3>
            <p>Add a story, import a transcript or adjust your filters.</p>
            <button
              className="primary"
              disabled={session?.role === "Viewer"}
              onClick={addStory}
            >
              <Plus size={16} /> Add a story
            </button>
          </div>
        ) : (
          rows.map((s) => {
            const Icon = channelIcons[s.channel] || Newspaper;
            return (
              <article className="story" key={s.id}>
                <div className={"channel-box " + s.channel.toLowerCase()}>
                  <Icon size={19} />
                </div>
                <div className="story-content">
                  <div className="story-meta">
                    <span>{s.source}</span>
                    <span>·</span>
                    <span>{s.channel}</span>
                    <span>·</span>
                    <span>{fmt(s.date)}</span>
                    {s.sample && <span className="sample-tag">SAMPLE</span>}
                  </div>
                  <button className="story-title" onClick={() => openStory(s)}>
                    {s.title}
                  </button>
                  {!compact && (
                    <p>
                      {(s.summary || s.body).slice(0, 200)}
                      {(s.summary || s.body).length > 200 ? "…" : ""}
                    </p>
                  )}
                  <div className="story-tags">
                    <span>
                      <MapPin size={11} />
                      {s.region}
                    </span>
                    <span>{s.topic}</span>
                    <span className="story-approval">
                      {s.approval || "Draft"}
                    </span>
                    {s.reviewed && (
                      <span className="reviewed">
                        <ShieldCheck size={12} /> Reviewed
                      </span>
                    )}
                    {s.verification === "Unverified" && (
                      <span className="unverified">Verification pending</span>
                    )}
                  </div>
                </div>
                <div className="story-end">
                  <span className={"badge " + s.sentiment.toLowerCase()}>
                    {s.sentiment}
                  </span>
                  <button
                    className={"icon-button " + (s.saved ? "bookmarked" : "")}
                    aria-label={s.saved ? "Unsave story" : "Save story"}
                    onClick={() => save({ ...s, saved: !s.saved }, false)}
                  >
                    <Bookmark
                      size={17}
                      fill={s.saved ? "currentColor" : "none"}
                    />
                  </button>
                </div>
              </article>
            );
          })
        )}
      </div>
    );
  }
  return (
    <div className={"app-shell " + (pinned ? "nav-pinned" : "")}>
      <aside
        id="workspace-navigation"
        aria-label="Workspace navigation"
        className={
          "sidebar " + (mobile ? "open " : "") + (pinned ? "pinned" : "")
        }
      >
        <button
          className="icon-button nav-close"
          aria-label="Close navigation"
          onClick={() => {
            setMobile(false);
            setPinned(false);
            (document.activeElement as HTMLElement)?.blur();
          }}
        >
          <X size={18} />
        </button>
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            navigate("Overview");
          }}
        >
          <Logo />
          <div>
            <strong>
              NAM <span className="lens-word">LENS</span>
            </strong>
            <small>MEDIA INTELLIGENCE</small>
          </div>
        </a>
        <div className="workspace-label">
          <span className="mini-flag">🇳🇦</span> National workspace{" "}
          <ChevronDown size={14} />
        </div>
        <button
          className="menu-pin"
          aria-pressed={pinned}
          onClick={() => {
            setPinned(!pinned);
            setMobile(false);
          }}
        >
          {pinned ? "Unpin menu" : "Keep menu open"}
        </button>
        <div className="nav-caption">YOUR MEDIA DESK</div>
        <nav>
          {nav.map(([name, Icon]) => (
            <button
              key={name}
              className={page === name ? "active" : ""}
              onClick={() => navigate(name)}
            >
              <Icon size={19} />
              <span>{labelPage(name)}</span>
              {name === "Issues & alerts" && alerts.length > 0 && (
                <b>{alerts.length}</b>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="purpose">
            <Signal size={18} />
            <strong>Many voices. One clear view.</strong>
            <p>Understand the stories shaping our nation.</p>
            <div className="flag-line">
              <i />
              <i />
              <i />
              <i />
            </div>
          </div>
          <button
            onClick={() => {
              setModal("help");
            }}
          >
            <CircleHelp size={17} /> How to use Nam Lens
          </button>
          <div className="profile">
            <div className="avatar">NA</div>
            <div>
              <strong>{session?.name || "Namibia analyst"}</strong>
              <span>National workspace</span>
              <small className="role-chip">
                {session?.role || "Connecting…"}
              </small>
            </div>
            <ShieldCheck size={17} />
          </div>
        </div>
      </aside>
      {mobile && <div className="scrim" onClick={() => setMobile(false)} />}
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-button mobile-menu"
              aria-label="Toggle navigation"
              aria-controls="workspace-navigation"
              aria-expanded={mobile || pinned}
              onClick={() => setMobile(!mobile)}
            >
              <Menu size={21} />
            </button>
            <span>Workspace</span>
            <ChevronRight size={13} />
            <strong>{labelPage(page)}</strong>
          </div>
          <div className="top-actions">
            <span className="connection">
              <i />{" "}
              {loading
                ? "Connecting…"
                : error
                  ? "Connection interrupted"
                  : "Workspace connected"}
            </span>
            <span className="top-divider" />
            <button
              className="icon-button notification"
              aria-label="View alerts"
              onClick={() => navigate("Issues & alerts")}
            >
              <Bell size={19} />
              {alerts.length > 0 && <i />}
            </button>
            <button
              className="text-button"
              onClick={async () => {
                await fetch("/api/auth/logout", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: "{}",
                });
                location.assign("/");
              }}
            >
              Log out
            </button>
          </div>
        </header>
        <main>
          <div className="page-heading">
            <div>
              <div className="eyebrow">THE NATIONAL PICTURE</div>
              <h1 tabIndex={-1}>
                {page === "Overview"
                  ? "A clearer view of Namibia."
                  : labelPage(page)}
              </h1>
              <p>
                {
                  (
                    {
                      Overview:
                        "Follow the conversation. Spot the signals. Make informed decisions.",
                      "Media feed":
                        "Every story in one place, across every channel.",
                      Insights: "Explore the patterns behind the headlines.",
                      "Issues & alerts":
                        "Identify concerns early and follow them through to resolution.",
                      "Daily briefings":
                        "Turn daily stories into a useful, shareable briefing.",
                      Sources:
                        "Build a source network that reflects Namibia’s many voices.",
                      Watchlists:
                        "Keep the topics and entities that matter within reach.",
                      Workspace:
                        "Your data, review standards and workspace controls.",
                      "Capture studio":
                        "Listen, transcribe and save stories in their original language.",
                      "Trends & duplicates":
                        "Detect accelerating topics and repeated reporting.",
                      Entities:
                        "Follow organisations, institutions and people.",
                      Campaigns:
                        "Monitor the stories of campaigns and initiatives.",
                      "Follow-up actions":
                        "Move from recommendations to documented outcomes.",
                      "Team & approvals":
                        "Give every review a responsible analyst.",
                      Integrations:
                        "Connect media and analysis services securely.",
                      Automation:
                        "Keep your monitoring desk working in the background.",
                      "Audit trail": "Trace the changes behind every decision.",
                    } as any
                  )[page]
                }
              </p>
            </div>
            <div className="heading-actions">
              <button
                className="button"
                onClick={() => {
                  setPeriod(period === "7" ? "30" : "7");
                }}
              >
                <CalendarDays size={16} />
                {period === "all" ? "All time" : `Last ${period} days`}
                <ChevronDown size={14} />
              </button>
              <button
                className="primary"
                disabled={session?.role === "Viewer"}
                onClick={addStory}
              >
                <Plus size={16} /> Add a story
              </button>
            </div>
          </div>
          {error && (
            <div className="error-banner">
              {error}
              {error.includes("Sign in") && (
                <button
                  onClick={() =>
                    window.dispatchEvent(new Event("nmo-auth-required"))
                  }
                >
                  Sign in
                </button>
              )}
              <button onClick={refresh}>Retry</button>
            </div>
          )}
          {loading ? (
            <div className="empty">
              <LoaderCircle className="spin" />
              <h3>Opening your national workspace…</h3>
            </div>
          ) : (
            <>
              {sampleCount > 0 && (
                <div className="demo-strip">
                  <Sparkles size={15} />
                  <span>
                    <strong>Explore the sample workspace.</strong> {sampleCount}{" "}
                    fictional stories demonstrate the workflow; they are not
                    actual news.
                  </span>
                  <button onClick={() => navigate("Workspace")}>
                    Manage samples <ArrowRight size={13} />
                  </button>
                </div>
              )}
              {page === "Overview" && (
                <>
                  <section className="hero">
                    <div className="hero-copy">
                      <div className="hero-label">
                        <span /> NAMIBIA, IN FOCUS
                      </div>
                      <h2>
                        Listen wider.
                        <br />
                        See the bigger picture.
                      </h2>
                      <p>
                        From community radio to national headlines,
                        <br className="desktop-break" /> bring every perspective
                        into focus.
                      </p>
                      <button onClick={() => navigate("Media feed")}>
                        Explore news & stories <ArrowRight size={16} />
                      </button>
                    </div>
                    <div className="hero-map">
                      <NamibiaMap />
                      <div className="map-caption">
                        <span className="gold-dot" /> 14 regions. A connected
                        perspective.
                      </div>
                    </div>
                    <div className="hero-date">
                      <Sun size={17} />
                      {new Date().toLocaleDateString("en-GB", {
                        day: "numeric",
                        month: "long",
                        year: "numeric",
                        timeZone: "Africa/Windhoek",
                      })}
                    </div>
                  </section>
                  <div className="stat-grid">
                    {[
                      [
                        Newspaper,
                        "Stories monitored",
                        filtered.length,
                        "Across " +
                          new Set(filtered.map((s) => s.channel)).size +
                          " media channels",
                        "blue",
                      ],
                      [
                        Globe2,
                        "Sources represented",
                        new Set(filtered.map((s) => s.source)).size,
                        sources.filter((s) => s.enabled).length +
                          " sources in your directory",
                        "green",
                      ],
                      [
                        ShieldCheck,
                        "Positive stories",
                        filtered.length
                          ? Math.round(
                              (counts.Positive / filtered.length) * 100,
                            ) + "%"
                          : "0%",
                        "Of the selected stories",
                        "gold",
                      ],
                      [
                        Bell,
                        "Issues to review",
                        alerts.length,
                        alerts.filter((s) => s.risk === "High").length +
                          " high-priority signals",
                        "red",
                      ],
                    ].map(([Icon, label, value, foot, color]: any) => (
                      <section className="stat-card" key={label}>
                        <div>
                          <span>{label}</span>
                          <div className={"stat-icon " + color}>
                            <Icon size={18} />
                          </div>
                        </div>
                        <strong>{value}</strong>
                        <p>{foot}</p>
                      </section>
                    ))}
                  </div>
                  <div className="overview-grid">
                    <section className="panel coverage-panel">
                      <div className="panel-heading">
                        <div>
                          <h3>Story activity</h3>
                          <p>Stories recorded over the last 7 days</p>
                        </div>
                        <span className="legend">
                          <i /> Media mentions
                        </span>
                      </div>
                      <svg
                        className="pulse"
                        viewBox="0 0 445 182"
                        role="img"
                        aria-label="Story counts over the last seven days"
                      >
                        <defs>
                          <linearGradient id="area" x1="0" y1="0" x2="0" y2="1">
                            <stop
                              offset="0%"
                              stopColor="#318b82"
                              stopOpacity=".18"
                            />
                            <stop
                              offset="100%"
                              stopColor="#318b82"
                              stopOpacity="0"
                            />
                          </linearGradient>
                        </defs>
                        {[35, 90, 145].map((y, i) => (
                          <g key={y}>
                            <path
                              d={`M25 ${y}H430`}
                              stroke="#e9edf0"
                              strokeDasharray="4 4"
                            />
                            <text x="0" y={y + 4} fontSize="10" fill="#8896a4">
                              {Math.round(maxDay * (1 - i / 2))}
                            </text>
                          </g>
                        ))}
                        <polygon
                          points={`25,145 ${points} 415,145`}
                          fill="url(#area)"
                        />
                        <polyline
                          points={points}
                          fill="none"
                          stroke="#258578"
                          strokeWidth="2.5"
                          strokeLinejoin="round"
                        />
                        {dayCounts.map((d, i) => (
                          <g key={i}>
                            <circle
                              cx={25 + i * 65}
                              cy={145 - (d.count / maxDay) * 110}
                              r="3.5"
                              fill="#258578"
                            >
                              <title>
                                {d.label}: {d.count} stories
                              </title>
                            </circle>
                            <text
                              x={25 + i * 65}
                              y="174"
                              textAnchor="middle"
                              fontSize="11"
                              fill="#8a96a4"
                            >
                              {d.label}
                            </text>
                          </g>
                        ))}
                      </svg>
                    </section>
                    <section className="panel sentiment-panel">
                      <div className="panel-heading">
                        <div>
                          <h3>Public sentiment</h3>
                          <p>Tone of saved stories</p>
                        </div>
                        <button
                          className="icon-button"
                          aria-label="Sentiment methodology"
                          onClick={() => location.assign("/guide")}
                        >
                          <CircleHelp size={16} />
                        </button>
                      </div>
                      <div className="sentiment-body">
                        <svg
                          viewBox="0 0 150 150"
                          className="donut"
                          role="img"
                          aria-label="Sentiment distribution"
                        >
                          <circle
                            cx="75"
                            cy="75"
                            r="57"
                            fill="none"
                            stroke="#ecf0f3"
                            strokeWidth="16"
                          />
                          {(() => {
                            let offset = 0;
                            return Object.entries(counts).map(([k, n]) => {
                              const len =
                                (Number(n) / Math.max(filtered.length, 1)) *
                                358;
                              const out = (
                                <circle
                                  key={k}
                                  cx="75"
                                  cy="75"
                                  r="57"
                                  fill="none"
                                  stroke={palette[k]}
                                  strokeWidth="16"
                                  strokeDasharray={`${len} ${358 - len}`}
                                  strokeDashoffset={-offset}
                                  transform="rotate(-90 75 75)"
                                />
                              );
                              offset += len;
                              return out;
                            });
                          })()}
                          <text
                            x="75"
                            y="75"
                            textAnchor="middle"
                            fontSize="27"
                            fontWeight="700"
                            fill="#17354c"
                          >
                            {filtered.length}
                          </text>
                          <text
                            x="75"
                            y="94"
                            textAnchor="middle"
                            fontSize="10"
                            fill="#8795a4"
                          >
                            TOTAL STORIES
                          </text>
                        </svg>
                        <div className="sentiment-legend">
                          {Object.entries(counts).map(([k, n]) => (
                            <div key={k}>
                              <span>
                                <i style={{ background: palette[k] }} />
                                {k}
                              </span>
                              <b>
                                {filtered.length
                                  ? Math.round(
                                      (Number(n) / filtered.length) * 100,
                                    )
                                  : 0}
                                %
                              </b>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="panel-foot">
                        Stories tone is an indicator, not a public opinion poll.
                      </div>
                    </section>
                    <section className="panel trending-panel">
                      <div className="panel-heading">
                        <div>
                          <h3>Topics in focus</h3>
                          <p>Most mentioned in your selected period</p>
                        </div>
                        <TrendingUp size={18} />
                      </div>
                      <div className="topics-list">
                        {topics.slice(0, 4).map(([topic, count], i) => (
                          <button
                            key={topic}
                            onClick={() => {
                              setPage("Media feed");
                              setQuery(topic);
                            }}
                          >
                            <span className="topic-rank">0{i + 1}</span>
                            <div>
                              <strong>{topic}</strong>
                              <div className="topic-track">
                                <i
                                  style={{
                                    width: `${(count / Math.max(1, topics[0][1])) * 100}%`,
                                  }}
                                />
                              </div>
                            </div>
                            <b>{count}</b>
                          </button>
                        ))}
                        {!topics.length && <p>No topics available yet.</p>}
                      </div>
                      <button
                        className="panel-link"
                        onClick={() => navigate("Insights")}
                      >
                        Explore all insights <ArrowRight size={14} />
                      </button>
                    </section>
                  </div>
                  <div className="bottom-grid">
                    <section className="panel latest-panel">
                      <div className="panel-heading">
                        <div>
                          <h3>Latest stories</h3>
                          <p>What’s being said, across Namibia</p>
                        </div>
                        <button
                          className="text-button"
                          onClick={() => navigate("Media feed")}
                        >
                          View all <ArrowRight size={14} />
                        </button>
                      </div>
                      {renderList(
                        [...filtered]
                          .sort(
                            (a, b) => Date.parse(b.date) - Date.parse(a.date),
                          )
                          .slice(0, 4),
                        true,
                      )}
                    </section>
                    <section className="panel priorities">
                      <div className="panel-heading">
                        <div>
                          <h3>On your radar</h3>
                          <p>Signals that deserve a closer look</p>
                        </div>
                        <span className="count-pill">{alerts.length}</span>
                      </div>
                      {alerts.slice(0, 3).map((s) => (
                        <button
                          className="priority-item"
                          key={s.id}
                          onClick={() => openStory(s)}
                        >
                          <span
                            className={"priority-dot " + s.risk.toLowerCase()}
                          />
                          <div>
                            <small>
                              {s.risk.toUpperCase()} PRIORITY · {s.region}
                            </small>
                            <strong>{s.title}</strong>
                            <span>
                              {s.verification === "Unverified"
                                ? "Verification needed"
                                : "Awaiting analyst review"}
                            </span>
                          </div>
                          <ChevronRight size={16} />
                        </button>
                      ))}
                      {!alerts.length && (
                        <div className="empty small-empty">
                          <ShieldCheck />
                          <p>No open priority signals.</p>
                        </div>
                      )}
                      <button
                        className="panel-link"
                        onClick={() => navigate("Issues & alerts")}
                      >
                        Open issue desk <ArrowRight size={14} />
                      </button>
                    </section>
                  </div>
                </>
              )}
              {["Media feed", "Insights", "Issues & alerts"].includes(page) && (
                <div className="filterbar">
                  <div className="searchbox">
                    <Search size={17} />
                    <input
                      aria-label="Search stories"
                      placeholder="Search stories, sources, topics…"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                  </div>
                  <select
                    aria-label="Media channel"
                    value={channel}
                    onChange={(e) => setChannel(e.target.value)}
                  >
                    {["All media", ...channels].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                  <select
                    aria-label="Sentiment"
                    value={sentiment}
                    onChange={(e) => setSentiment(e.target.value)}
                  >
                    {[
                      "All sentiment",
                      "Positive",
                      "Negative",
                      "Neutral",
                      "Unclassified",
                    ].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                  <select
                    aria-label="Region"
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                  >
                    {["All regions", ...regions].map((x) => (
                      <option key={x}>{x}</option>
                    ))}
                  </select>
                  <select
                    aria-label="Period"
                    value={period}
                    onChange={(e) => setPeriod(e.target.value)}
                  >
                    <option value="1">Last 24 hours</option>
                    <option value="7">Last 7 days</option>
                    <option value="30">Last 30 days</option>
                    <option value="all">All time</option>
                  </select>
                  <button
                    className="icon-button"
                    aria-label="Reset filters"
                    onClick={() => {
                      setQuery("");
                      setChannel("All media");
                      setSentiment("All sentiment");
                      setRegion("All regions");
                      setPeriod("7");
                    }}
                  >
                    <RefreshCw size={16} />
                  </button>
                </div>
              )}
              {page === "Media feed" && (
                <section className="panel">
                  <div className="panel-heading">
                    <div className="feed-tabs">
                      <button
                        className={!savedOnly ? "selected" : ""}
                        onClick={() => setSavedOnly(false)}
                      >
                        All stories <b>{stories.length}</b>
                      </button>
                      <button
                        className={savedOnly ? "selected" : ""}
                        onClick={() => setSavedOnly(true)}
                      >
                        Saved stories{" "}
                        <b>{stories.filter((s) => s.saved).length}</b>
                      </button>
                    </div>
                    <div className="inline-actions">
                      <button
                        className="button"
                        onClick={() => setModal("import")}
                      >
                        <Upload size={15} /> Import
                      </button>
                      <button className="button" onClick={exportStories}>
                        <ArrowDownToLine size={15} /> Download spreadsheet
                      </button>
                    </div>
                  </div>
                  <div className="result-count">
                    {filtered.length} matching stories · Click a headline to
                    review its analysis
                  </div>
                  {renderList(
                    [...filtered].sort(
                      (a, b) => Date.parse(b.date) - Date.parse(a.date),
                    ),
                  )}
                </section>
              )}
              {page === "Insights" && (
                <>
                  <div className="insight-banner">
                    <ChartNoAxesCombined />
                    <div>
                      <h3>Evidence before interpretation.</h3>
                      <p>
                        These statistics describe the records in your workspace.
                        They do not measure all media or the views of every
                        Namibian.
                      </p>
                    </div>
                  </div>
                  <div className="two-col">
                    <section className="panel">
                      <div className="panel-heading">
                        <h3>Topic distribution</h3>
                        <span>{filtered.length} stories</span>
                      </div>
                      <div className="bar-list">
                        {topics.map(([topic, n]) => (
                          <div key={topic}>
                            <div>
                              <span>{topic}</span>
                              <b>{n}</b>
                            </div>
                            <div className="bar-track">
                              <i
                                style={{
                                  width:
                                    (n / Math.max(1, filtered.length)) * 100 +
                                    "%",
                                }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h3>Media mix</h3>
                        <Globe2 size={18} />
                      </div>
                      <div className="bar-list">
                        {channels.map((c) => {
                          const n = filtered.filter(
                            (s) => s.channel === c,
                          ).length;
                          const Icon = channelIcons[c];
                          return (
                            <div key={c}>
                              <div>
                                <span>
                                  <Icon size={16} />
                                  {c}
                                </span>
                                <b>{n}</b>
                              </div>
                              <div className="bar-track">
                                <i
                                  style={{
                                    width:
                                      (n / Math.max(1, filtered.length)) * 100 +
                                      "%",
                                    background: "#ccad56",
                                  }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h3>Regional stories</h3>
                        <MapPin size={18} />
                      </div>
                      <div className="region-grid">
                        {regions
                          .filter((r) => r !== "International")
                          .map((r) => (
                            <button
                              key={r}
                              onClick={() => {
                                setPage("Media feed");
                                setRegion(r);
                              }}
                            >
                              <span>{r}</span>
                              <b>
                                {filtered.filter((s) => s.region === r).length}
                              </b>
                            </button>
                          ))}
                      </div>
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h3>Sentiment & review quality</h3>
                        <ShieldCheck size={18} />
                      </div>
                      <div className="bar-list">
                        {Object.entries(counts).map(([k, n]) => (
                          <div key={k}>
                            <div>
                              <span>{k}</span>
                              <b>{n}</b>
                            </div>
                            <div className="bar-track">
                              <i
                                style={{
                                  width:
                                    (Number(n) / Math.max(1, filtered.length)) *
                                      100 +
                                    "%",
                                  background: palette[k],
                                }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="quality-note">
                        {filtered.filter((s) => s.reviewed).length} /{" "}
                        {filtered.length} records reviewed. Review
                        language-specific classifications before use.
                      </div>
                    </section>
                  </div>
                </>
              )}
              {page === "Issues & alerts" && (
                <>
                  <div className="insight-banner alert-explainer">
                    <Flag />
                    <div>
                      <h3>Early signals, with human judgement.</h3>
                      <p>
                        Priority flags reflect keywords and analyst choices.
                        Unverified claims are not automatically misinformation.
                        Open a story to verify evidence, add notes and resolve
                        the issue.
                      </p>
                    </div>
                  </div>
                  <div className="stat-grid three">
                    {["High", "Medium", "Resolved"].map((k) => (
                      <section className="stat-card" key={k}>
                        <span>
                          {k === "Resolved"
                            ? "Resolved issues"
                            : k + " priority"}
                        </span>
                        <strong>
                          {k === "Resolved"
                            ? filtered.filter((s) => s.status === "Resolved")
                                .length
                            : alerts.filter((s) => s.risk === k).length}
                        </strong>
                        <p>
                          {k === "Resolved"
                            ? "Marked resolved by an analyst"
                            : "Open for review"}
                        </p>
                      </section>
                    ))}
                  </div>
                  <section className="panel">
                    <div className="panel-heading">
                      <h3>Open signals</h3>
                      <span>{alerts.length} items</span>
                    </div>
                    {renderList(alerts)}
                  </section>
                  <section className="panel section-gap">
                    <div className="panel-heading">
                      <h3>Resolved issues</h3>
                    </div>
                    {renderList(
                      filtered.filter((s) => s.status === "Resolved"),
                      true,
                    )}
                  </section>
                </>
              )}
              {page === "Sources" && (
                <>
                  <div className="section-toolbar">
                    <span>
                      {sources.length} sources ·{" "}
                      {sources.filter((s) => s.url && s.enabled).length} feed
                      connections configured
                    </span>
                    <button
                      className="primary"
                      onClick={() => {
                        setDraft({
                          name: "",
                          channel: "Online",
                          language: "English",
                          url: "",
                          enabled: true,
                        });
                        setModal("source");
                      }}
                    >
                      <Plus size={16} /> Add source
                    </button>
                  </div>
                  <div className="insight-banner">
                    <Radio />
                    <div>
                      <h3>Every channel has a place.</h3>
                      <p>
                        Connect a public news feed to import the latest stories.
                        Print, radio, TV and social stories can be submitted
                        manually with scans or recordings. Feed imports run when
                        you select Sync or when the local monitoring schedule
                        runs.
                      </p>
                    </div>
                  </div>
                  <div className="sources-grid">
                    {sources.map((s) => {
                      const Icon = channelIcons[s.channel] || Globe2;
                      return (
                        <section className="panel source-card" key={s.id}>
                          <div className="source-top">
                            <div
                              className={
                                "channel-box " + s.channel.toLowerCase()
                              }
                            >
                              <Icon size={21} />
                            </div>
                            <span
                              className={
                                "badge " + (s.enabled ? "positive" : "neutral")
                              }
                            >
                              {s.enabled ? "Enabled" : "Paused"}
                            </span>
                          </div>
                          <h3>{s.name}</h3>
                          <p>
                            {s.channel} · {s.language}
                          </p>
                          <div className="source-status">
                            <span
                              className={"dot " + (s.url ? "green" : "grey")}
                            />
                            {s.url
                              ? "News feed connected"
                              : "Manual collection"}
                          </div>
                          <div className="source-health-detail">
                            Health: {s.health || "Not tested"} · Attempts:{" "}
                            {s.lastAttempts || 0}
                            {s.nextRetry &&
                              " · Retry after " +
                                new Date(s.nextRetry).toLocaleString("en-GB")}
                          </div>
                          {s.lastError && (
                            <div className="source-error-detail">
                              {s.lastError}
                            </div>
                          )}
                          <small>
                            {s.lastSync
                              ? "Last import: " +
                                new Date(s.lastSync).toLocaleString("en-GB")
                              : "No feed import yet"}
                          </small>
                          <div className="source-actions">
                            <button
                              className="button"
                              onClick={() => {
                                setDraft({ ...s });
                                setModal("source");
                              }}
                            >
                              <Settings2 size={14} /> Configure
                            </button>
                            {s.url && s.enabled ? (
                              <button
                                className="text-button"
                                disabled={!!feedBusy}
                                onClick={() => syncSource(s)}
                              >
                                <RefreshCw
                                  size={14}
                                  className={feedBusy === s.id ? "spin" : ""}
                                />
                                {feedBusy === s.id
                                  ? "Importing…"
                                  : "Import latest news"}
                              </button>
                            ) : (
                              <button
                                className="text-button"
                                onClick={() => {
                                  addStory();
                                  setDraft((d: any) => ({
                                    ...d,
                                    source: s.name,
                                    channel: s.channel,
                                    language: s.language,
                                  }));
                                }}
                              >
                                Add a story <Plus size={14} />
                              </button>
                            )}
                          </div>
                        </section>
                      );
                    })}
                  </div>
                </>
              )}
              {page === "Watchlists" && (
                <>
                  <div className="section-toolbar">
                    <span>Track names, organisations, campaigns or issues</span>
                    <button
                      className="primary"
                      onClick={() => {
                        setDraft({ name: "", keywords: "", description: "" });
                        setModal("rule");
                      }}
                    >
                      <Plus size={16} /> New watchlist
                    </button>
                  </div>
                  {!rules.length ? (
                    <section className="panel empty">
                      <Bookmark size={34} />
                      <h3>Keep important conversations close.</h3>
                      <p>
                        Create a watchlist for a topic such as water supply,
                        rural education or youth employment.
                      </p>
                      <button
                        className="primary"
                        onClick={() => {
                          setDraft({
                            name: "Youth opportunities",
                            keywords: "youth, job, skills, training",
                            description:
                              "Stories of skills and employment opportunities",
                          });
                          setModal("rule");
                        }}
                      >
                        Create your first watchlist
                      </button>
                    </section>
                  ) : (
                    rules.map((rule) => {
                      const terms = rule.keywords
                        .split(",")
                        .map((s: string) => s.trim().toLowerCase())
                        .filter(Boolean);
                      const matches = stories.filter((s) =>
                        terms.some((t: string) =>
                          (s.title + " " + s.body).toLowerCase().includes(t),
                        ),
                      );
                      return (
                        <section className="panel section-gap" key={rule.id}>
                          <div className="panel-heading">
                            <div>
                              <h3>{rule.name}</h3>
                              <p>
                                {rule.description} · {matches.length} keyword
                                matches
                              </p>
                            </div>
                            <button
                              className="button"
                              onClick={() => {
                                setDraft({ ...rule });
                                setModal("rule");
                              }}
                            >
                              Edit watchlist
                            </button>
                          </div>
                          <div className="keyword-tags">
                            {terms.map((t: string) => (
                              <span key={t}>{t}</span>
                            ))}
                          </div>
                          {renderList(matches, true)}
                        </section>
                      );
                    })
                  )}
                </>
              )}
              {page === "Daily briefings" && (
                <>
                  <section className="briefing-hero">
                    <div className="briefing-symbol">
                      <FileText size={36} />
                    </div>
                    <div>
                      <div className="eyebrow">FROM COVERAGE TO CLARITY</div>
                      <h2>Your daily intelligence briefing.</h2>
                      <p>
                        Generate a dated digest with key stories, sentiment,
                        priority issues and review notes.
                      </p>
                      <small>
                        Generate on demand or use the background monitoring task
                        for daily snapshots.
                      </small>
                    </div>
                    <div className="report-controls">
                      <label htmlFor="reportdate">
                        Briefing date (Namibia time)
                      </label>
                      <input
                        id="reportdate"
                        type="date"
                        value={reportDate}
                        onChange={(e) => setReportDate(e.target.value)}
                      />
                      <button
                        className="primary"
                        disabled={busy}
                        onClick={generateReport}
                      >
                        <Sparkles size={16} /> Generate briefing
                      </button>
                    </div>
                  </section>
                  <section className="panel">
                    <div className="panel-heading">
                      <h3>Briefing archive</h3>
                      <span>{reports.length} saved reports</span>
                    </div>
                    {reports.length ? (
                      reports
                        .sort((a, b) => b.created.localeCompare(a.created))
                        .map((r) => (
                          <div className="report-row" key={r.id}>
                            <div className="channel-box print">
                              <FileText size={21} />
                            </div>
                            <div>
                              <h3>
                                {r.title} · {fmt(r.date)}
                              </h3>
                              <p>
                                {r.count} stories · {r.samples} illustrative
                                items · Saved {fmt(r.created)}
                              </p>
                            </div>
                            <button
                              className="button"
                              onClick={() => {
                                setSelected(r);
                                setModal("report");
                              }}
                            >
                              Open briefing <ArrowRight size={15} />
                            </button>
                          </div>
                        ))
                    ) : (
                      <div className="empty">
                        <FileText size={30} />
                        <h3>Your first briefing starts here.</h3>
                        <p>
                          Select a date with recorded stories, then generate a
                          briefing.
                        </p>
                      </div>
                    )}
                  </section>
                </>
              )}
              {[
                "Capture studio",
                "Trends & duplicates",
                "Entities",
                "Campaigns",
                "Follow-up actions",
                "Team & approvals",
                "Integrations",
                "Automation",
                "Audit trail",
              ].includes(page) && (
                <WorkspaceTools
                  page={page}
                  data={data}
                  refresh={refresh}
                  notice={setNotice}
                  save={save}
                  openStory={openStory}
                  addCaptured={(capture) => {
                    addStory();
                    setDraft((d: any) => ({ ...d, ...capture }));
                  }}
                />
              )}
              {[
                "Broadcast desk",
                "Language quality",
                "Service status",
              ].includes(page) && (
                <Operations page={page} session={session} notice={setNotice} />
              )}
              {page === "Workspace" && (
                <LocalPanel
                  session={session}
                  notice={setNotice}
                  refresh={refresh}
                />
              )}
              {page === "Workspace" && session?.role === "Admin" && (
                <section className="panel settings-card">
                  <h3>Sample stories</h3>
                  <div className="sample-total">
                    <strong>{sampleCount}</strong>
                    <span>fictional sample stories</span>
                  </div>
                  <button
                    className="danger-button"
                    disabled={!sampleCount}
                    onClick={() => setModal("removeSamples")}
                  >
                    Remove sample stories
                  </button>
                  <button className="button" onClick={() => setModal("import")}>
                    Import stories
                  </button>
                </section>
              )}
            </>
          )}
          <footer>
            <span>
              <Logo /> NAM LENS
            </span>
            <p>Built for Namibia. Informed by every voice.</p>
            <button onClick={() => location.assign("/guide")}>
              User guide <ExternalLink size={12} />
            </button>
          </footer>
        </main>
      </div>
      {notice && (
        <div className="toast" role="status">
          <Check size={18} />
          {notice}
          <button
            aria-label="Dismiss notification"
            onClick={() => setNotice("")}
          >
            <X size={16} />
          </button>
        </div>
      )}
      {modal && (
        <div
          className="modal-backdrop"
          onClick={() => {
            if (!busy) {
              setModal("");
              setSelected(null);
            }
          }}
        >
          <section
            className={
              "modal " +
              (["detail", "report"].includes(modal) ? "wide-modal" : "")
            }
            role="dialog"
            aria-modal="true"
            aria-label={
              modal === "detail" ? "Review story" : "Workspace action"
            }
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-top">
              <span className="eyebrow">NAM LENS</span>
              <button
                className="icon-button"
                disabled={busy}
                aria-label="Close dialog"
                onClick={() => {
                  setModal("");
                  setSelected(null);
                }}
              >
                <X size={21} />
              </button>
            </div>
            {modal === "import" && (
              <>
                <h2>Bring your stories together.</h2>
                <p className="modal-intro">
                  Import up to 100 stories using the spreadsheet template, or
                  choose a text transcript. Maximum 2 MB.
                </p>
                <label className="upload-zone">
                  <Upload size={32} />
                  <strong>
                    {busy ? "Importing…" : "Choose an import file"}
                  </strong>
                  <span>Spreadsheet · Transcript · Saved stories</span>
                  <input
                    type="file"
                    accept=".csv,.json,.txt"
                    disabled={busy}
                    onChange={(e) =>
                      e.target.files?.[0] && importFile(e.target.files[0])
                    }
                  />
                </label>
                <div className="help-note">
                  <strong>Required fields:</strong> Headline and Story text.
                  <br />
                  Optional: Source, Media channel, Region, Language, Date and
                  Source link. Sentiment is freshly analysed and can be reviewed
                  afterwards.
                </div>
                <button
                  className="button"
                  onClick={() =>
                    download(
                      "nmo-import-template.csv",
                      'Headline,Story text,Source,Media channel,Region,Language,Date,Source link\n"Your headline","Article or transcript text","Your source","Print","National","English","' +
                        new Date().toISOString().slice(0, 10) +
                        '",""',
                      "text/csv",
                    )
                  }
                >
                  <ArrowDownToLine size={15} /> Download spreadsheet template
                </button>
              </>
            )}
            {["story", "detail"].includes(modal) && (
              <>
                <h2>
                  {modal === "story"
                    ? "Add a story. Hear another voice."
                    : draft.title}
                </h2>
                {draft.sample && (
                  <div className="help-note">
                    Illustrative sample. This story is fictional.
                  </div>
                )}
                {modal === "detail" && /^https?:\/\//.test(draft.url || "") && (
                  <a
                    className="original-link"
                    href={draft.url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Open original source <ExternalLink size={13} />
                  </a>
                )}
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (busy) return;
                    const auto = analyse(
                      draft.title + " " + draft.body,
                      draft.language,
                    );
                    const date = new Date(draft.date);
                    if (isNaN(date.getTime())) {
                      setNotice("Choose a valid date");
                      return;
                    }
                    await save({
                      ...draft,
                      id: draft.id || crypto.randomUUID(),
                      kind: "story",
                      date: date.toISOString(),
                      ...(modal === "story" ? auto : {}),
                      sample: draft.sample || false,
                      saved: draft.saved || false,
                      status: draft.status || "Open",
                      reviewed: modal === "detail" ? true : false,
                    });
                  }}
                >
                  <StepFields
                    names={
                      modal === "source"
                        ? ["Source details"]
                        : modal === "rule"
                          ? ["Watchlist details"]
                          : [
                              "Story basics",
                              "Text & details",
                              "People & context",
                              "Summary & response",
                              "Review & evidence",
                              "Final checks",
                            ]
                    }
                    size={6}
                  >
                    <label className="full">
                      Headline
                      <input
                        aria-label="Headline"
                        required
                        maxLength={500}
                        value={draft.title || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, title: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Source
                      <input
                        aria-label="Source"
                        required
                        list="source-options"
                        value={draft.source || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, source: e.target.value })
                        }
                      />
                      <datalist id="source-options">
                        {sources.map((s) => (
                          <option key={s.id}>{s.name}</option>
                        ))}
                      </datalist>
                    </label>
                    <label>
                      Media channel
                      <select
                        aria-label="Media channel"
                        value={draft.channel || "Print"}
                        onChange={(e) =>
                          setDraft({ ...draft, channel: e.target.value })
                        }
                      >
                        {channels.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Region
                      <select
                        aria-label="Region"
                        value={draft.region || "National"}
                        onChange={(e) =>
                          setDraft({ ...draft, region: e.target.value })
                        }
                      >
                        {regions.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Language
                      <select
                        aria-label="Language"
                        value={draft.language || "English"}
                        onChange={(e) =>
                          setDraft({ ...draft, language: e.target.value })
                        }
                      >
                        {languages.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Publication date & time (device time)
                      <input
                        aria-label="Publication date &amp; time (device time)"
                        required
                        type="datetime-local"
                        value={
                          draft.date
                            ? new Date(
                                Date.parse(draft.date) -
                                  new Date(draft.date).getTimezoneOffset() *
                                    60000,
                              )
                                .toISOString()
                                .slice(0, 16)
                            : ""
                        }
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            date: e.target.value
                              ? new Date(e.target.value).toISOString()
                              : "",
                          })
                        }
                      />
                    </label>
                    <label>
                      Original source link
                      <input
                        aria-label="Original source link"
                        type="url"
                        placeholder="https://…"
                        value={draft.url || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, url: e.target.value })
                        }
                      />
                    </label>
                    <label className="full">
                      Article text / transcript
                      <textarea
                        aria-label="Article text / transcript"
                        required
                        rows={5}
                        maxLength={60000}
                        value={draft.body || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, body: e.target.value })
                        }
                      />
                    </label>
                    <div className="field-divider">
                      Monitoring report details
                    </div>
                    {draft.channel === "Print" && (
                      <label>
                        Newspaper page number
                        <input
                          aria-label="Newspaper page number"
                          value={draft.pageNumber || ""}
                          placeholder="e.g. 3"
                          onChange={(e) =>
                            setDraft({ ...draft, pageNumber: e.target.value })
                          }
                        />
                      </label>
                    )}
                    {["Radio", "Television"].includes(draft.channel) && (
                      <label>
                        Programme name
                        <input
                          aria-label="Programme name"
                          value={draft.programme || ""}
                          onChange={(e) =>
                            setDraft({ ...draft, programme: e.target.value })
                          }
                        />
                      </label>
                    )}
                    {["Radio", "Television"].includes(draft.channel) && (
                      <label>
                        Presenter / reporter
                        <input
                          aria-label="Presenter / reporter"
                          value={draft.presenter || ""}
                          onChange={(e) =>
                            setDraft({ ...draft, presenter: e.target.value })
                          }
                        />
                      </label>
                    )}
                    {["Radio", "Television"].includes(draft.channel) && (
                      <label>
                        Broadcast time (CAT)
                        <input
                          aria-label="Broadcast time (CAT)"
                          type="time"
                          value={draft.broadcastTime || ""}
                          onChange={(e) =>
                            setDraft({
                              ...draft,
                              broadcastTime: e.target.value,
                            })
                          }
                        />
                      </label>
                    )}
                    <label>
                      Quoted spokesperson / source
                      <input
                        aria-label="Quoted spokesperson / source"
                        value={draft.quotedPerson || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, quotedPerson: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Quoted source role
                      <input
                        aria-label="Quoted source role"
                        value={draft.quotedRole || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, quotedRole: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Statement type
                      <select
                        aria-label="Statement type"
                        value={draft.statementType || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, statementType: e.target.value })
                        }
                      >
                        <option value="">Not recorded</option>
                        {[
                          "Interview",
                          "Media statement",
                          "Report",
                          "Event speech",
                          "Social post",
                          "Other",
                        ].map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Institutions / organisations (comma separated)
                      <input
                        aria-label="Institutions / organisations (comma separated)"
                        value={
                          Array.isArray(draft.institutions)
                            ? draft.institutions.join(", ")
                            : draft.institutions || ""
                        }
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            institutions: e.target.value
                              .split(",")
                              .map((x) => x.trim())
                              .filter(Boolean),
                          })
                        }
                      />
                    </label>
                    <label className="full">
                      Brief summary (generated from text if left blank)
                      <textarea
                        aria-label="Brief summary (generated from text if left blank)"
                        rows={3}
                        value={draft.summary || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, summary: e.target.value })
                        }
                      />
                    </label>
                    <label className="full">
                      Communication recommendation
                      <textarea
                        aria-label="Communication recommendation"
                        rows={3}
                        value={draft.recommendation || ""}
                        placeholder="Recommended response, clarification or follow-up…"
                        onChange={(e) =>
                          setDraft({ ...draft, recommendation: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Approval workflow
                      <select
                        aria-label="Approval workflow"
                        value={draft.approval || "Draft"}
                        onChange={(e) =>
                          setDraft({ ...draft, approval: e.target.value })
                        }
                      >
                        <option>Draft</option>
                        <option>Pending review</option>
                        {["Admin", "Reviewer"].includes(session?.role) && (
                          <option>Approved</option>
                        )}
                        <option>Changes requested</option>
                      </select>
                    </label>
                    <label>
                      People & organisations (matched automatically)
                      <input
                        aria-label="People & organisations (matched automatically)"
                        readOnly
                        value={(draft.entities || []).join(", ")}
                      />
                    </label>
                    {modal === "detail" && (
                      <>
                        <div className="analysis-box full">
                          <div>
                            <Sparkles size={17} />
                            <strong>Analysis review</strong>
                            <button
                              type="button"
                              className="text-button"
                              onClick={() =>
                                setDraft({
                                  ...draft,
                                  ...analyse(
                                    draft.title + " " + draft.body,
                                    draft.language,
                                  ),
                                })
                              }
                            >
                              Reanalyse text
                            </button>
                          </div>
                          <p>{draft.analysisReason}</p>
                          <button
                            type="button"
                            className="button"
                            disabled={busy}
                            onClick={async () => {
                              setBusy(true);
                              try {
                                const r = await fetch("/api/analysis", {
                                  method: "POST",
                                  headers: {
                                    "Content-Type": "application/json",
                                  },
                                  body: JSON.stringify({
                                    text: draft.title + " " + draft.body,
                                    language: draft.language,
                                  }),
                                });
                                const j: any = await r.json();
                                if (!r.ok) throw Error(j.error);
                                setDraft({ ...draft, ...j });
                                setNotice("Model suggestion ready for review");
                              } catch (e) {
                                setNotice((e as Error).message);
                              } finally {
                                setBusy(false);
                              }
                            }}
                          >
                            Analyse with connected model
                          </button>
                        </div>
                        <label>
                          Sentiment
                          <select
                            aria-label="Sentiment"
                            value={draft.sentiment}
                            onChange={(e) =>
                              setDraft({ ...draft, sentiment: e.target.value })
                            }
                          >
                            {[
                              "Positive",
                              "Negative",
                              "Neutral",
                              "Unclassified",
                            ].map((x) => (
                              <option key={x}>{x}</option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Priority
                          <select
                            aria-label="Priority"
                            value={draft.risk}
                            onChange={(e) =>
                              setDraft({ ...draft, risk: e.target.value })
                            }
                          >
                            {["Low", "Medium", "High"].map((x) => (
                              <option key={x}>{x}</option>
                            ))}
                          </select>
                        </label>
                        <label>
                          Topic
                          <input
                            aria-label="Topic"
                            required
                            value={draft.topic || ""}
                            onChange={(e) =>
                              setDraft({ ...draft, topic: e.target.value })
                            }
                          />
                        </label>
                        <label>
                          Issue status
                          <select
                            aria-label="Issue status"
                            value={draft.status || "Open"}
                            onChange={(e) =>
                              setDraft({ ...draft, status: e.target.value })
                            }
                          >
                            {["Open", "Investigating", "Resolved"].map((x) => (
                              <option key={x}>{x}</option>
                            ))}
                          </select>
                        </label>
                      </>
                    )}
                    <label>
                      Verification status
                      <select
                        aria-label="Verification status"
                        value={draft.verification || "Not assessed"}
                        onChange={(e) =>
                          setDraft({ ...draft, verification: e.target.value })
                        }
                      >
                        {[
                          "Not assessed",
                          "Unverified",
                          "Supported by evidence",
                          "Disputed",
                          "False — evidence documented",
                        ].map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Evidence attachment
                      <input
                        aria-label="Evidence attachment"
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png,.webp,.mp3,.wav,.m4a,.ogg,.webm,.mp4,.txt"
                        disabled={busy}
                        onChange={(e) =>
                          e.target.files?.[0] &&
                          uploadEvidence(e.target.files[0])
                        }
                      />
                    </label>
                    {draft.evidence && (
                      <div className="full evidence-link">
                        <FileText size={15} />
                        <a
                          href={
                            "/api/evidence?key=" +
                            encodeURIComponent(draft.evidence.key)
                          }
                        >
                          {draft.evidence.name}
                        </a>
                        <button
                          type="button"
                          className="text-button"
                          onClick={() => setDraft({ ...draft, evidence: null })}
                        >
                          Detach
                        </button>
                      </div>
                    )}
                    <label className="full">
                      Analyst notes & verification evidence
                      <textarea
                        aria-label="Analyst notes &amp; verification evidence"
                        rows={3}
                        value={draft.notes || ""}
                        placeholder="Document context, evidence and recommended actions…"
                        onChange={(e) =>
                          setDraft({ ...draft, notes: e.target.value })
                        }
                      />
                    </label>
                  </StepFields>
                  <p className="fine-print">
                    Use Language studio to extract scan text, record audio or
                    transcribe recordings. Attach the original evidence here.
                    Maximum file size: 10 MB.
                  </p>
                  <div className="modal-actions">
                    {modal === "detail" && (
                      <button
                        type="button"
                        className="danger-button"
                        onClick={() => setModal("deleteStory")}
                      >
                        <Trash2 size={15} /> Delete
                      </button>
                    )}
                    <button
                      type="submit"
                      className="primary"
                      disabled={busy || session?.role === "Viewer"}
                    >
                      {busy ? (
                        <LoaderCircle size={16} className="spin" />
                      ) : (
                        <Check size={16} />
                      )}{" "}
                      {modal === "detail"
                        ? "Save analyst review"
                        : "Save & analyse story"}
                    </button>
                  </div>
                </form>
              </>
            )}
            {modal === "source" && (
              <>
                <h2>{draft.id ? "Configure source" : "Add a source"}</h2>
                <p className="modal-intro">
                  Create a source for any Namibian or international outlet.
                </p>
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    await save({
                      ...draft,
                      id: draft.id || crypto.randomUUID(),
                      kind: "source",
                    });
                  }}
                >
                  <StepFields
                    names={
                      modal === "source"
                        ? ["Source details"]
                        : modal === "rule"
                          ? ["Watchlist details"]
                          : [
                              "Story basics",
                              "Text & details",
                              "People & context",
                              "Summary & response",
                              "Review & evidence",
                              "Final checks",
                            ]
                    }
                    size={6}
                  >
                    <label className="full">
                      Source name
                      <input
                        aria-label="Source name"
                        required
                        value={draft.name}
                        onChange={(e) =>
                          setDraft({ ...draft, name: e.target.value })
                        }
                      />
                    </label>
                    <label>
                      Media channel
                      <select
                        aria-label="Media channel"
                        value={draft.channel}
                        onChange={(e) =>
                          setDraft({ ...draft, channel: e.target.value })
                        }
                      >
                        {channels.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Primary language
                      <select
                        aria-label="Primary language"
                        value={draft.language}
                        onChange={(e) =>
                          setDraft({ ...draft, language: e.target.value })
                        }
                      >
                        {languages.map((x) => (
                          <option key={x}>{x}</option>
                        ))}
                      </select>
                    </label>
                    <label className="full">
                      Public news feed link (optional)
                      <input
                        aria-label="Public news feed link (optional)"
                        type="url"
                        placeholder="https://example.com/rss.xml"
                        value={draft.url || ""}
                        onChange={(e) =>
                          setDraft({ ...draft, url: e.target.value })
                        }
                      />
                    </label>
                    <label className="checkbox-label full">
                      <input
                        type="checkbox"
                        checked={draft.enabled}
                        onChange={(e) =>
                          setDraft({ ...draft, enabled: e.target.checked })
                        }
                      />{" "}
                      Enable this source
                    </label>
                  </StepFields>
                  <div className="help-note">
                    Without a feed URL, collect this source using manual stories
                    or file imports. No subscriptions or social accounts are
                    connected.
                  </div>
                  <div className="modal-actions">
                    {draft.id && (
                      <button
                        type="button"
                        className="danger-button"
                        disabled={busy}
                        onClick={() => setModal("deleteSource")}
                      >
                        <Trash2 size={15} /> Delete source
                      </button>
                    )}
                    <button className="primary" disabled={busy}>
                      Save source
                    </button>
                  </div>
                </form>
              </>
            )}
            {modal === "rule" && (
              <>
                <h2>{draft.id ? "Edit watchlist" : "Create a watchlist"}</h2>
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (
                      !draft.keywords.split(",").some((s: string) => s.trim())
                    ) {
                      setNotice("Enter at least one keyword");
                      return;
                    }
                    await save({
                      ...draft,
                      id: draft.id || crypto.randomUUID(),
                      kind: "rule",
                    });
                  }}
                >
                  <StepFields
                    names={
                      modal === "source"
                        ? ["Source details"]
                        : modal === "rule"
                          ? ["Watchlist details"]
                          : [
                              "Story basics",
                              "Text & details",
                              "People & context",
                              "Summary & response",
                              "Review & evidence",
                              "Final checks",
                            ]
                    }
                    size={6}
                  >
                    <label className="full">
                      Watchlist name
                      <input
                        aria-label="Watchlist name"
                        required
                        value={draft.name}
                        onChange={(e) =>
                          setDraft({ ...draft, name: e.target.value })
                        }
                      />
                    </label>
                    <label className="full">
                      Keywords, separated by commas
                      <input
                        aria-label="Keywords, separated by commas"
                        required
                        placeholder="water, drought, service delivery"
                        value={draft.keywords}
                        onChange={(e) =>
                          setDraft({ ...draft, keywords: e.target.value })
                        }
                      />
                    </label>
                    <label className="full">
                      Description
                      <textarea
                        aria-label="Description"
                        value={draft.description}
                        onChange={(e) =>
                          setDraft({ ...draft, description: e.target.value })
                        }
                      />
                    </label>
                  </StepFields>
                  <p className="fine-print">
                    Matches any keyword in a story’s headline or text, across
                    all saved stories.
                  </p>
                  <div className="modal-actions">
                    {draft.id && (
                      <button
                        type="button"
                        className="danger-button"
                        onClick={() => setModal("deleteRule")}
                      >
                        Delete watchlist
                      </button>
                    )}
                    <button className="primary" disabled={busy}>
                      Save watchlist
                    </button>
                  </div>
                </form>
              </>
            )}
            {modal === "report" && selected && (
              <>
                <h2>{selected.title}</h2>
                <div className="report-actions">
                  <button
                    className="button"
                    onClick={() =>
                      download(
                        "nmo-briefing-" + selected.date + ".txt",
                        selected.content,
                      )
                    }
                  >
                    <ArrowDownToLine size={15} /> Download text
                  </button>
                  <a
                    className="button source-download"
                    href={
                      "/api/export?id=" +
                      encodeURIComponent(selected.id) +
                      "&format=docx"
                    }
                  >
                    <ArrowDownToLine size={15} /> Word download
                  </a>
                  <a
                    className="button source-download"
                    href={
                      "/api/export?id=" +
                      encodeURIComponent(selected.id) +
                      "&format=xlsx"
                    }
                  >
                    <ArrowDownToLine size={15} /> Spreadsheet download
                  </a>
                  <button
                    className="button"
                    disabled={busy}
                    onClick={pdfReport}
                  >
                    <ArrowDownToLine size={15} /> PDF download
                  </button>
                  <button className="primary" onClick={() => window.print()}>
                    <FileText size={15} /> Print / Save PDF
                  </button>
                  <button
                    className="danger-button"
                    onClick={() => setModal("deleteReport")}
                  >
                    <Trash2 size={15} /> Delete
                  </button>
                </div>
                {selected.items ? (
                  <>
                    <p className="report-warning">
                      {selected.count} stories · {selected.samples || 0}{" "}
                      fictional samples · Approval:{" "}
                      {selected.approval || "Draft"}. Saved snapshots do not
                      change when stories are edited.
                    </p>
                    {reportSections(selected).map((section) => (
                      <section key={section.name}>
                        <h3 className="manual-section-title">{section.name}</h3>
                        <div className="report-table-wrapper">
                          <table className="manual-report-table">
                            <thead>
                              <tr>
                                {section.headers.map((h) => (
                                  <th key={h}>{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {section.rows.map((row, i) => (
                                <tr key={i}>
                                  {row.map((cell, n) => (
                                    <td
                                      key={n}
                                      className={
                                        cell === "Negative"
                                          ? "negative-text"
                                          : cell === "Positive"
                                            ? "positive-text"
                                            : ""
                                      }
                                    >
                                      {cell}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {!section.rows.length && (
                          <p className="report-warning">
                            No stories recorded in this section.
                          </p>
                        )}
                      </section>
                    ))}
                  </>
                ) : (
                  <pre className="report-document">{selected.content}</pre>
                )}
              </>
            )}
            {[
              "removeSamples",
              "deleteStory",
              "deleteSource",
              "deleteRule",
              "deleteReport",
            ].includes(modal) && (
              <>
                <h2>
                  {modal === "removeSamples"
                    ? "Remove illustrative stories?"
                    : "Delete this record?"}
                </h2>
                <p className="modal-intro">
                  {modal === "removeSamples"
                    ? "This removes fictional sample stories. Saved report snapshots and your own records remain."
                    : "This record will be removed from the workspace. Saved report snapshots are retained."}
                </p>
                <div className="modal-actions">
                  <button className="button" onClick={() => setModal("")}>
                    Cancel
                  </button>
                  <button
                    className="danger-button"
                    disabled={busy}
                    onClick={async () => {
                      if (modal === "removeSamples") {
                        await save({ action: "removeSamples" });
                      } else {
                        const item =
                          modal === "deleteReport" ? selected : draft;
                        if (item)
                          await save({
                            id: item.id,
                            kind:
                              item.kind ||
                              (modal === "deleteSource"
                                ? "source"
                                : modal === "deleteRule"
                                  ? "rule"
                                  : "story"),
                            action: "delete",
                          });
                      }
                    }}
                  >
                    Confirm removal
                  </button>
                </div>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
