import { readSecret } from "./secrets";
import { getRecord, putRecord } from "./store";
export const integrations = [
  {
    id: "deepgram",
    name: "Deepgram transcription",
    purpose: "Uploaded audio/video transcription",
    needsKey: true,
  },
  {
    id: "huggingface",
    name: "Multilingual sentiment model",
    purpose:
      "Hugging Face XLM-R model (English/German and six other trained languages)",
    needsKey: true,
  },
  {
    id: "bluesky",
    name: "Bluesky public search",
    purpose: "Public social posts matching configured keywords",
    needsKey: false,
  },
  {
    id: "youtube",
    name: "YouTube public search",
    purpose: "Public video metadata; requires Google API key",
    needsKey: true,
  },
  {
    id: "x",
    name: "X public search",
    purpose: "Recent posts; requires an eligible API plan and bearer token",
    needsKey: true,
  },
  {
    id: "facebook",
    name: "Facebook Page posts",
    purpose: "Authorised Page posts; requires a Meta Page token",
    needsKey: true,
  },
];
export async function providerStatus() {
  return Promise.all(
    integrations.map(async (p) => {
      const cfg = await getRecord("integration-" + p.id);
      return {
        ...p,
        configured: !p.needsKey || Boolean(await getRecord("secret-" + p.id)),
        enabled: cfg?.enabled || false,
        query: cfg?.query || "Namibia",
        pageId: cfg?.pageId || "",
        lastTest: cfg?.lastTest || null,
        lastError: cfg?.lastError || "",
        health: cfg?.health || "Not tested",
      };
    }),
  );
}
export async function sentimentModel(text: string, language: string) {
  if (
    ![
      "English",
      "German",
      "Arabic",
      "French",
      "Hindi",
      "Italian",
      "Spanish",
      "Portuguese",
    ].includes(language)
  )
    throw Error(
      "The connected model does not validate this language. Use a language reviewer.",
    );
  const cfg = await getRecord("integration-huggingface");
  if (!cfg?.enabled)
    throw Error("Enable the sentiment model in Integrations first");
  const token = await readSecret("huggingface");
  if (!token) throw Error("Connect a Hugging Face token first");
  const res = await fetch(
    "https://router.huggingface.co/hf-inference/models/cardiffnlp/twitter-xlm-roberta-base-sentiment",
    {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ inputs: text.slice(0, 5000) }),
      signal: AbortSignal.timeout(25000),
    },
  );
  if (!res.ok) throw Error("Sentiment provider returned " + res.status);
  const j: any = await res.json();
  const rows = Array.isArray(j[0]) ? j[0] : j;
  const top = Array.isArray(rows)
    ? rows.sort((a: any, b: any) => b.score - a.score)[0]
    : null;
  const label = String(top?.label || "").toLowerCase();
  const sentiment =
    label.includes("positive") || label === "label_2"
      ? "Positive"
      : label.includes("negative") || label === "label_0"
        ? "Negative"
        : label.includes("neutral") || label === "label_1"
          ? "Neutral"
          : null;
  if (!sentiment) throw Error("Unrecognised model output");
  return {
    sentiment,
    confidence: Number(top.score),
    analysisReason:
      "Connected XLM-R model suggestion. Context and language accuracy require review.",
    analysisMethod: "XLM-R multilingual model",
    reviewed: false,
  };
}
export async function socialSearch(provider: string, cfg: any) {
  const q = cfg.query || "Namibia";
  const token = integrations.find((p) => p.id === provider)?.needsKey
    ? await readSecret(provider)
    : "";
  let url: string;
  let headers: Record<string, string> = {};
  if (provider === "bluesky")
    url =
      "https://public.api.bsky.app/xrpc/app.bsky.feed.searchPosts?q=" +
      encodeURIComponent(q) +
      "&limit=25&sort=latest";
  else if (provider === "youtube") {
    if (!token) throw Error("YouTube API key not connected");
    url =
      "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=25&q=" +
      encodeURIComponent(q) +
      "&key=" +
      encodeURIComponent(token);
  } else if (provider === "x") {
    if (!token) throw Error("X bearer token not connected");
    url =
      "https://api.x.com/2/tweets/search/recent?max_results=25&tweet.fields=created_at,lang,public_metrics&query=" +
      encodeURIComponent(q);
    headers.Authorization = "Bearer " + token;
  } else if (provider === "facebook") {
    if (!token || !/^\d+$/.test(cfg.pageId || ""))
      throw Error("Connect a Page token and numeric Page ID");
    url =
      "https://graph.facebook.com/v23.0/" +
      cfg.pageId +
      "/posts?fields=message,created_time,permalink_url&limit=25";
    headers.Authorization = "Bearer " + token;
  } else throw Error("Unknown social provider");
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw Error(provider + " API returned " + res.status);
  const j: any = await res.json();
  if (provider === "bluesky")
    return (j.posts || []).map((p: any) => ({
      externalId: p.uri,
      title: p.record?.text?.slice(0, 130) || "Bluesky post",
      body: p.record?.text || "",
      source: "Bluesky · " + p.author?.handle,
      date: p.record?.createdAt || new Date().toISOString(),
      url:
        "https://bsky.app/profile/" +
        p.author?.handle +
        "/post/" +
        p.uri?.split("/").pop(),
      language: p.record?.langs?.includes("en")
        ? "English"
        : p.record?.langs?.includes("de")
          ? "German"
          : p.record?.langs?.includes("af")
            ? "Afrikaans"
            : "Other",
      channel: "Social",
    }));
  if (provider === "youtube")
    return (j.items || []).map((p: any) => ({
      externalId: p.id.videoId,
      title: p.snippet.title,
      body: p.snippet.description || p.snippet.title,
      source: "YouTube · " + p.snippet.channelTitle,
      date: p.snippet.publishedAt,
      url: "https://www.youtube.com/watch?v=" + p.id.videoId,
      language: "English",
      channel: "Social",
    }));
  if (provider === "x")
    return (j.data || []).map((p: any) => ({
      externalId: p.id,
      title: p.text.slice(0, 130),
      body: p.text,
      source: "X",
      date: p.created_at,
      url: "https://x.com/i/web/status/" + p.id,
      language:
        p.lang === "en"
          ? "English"
          : p.lang === "de"
            ? "German"
            : p.lang === "af"
              ? "Afrikaans"
              : "Other",
      channel: "Social",
    }));
  return (j.data || [])
    .filter((p: any) => p.message)
    .map((p: any) => ({
      externalId: p.id,
      title: p.message.slice(0, 130),
      body: p.message,
      source: "Facebook Page " + cfg.pageId,
      date: p.created_time,
      url: p.permalink_url || "",
      language: "Other",
      channel: "Social",
    }));
}
export async function testProvider(id: string) {
  const cfg = (await getRecord("integration-" + id)) || {};
  try {
    if (id === "deepgram") {
      const token = await readSecret(id);
      if (!token) throw Error("Connect a Deepgram key first");
      const r = await fetch("https://api.deepgram.com/v1/projects", {
        headers: { Authorization: "Token " + token },
        signal: AbortSignal.timeout(10000),
      });
      if (!r.ok) throw Error("Provider returned " + r.status);
    } else if (id === "huggingface")
      await sentimentModel("A successful opportunity for Namibia.", "English");
    else await socialSearch(id, cfg);
    await putRecord({
      ...cfg,
      id: "integration-" + id,
      kind: "settings",
      health: "Connected",
      lastTest: new Date().toISOString(),
      lastError: "",
    });
    return { ok: true };
  } catch (e) {
    const error = (e as Error).message;
    await putRecord({
      ...cfg,
      id: "integration-" + id,
      kind: "settings",
      health: "Needs attention",
      lastTest: new Date().toISOString(),
      lastError: error,
    });
    throw e;
  }
}
