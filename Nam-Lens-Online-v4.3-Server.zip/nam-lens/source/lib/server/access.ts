import {
  randomBytes,
  scryptSync,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import { allRecords, getRecord, putRecord, db } from "./store";
type Session = { email: string; expires: number };
class PersistentSessions extends Map<string, Session> {
  constructor() {
    super();
    db.exec(
      "CREATE TABLE IF NOT EXISTS auth_sessions (tokenHash TEXT PRIMARY KEY, email TEXT NOT NULL, expires INTEGER NOT NULL)",
    );
    db.prepare("DELETE FROM auth_sessions WHERE expires <= ?").run(Date.now());
    for (const r of db
      .prepare("SELECT tokenHash,email,expires FROM auth_sessions")
      .all() as any[])
      super.set("hash:" + r.tokenHash, { email: r.email, expires: r.expires });
  }
  private key(token: string) {
    return token.startsWith("hash:")
      ? token
      : "hash:" + createHash("sha256").update(token).digest("hex");
  }
  get(token: string) {
    return super.get("hash:"+createHash("sha256").update(token).digest("hex"));
  }
  set(token: string, value: Session) {
    const key = this.key(token);
    db.prepare(
      "INSERT INTO auth_sessions VALUES (?,?,?) ON CONFLICT(tokenHash) DO UPDATE SET email=excluded.email,expires=excluded.expires",
    ).run(key.slice(5), value.email, value.expires);
    return super.set(key, value);
  }
  delete(token: string) {
    const key = this.key(token);
    db.prepare("DELETE FROM auth_sessions WHERE tokenHash=?").run(key.slice(5));
    return super.delete(key);
  }
  clear() {
    db.exec("DELETE FROM auth_sessions");
    super.clear();
  }
}
export const sessions =
  process.env.NAMLENS_HOSTED === "1"
    ? new PersistentSessions()
    : new Map<string, Session>();
export const owner = {
  id: "owner",
  email: (
    process.env.NAMLENS_ADMIN_EMAIL || "owner@namibia.local"
  ).toLowerCase(),
  name: "Workspace owner",
  role: "Admin",
};
export const serviceActor = {
  id: "scheduler",
  email: "",
  name: "Local scheduled monitoring",
  role: "Service",
};
export function hashPassword(password: string) {
  if (
    typeof password !== "string" ||
    password.length < 8 ||
    password.length > 200
  )
    throw Error("Use a password of 8 to 200 characters");
  const salt = randomBytes(16).toString("hex");
  return { salt, hash: scryptSync(password, salt, 32).toString("hex") };
}
export function matches(password: string, credential: any) {
  try {
    const expected = Buffer.from(credential.hash, "hex");
    return timingSafeEqual(scryptSync(password, credential.salt, 32), expected);
  } catch {
    return false;
  }
}
export async function loadOwner() {
  if (process.env.NAMLENS_HOSTED === "1") return;
  Object.assign(owner, {
    email: (
      process.env.NAMLENS_ADMIN_EMAIL || "owner@namibia.local"
    ).toLowerCase(),
    name: "Workspace owner",
  });
  const saved = await getRecord("workspace-owner");
  if (saved?.email)
    Object.assign(owner, {
      email: saved.email,
      name: saved.name || "Workspace owner",
    });
}
export async function authEnabled() {
  return true;
}
export async function setupNeeded() {
  return (
    process.env.NAMLENS_HOSTED !== "1" &&
    !(await getRecord("auth-" + owner.email))
  );
}
let registrationLock = Promise.resolve();
export async function registerAccount(data: any) {
  const previous = registrationLock;
  let release!: () => void;
  registrationLock = new Promise<void>((resolve) => (release = resolve));
  await previous;
  try {
    const email = String(data.email || "")
        .trim()
        .toLowerCase(),
      name = String(data.name || "").trim();
    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      email.length > 254 ||
      !name ||
      name.length > 100
    )
      throw Error("Enter your name and a valid email address");
    if (
      (await getRecord("auth-" + email)) ||
      (await allRecords()).some((x) => x.kind === "member" && x.email === email)
    )
      throw Error("This email already has an account. Please log in.");
    const credential = hashPassword(data.password),
      first = await setupNeeded();
    db.exec("BEGIN IMMEDIATE");
    try {
      await putRecord({ id: "auth-" + email, kind: "auth", ...credential });
      if (first) {
        await putRecord({
          id: "workspace-owner",
          kind: "settings",
          email,
          name,
        });
        await putRecord({ id: "local-auth", kind: "settings", enabled: true });
      } else {
        await putRecord({
          id: crypto.randomUUID(),
          kind: "member",
          email,
          name,
          role: "Viewer",
          enabled: false,
          pending: true,
          date: new Date().toISOString(),
        });
      }
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    if (first) Object.assign(owner, { email, name });
    await audit(
      first ? owner : { name, email, role: "Applicant" },
      "Register account",
      "workspace",
      first ? "Owner account created" : "Awaiting owner approval",
    );
    return { ok: true, pending: !first };
  } finally {
    release();
  }
}
export async function actor(req: Request) {
  const token = req.headers
    .get("cookie")
    ?.match(/(?:^|;\s*)nmo_session=([^;]+)/)?.[1];
  const session = token ? sessions.get(token) : null;
  if (!session || session.expires < Date.now())
    throw Error("401:Sign in to access this workspace");
  if (session.email === owner.email) return owner;
  const m = (await allRecords()).find(
    (m) => m.kind === "member" && m.email === session.email && m.enabled,
  );
  if (!m) throw Error("401:Account disabled or removed");
  return { id: m.id, email: m.email, name: m.name || m.email, role: m.role };
}
export function createSession(email: string) {
  for (const [key, s] of sessions)
    if (s.expires < Date.now()) sessions.delete(key);
  if (sessions.size > 1000) throw Error("403:Too many active sessions");
  const token = randomBytes(32).toString("hex");
  sessions.set(token, { email, expires: Date.now() + 8 * 3600000 });
  return (
    "nmo_session=" +
    token +
    "; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800" +
    (process.env.NAMLENS_HOSTED === "1" ? "; Secure" : "")
  );
}
export function requireRole(a: any, roles: string[]) {
  if (!roles.includes(a.role))
    throw Error("403:This action requires " + roles.join(" or ") + " access");
}
export function sameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (origin && origin !== new URL(req.url).origin)
    throw Error("403:Invalid origin");
  if (req.headers.get("sec-fetch-site") === "cross-site")
    throw Error("403:Invalid origin");
}
export function apiError(e: any) {
  const m = e?.message || "Operation failed";
  return Response.json(
    { error: m.replace(/^\d{3}:/, "") },
    { status: /^(401|403|404|413):/.test(m) ? Number(m.slice(0, 3)) : 400 },
  );
}
export async function audit(
  a: any,
  action: string,
  target: string,
  details: string,
) {
  await putRecord({
    id: crypto.randomUUID(),
    kind: "audit",
    actor: a.name,
    email: a.email,
    role: a.role,
    action,
    target,
    details,
    date: new Date().toISOString(),
  });
}
