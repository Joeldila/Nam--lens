# Nam Lens 4.2 — original local edition

The original media desk now opens with a minimal public welcome page. Registration and login forms appear after the corresponding button is selected. The existing logo, newsroom tools, sources, stories, reports, alerts, review roles, document extraction and broadcast capture remain part of the app.

- Animated logo assembly, rotating opening indicator, changing introductory sections, manual slide controls and reduced-motion support.
- Database-backed registration, salted password hashes, owner setup and login. Later accounts wait for owner approval and cannot choose elevated access for themselves. Existing signed-in accounts migrate with their original roles.
- Public User guide at `/guide`, accessible before login. Settings contains account, password, backup and scheduling controls.
- Shorter story, source, campaign, action and broadcast forms with Back/Next, retained values and validation before saving. Print-only fields and broadcast-only fields appear for the relevant media channel.
- Clearer navigation and buttons: News & stories, Daily reports, Language studio, Connections, Settings, Import and Download spreadsheet. Imports still accept the original saved formats internally.
- A navigation drawer with a Menu button, desktop edge hover, keyboard access, Escape/close controls and optional pinning. Touch navigation uses the button.
- Phone, tablet and desktop layout adjustments; explicit form labels and branded app icons.
- Language studio: recording/upload, playback, saved personal working drafts, original-language selection, timed transcript editing when supported by the connected engine, evidence links and fluent-speaker confirmation before continuing to a story.
- Optional private AI engine for English, Afrikaans and German, plus an experimental Oshiwambo model. Capability discovery prevents an unsupported language being presented as available AI. Human transcription works for all listed languages.
- Separate Oshindonga and Oshikwanyama choices, alongside Otjiherero, Khoekhoegowab, Rukwangali, Silozi and Setswana. Their AI availability depends on a service that actually advertises support; the bundled experimental Oshiwambo model does not establish dialect-specific accuracy.
- Original-workspace copy upgrade and full backup restore tested against version 4.1. No online deployment has been performed.

## Language model evidence

The optional Oshiwambo experiment loads [`jpandeinge/whisper-tiny-oshiwambo-speech`](https://huggingface.co/jpandeinge/whisper-tiny-oshiwambo-speech), an Apache-2.0 model described by its author as a fine-tuned Whisper Tiny model. Its card leaves important dataset and intended-use information incomplete and reports substantial recognition errors. Nam Lens does not claim reliable Namibian-news accuracy for it. Use short recordings and fluent-speaker evaluation before any operational reliance.

The contribution here is a media workflow that keeps the voice, transcript, corrections, language and review together. It is not a claim that this is Namibia's first or only language tool, or that every indigenous language has a production-ready speech model.

See READ-ME-FIRST.txt for upgrade/start instructions and TEST-RESULTS.md for the checks and remaining limits.

## 4.3 online server preparation

- Added verified public-feed addresses for The Namibian and NBC Digital News to fresh hosted workspaces.
- Persistent, hashed eight-hour login sessions in hosted mode, with logout/password revocation.
- Explicit owner email and persistent data-directory validation for hosting.
- Account-specific login-attempt buckets so different users behind the same proxy do not share a single login-attempt limit.
- No-GitHub container build helper and exact Render setup instructions, with costs and remaining account/image requirements disclosed.
- Hosted account, restart, import and deduplication checks completed; see HOSTED-TEST-RESULTS.md for the test transport limit.

No public deployment was performed during preparation. Provider connections and experimental-language limitations remain explicit.
