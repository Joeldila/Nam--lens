# Nam Lens 4.3 — online server edition

Read ONLINE-SETUP.txt for the no-GitHub Render route, persistent-storage settings and current costs. This is a deployment candidate, not an already published website.

The original full server and interface are retained. The Namibian and NBC Digital News feeds are added; online login sessions and records persist on the configured disk. See HOSTED-TEST-RESULTS.md for passed checks and verification limits.

Keep the local 4.2 copy and back up before migration.
