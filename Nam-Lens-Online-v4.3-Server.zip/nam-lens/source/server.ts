import { analysisTick, recoverAnalysis } from "./lib/server/automatic-analysis";
import {
  hosted,
  origin,
  validateRuntime,
  automaticBackup,
} from "./lib/server/runtime";
import {
  saveBroadcast,
  broadcastTick,
  transcriptionTick,
  ffmpegAvailable,
  captureRunning,
  recoverCaptureJobs,
  stopCaptures,
} from "./lib/server/broadcast";
import {
  transcribeBytes,
  speechHealth,
  speechStatus,
  configureSpeech,
  speechLanguages,
} from "./lib/server/transcription";
import {
  connectedAnalysis,
  addBenchmark,
  evaluateBenchmark,
} from "./lib/server/quality";
import { deliveryTick } from "./lib/server/delivery";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import {
  allRecords,
  getRecord,
  putRecord,
  insertRecord,
  deleteRecord,
  db,
  dataDir,
} from "./lib/server/store";
import {
  loadOwner,
  setupNeeded,
  registerAccount,
  actor,
  owner,
  audit,
  authEnabled,
  hashPassword,
  matches,
  createSession,
  sessions,
  requireRole,
  sameOrigin,
  apiError,
} from "./lib/server/access";
import { sampleRecords } from "./lib/sample";
import { enrich, buildBriefing, namibiaDay } from "./lib/intelligence";
import { collectSource } from "./lib/server/collection";
import {
  providerStatus,
  testProvider,
  integrations,
  sentimentModel,
} from "./lib/server/providers";
import { saveSecret, readSecret } from "./lib/server/secrets";
import { runMonitoringJob } from "./lib/server/jobs";
import { createDocx, createXlsx, createPDF } from "./lib/exports";
import { publicFetch, limitedBytes } from "./lib/server/network";
import { zipSync, unzipSync, strToU8, strFromU8 } from "fflate";
validateRuntime();
await loadOwner();
const root = path.dirname(fileURLToPath(import.meta.url)),
  publicDir = path.join(root, "public");
const project = createHash("sha256").update(root).digest("hex").slice(0, 16);
const writable = [
  "story",
  "source",
  "rule",
  "report",
  "member",
  "entity",
  "campaign",
  "action",
];
const attachmentDir = path.join(dataDir, "evidence");
fs.mkdirSync(attachmentDir, { recursive: true });
const json = (x: any) => Response.json(x);
const localDay = () => namibiaDay();
function safeItem(x: any) {
  const { hash, salt, password, ...rest } = x;
  return rest;
}
async function initialise() {
  if (!(await getRecord("initialised"))) {
    db.exec("BEGIN");
    try {
      for (const r of sampleRecords().filter(
        (r) => !hosted || r.kind !== "story",
      ))
        await putRecord(
          enrich({ id: r.id, kind: r.kind, ...JSON.parse(r.data) }),
        );
      await putRecord({ id: "initialised", kind: "settings" });
      await putRecord({
        id: "monitoring-settings",
        kind: "settings",
        paused: false,
        intervalMinutes: 60,
      });
      await putRecord({
        id: "feed-bbc-africa",
        kind: "source",
        name: "BBC News · Africa",
        url: "https://feeds.bbci.co.uk/news/world/africa/rss.xml",
        region: "International",
        channel: "Online",
        language: "English",
        enabled: hosted,
        health: "Ready to collect",
      });
      await putRecord({
        id: "feed-google-namibia",
        kind: "source",
        name: "Google News · Namibia",
        url: "https://news.google.com/rss/search?q=Namibia&hl=en-US&gl=US&ceid=US:en",
        region: "National",
        channel: "Online",
        language: "English",
        enabled: hosted,
        health: "Ready to collect",
      });
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
  }
  if (hosted) {
    for (const source of [
      {
        id: "feed-namibian-live",
        name: "The Namibian · Online",
        url: "https://www.namibian.com.na/feed/",
        region: "National",
      },
      {
        id: "feed-nbc-live",
        name: "NBC Digital News",
        url: "https://nbcnews.na/index.php/rss.xml",
        region: "National",
      },
    ])
      await insertRecord({
        ...source,
        kind: "source",
        channel: "Online",
        language: "English",
        enabled: true,
        health: "Ready to collect",
      });
  }
  await putRecord({
    id: "cloud-schedule",
    kind: "automation",
    enabled: true,
    title: hosted ? "Hosted monitoring" : "Local monitoring",
    timezone: "Africa/Windhoek",
  });
}
function reqEdit(a: any) {
  requireRole(a, ["Admin", "Analyst", "Reviewer"]);
}
function validApproval(value: any) {
  if (
    !["Draft", "Pending review", "Approved", "Changes requested"].includes(
      value || "Draft",
    )
  )
    throw Error("Invalid approval state");
}
async function saveRecord(a: any, data: any) {
  if (data.action === "removeSamples") {
    requireRole(a, ["Admin"]);
    for (const x of (await allRecords()).filter(
      (x) => x.kind === "story" && x.sample,
    ))
      await deleteRecord(x.id);
    await audit(
      a,
      "Remove samples",
      "workspace",
      "Fictional story records removed",
    );
    return { ok: true };
  }
  if (
    !writable.includes(data.kind) ||
    typeof data.id !== "string" ||
    !data.id ||
    data.id.length > 100
  )
    throw Error("Invalid record");
  requireRole(
    a,
    ["source", "member"].includes(data.kind)
      ? ["Admin"]
      : ["Admin", "Analyst", "Reviewer"],
  );
  const old = await getRecord(data.id);
  if (old && old.kind !== data.kind)
    throw Error("Record type cannot be changed");
  if (data.action === "delete") {
    if (data.kind === "member" && old?.email === a.email)
      throw Error("You cannot remove your own membership");
    if (data.kind === "member" && old?.email) {
      await deleteRecord("auth-" + old.email);
      for (const [key, v] of sessions)
        if (v.email === old.email) sessions.delete(key);
    }
    await deleteRecord(data.id);
    await audit(a, "Delete", data.id, data.kind + " removed");
    return { ok: true };
  }
  const { action, ...body } = data;
  let item: any = { ...body };
  if (JSON.stringify(item).length > 3000000) throw Error("Record too large");
  if (item.kind === "story") {
    if (
      typeof item.title !== "string" ||
      !item.title.trim() ||
      item.title.length > 500 ||
      typeof item.body !== "string" ||
      !item.body.trim() ||
      item.body.length > 60000
    )
      throw Error(
        "Headline (up to 500 characters) and text (up to 60,000) are required",
      );
    if (isNaN(Date.parse(item.date)))
      throw Error("Valid publication date required");
    item.date = new Date(item.date).toISOString();
    item = enrich(
      item,
      (await allRecords()).filter((x) => x.kind === "entity"),
    );
    validApproval(item.approval);
    if (
      !["Positive", "Negative", "Neutral", "Unclassified"].includes(
        item.sentiment,
      ) ||
      !["High", "Medium", "Low"].includes(item.risk)
    )
      throw Error("Valid sentiment and priority required");
    if (
      !["Print", "Radio", "Television", "Online", "Social"].includes(
        item.channel,
      )
    )
      throw Error("Valid media channel required");
    if (item.url && !/^https?:\/\//i.test(item.url))
      throw Error("Source links must use HTTP or HTTPS");
    if (item.evidence && !(await getRecord("evidence-" + item.evidence.key)))
      throw Error("Evidence attachment not found");
    if (item.approval === "Approved" && old?.approval !== "Approved")
      requireRole(a, ["Admin", "Reviewer"]);
    const changed =
      !old ||
      [
        "title",
        "body",
        "source",
        "channel",
        "date",
        "language",
        "region",
        "url",
        "sentiment",
        "risk",
        "topic",
        "summary",
        "recommendation",
        "institutions",
        "quotedPerson",
        "quotedRole",
        "statementType",
        "programme",
        "presenter",
        "broadcastTime",
        "pageNumber",
        "verification",
        "notes",
        "evidence",
        "transcript",
        "sample",
      ].some((k) => JSON.stringify(old[k]) !== JSON.stringify(item[k]));
    if (changed && old?.approval === "Approved" && item.approval === "Approved")
      item.approval = "Pending review";
    item.reviewed = Boolean(item.reviewed);
    item.reviewedBy = item.reviewed ? a.name : old?.reviewedBy;
  }
  if (item.kind === "report") {
    validApproval(item.approval);
    if (!Array.isArray(item.items) || item.items.length > 10000)
      throw Error("Report requires story snapshot items");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(item.date))
      throw Error("Report date required");
    if (item.approval === "Approved" && old?.approval !== "Approved")
      requireRole(a, ["Admin", "Reviewer"]);
    if (
      old?.approval === "Approved" &&
      item.approval === "Approved" &&
      ["content", "items", "date", "title"].some(
        (k) => JSON.stringify(old[k]) !== JSON.stringify(item[k]),
      )
    )
      item.approval = "Pending review";
  }
  if (
    ["source", "entity", "campaign", "rule"].includes(item.kind) &&
    !item.name?.trim()
  )
    throw Error("Name is required");
  if (item.kind === "member") {
    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(item.email || "") ||
      !["Viewer", "Analyst", "Reviewer", "Admin"].includes(item.role)
    )
      throw Error("Valid email and role required");
    item.email = item.email.toLowerCase();
    if (item.email === owner.email)
      throw Error("Owner account is managed in Workspace");
    if (
      (await allRecords()).some(
        (x) =>
          x.kind === "member" && x.email === item.email && x.id !== item.id,
      )
    )
      throw Error("This email already has an account");
    const secret = await getRecord("auth-" + item.email);
    if ((!old || old.email !== item.email) && !item.password)
      throw Error("Set a new password for a new account or changed email");
    if (old?.email && old.email !== item.email) {
      await deleteRecord("auth-" + old.email);
      for (const [key, v] of sessions)
        if (v.email === old.email) sessions.delete(key);
    }
    if (item.enabled) item.pending = false;
    if (item.password) {
      await putRecord({
        id: "auth-" + item.email,
        kind: "auth",
        ...hashPassword(item.password),
      });
      for (const [token, session] of sessions)
        if (session.email === item.email) sessions.delete(token);
    } else if (!secret)
      throw Error("Set an initial password of at least 8 characters");
    delete item.password;
  }
  if (item.kind === "action" && !item.title?.trim())
    throw Error("Action title required");
  if (
    item.kind === "campaign" &&
    (!item.keywords?.trim() ||
      !(Number(item.target) > 0) ||
      (item.end && item.end < item.start))
  )
    throw Error("Valid keywords, dates and a positive target required");
  if (
    item.kind === "rule" &&
    !item.keywords?.split(",").some((s: string) => s.trim())
  )
    throw Error("Keywords are required");
  item.updatedBy = a.name;
  item.updatedAt = new Date().toISOString();
  await putRecord(item);
  await audit(
    a,
    old ? "Update" : "Create",
    item.id,
    item.kind + ": " + (item.title || item.name || item.email || item.id),
  );
  return { ok: true };
}
async function evidence(file: File) {
  if (!(file instanceof File) || file.size > 10485760)
    throw Error("Choose an evidence file under 10 MB");
  if (
    !/^(application\/pdf|image\/(jpeg|png|webp)|audio\/(mpeg|mp3|wav|x-wav|mp4|ogg|webm)|video\/(mp4|webm)|text\/plain)$/.test(
      file.type,
    )
  )
    throw Error(
      "Supported: PDF, JPG, PNG, WebP, MP3, WAV, M4A, OGG, WebM, MP4, TXT",
    );
  const key = crypto.randomUUID(),
    item = {
      key,
      name: file.name.slice(0, 250),
      type: file.type,
      size: file.size,
    };
  fs.writeFileSync(
    path.join(attachmentDir, key),
    Buffer.from(await file.arrayBuffer()),
  );
  await putRecord({ id: "evidence-" + key, kind: "evidence", ...item });
  return item;
}
const attempts = new Map<string, { time: number; count: number }>();
async function handle(req: Request) {
  const u = new URL(req.url);
  if (u.pathname === "/api/health")
    return json({
      ok: true,
      app: "namlens-v4",
      project,
      mode: hosted ? "hosted" : "local",
    });
  if (!u.pathname.startsWith("/api/")) return staticResponse(u.pathname);
  if (req.method !== "GET") {
    sameOrigin(req);
    const ct = req.headers.get("content-type") || "";
    if (
      !ct.startsWith("application/json") &&
      !ct.startsWith("multipart/form-data")
    )
      throw Error("403:JSON or multipart form data is required");
  }
  if (u.pathname === "/api/auth/status") {
    let a: any = null;
    try {
      a = await actor(req);
    } catch {}
    return json({
      enabled: await authEnabled(),
      authenticated: !!a,
      actor: a,
      setup: await setupNeeded(),
    });
  }
  if (u.pathname === "/api/auth/register" && req.method === "POST") {
    const peer = req.headers.get("x-namlens-peer") || "local",
      key = "register-" + peer;
    const limit = attempts.get(key) || { time: Date.now(), count: 0 };
    if (Date.now() - limit.time > 60000) {
      limit.time = Date.now();
      limit.count = 0;
    }
    attempts.set(key, limit);
    if (++limit.count > 5)
      throw Error("403:Too many registrations. Wait a minute and try again.");
    const result = await registerAccount(await req.json());
    return Response.json(result, {
      headers: result.pending
        ? {}
        : { "Set-Cookie": createSession(owner.email) },
    });
  }
  if (u.pathname === "/api/auth/login" && req.method === "POST") {
    const data = await req.json();
    const email = String(data.email || "")
        .trim()
        .toLowerCase(),
      loginKey =
        "login:" +
        (req.headers.get("x-namlens-peer") || "local") +
        ":" +
        email.slice(0, 254),
      limit = attempts.get(loginKey) || {
        time: Date.now(),
        count: 0,
      };
    if (Date.now() - limit.time > 60000) {
      limit.time = Date.now();
      limit.count = 0;
    }
    if (++limit.count > 10)
      throw Error("403:Too many attempts. Wait a minute and try again.");
    if (attempts.size > 1000)
      for (const [key, value] of attempts)
        if (Date.now() - value.time > 60000) attempts.delete(key);
    attempts.set(loginKey, limit);
    const credential = await getRecord("auth-" + email),
      member =
        email === owner.email
          ? owner
          : (await allRecords()).find(
              (m) => m.kind === "member" && m.email === email,
            );
    if (
      typeof data.password !== "string" ||
      data.password.length > 200 ||
      !member ||
      !credential ||
      !matches(data.password, credential)
    )
      throw Error("401:Email or password is incorrect");
    if (email !== owner.email && !member.enabled)
      throw Error(
        "403:Your account is waiting for owner approval or has been disabled",
      );
    attempts.delete(loginKey);
    return Response.json(
      { ok: true },
      { headers: { "Set-Cookie": createSession(email) } },
    );
  }
  if (u.pathname === "/api/auth/logout" && req.method === "POST") {
    const token = req.headers
      .get("cookie")
      ?.match(/(?:^|;\s*)nmo_session=([^;]+)/)?.[1];
    if (token) sessions.delete(token);
    return Response.json(
      { ok: true },
      {
        headers: {
          "Set-Cookie":
            "nmo_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0" +
            (hosted ? "; Secure" : ""),
        },
      },
    );
  }
  const a = await actor(req);
  if (u.pathname === "/api/workspace") {
    if (req.method === "GET") {
      const rows = await allRecords();
      return json([
        ...rows
          .filter(
            (x) =>
              ![
                "secret",
                "settings",
                "auth",
                "evidence",
                "captureDraft",
              ].includes(x.kind) &&
              (a.role === "Admin" || !["member", "audit"].includes(x.kind)),
          )
          .map(safeItem),
        { ...a, userId: a.id, id: "session", kind: "session" },
      ]);
    }
    if (req.method === "POST")
      return json(await saveRecord(a, await req.json()));
  }
  if (u.pathname === "/api/local") {
    if (req.method === "GET")
      return json({
        authEnabled: await authEnabled(),
        ownerEmail: owner.email,
        version: "4.3.0",
        hosted,
        dataFolder: "data",
        schedule: await getRecord("monitoring-settings"),
        lastBackup: (await getRecord("backup-settings"))?.date || null,
      });
    requireRole(a, ["Admin"]);
    const data = await req.json();
    if (data.action === "password") {
      await putRecord({
        id: "auth-" + owner.email,
        kind: "auth",
        ...hashPassword(data.password),
      });
      await putRecord({ id: "local-auth", kind: "settings", enabled: true });
      sessions.clear();
      await audit(
        a,
        "Enable local sign-in",
        "workspace",
        "Owner password created or updated",
      );
      return Response.json(
        { ok: true },
        { headers: { "Set-Cookie": createSession(owner.email) } },
      );
    }
    if (data.action === "disableAuth")
      throw Error("403:Sign-in stays enabled to protect registered accounts");
    throw Error("Unknown local setting");
  }
  if (u.pathname === "/api/speech") {
    if (req.method === "GET") return json(await speechStatus());
    requireRole(a, ["Admin"]);
    return json(await configureSpeech(await req.json()));
  }
  if (u.pathname === "/api/capture-draft") {
    reqEdit(a);
    const id = "capture-draft-" + a.id;
    if (req.method === "GET") {
      const d = await getRecord(id);
      return json(d || {});
    }
    const d = await req.json();
    if (d.clear) {
      await deleteRecord(id);
      return json({ ok: true });
    }
    if (
      typeof d.text !== "string" ||
      d.text.length > 60000 ||
      !speechLanguages[d.language]
    )
      throw Error(
        "Choose a language and keep the transcript below 60,000 characters",
      );
    if (d.evidence && !(await getRecord("evidence-" + d.evidence.key)))
      throw Error("Recording not found");
    const segments = Array.isArray(d.segments)
      ? d.segments.slice(0, 1000).map((s: any) => ({
          start: Number(s.start) || 0,
          end: Number(s.end) || 0,
          text: String(s.text || "").slice(0, 6000),
        }))
      : [];
    await putRecord({
      id,
      kind: "captureDraft",
      text: d.text,
      language: d.language,
      evidence: d.evidence || null,
      segments,
      provider: String(d.provider || "Human transcript").slice(0, 120),
      originalText: String(d.originalText || "").slice(0, 60000),
      reviewed: !!d.reviewed,
      updatedAt: new Date().toISOString(),
    });
    return json({ ok: true });
  }
  if (u.pathname === "/api/broadcast") {
    if (req.method === "GET")
      return json({
        streams: (await allRecords()).filter((x) => x.kind === "broadcast"),
        queue: (await allRecords())
          .filter((x) => x.kind === "transcription")
          .slice(0, 40),
        ffmpeg: ffmpegAvailable(),
        running: captureRunning.size,
      });
    requireRole(a, ["Admin"]);
    const d = await req.json();
    if (d.action === "run") {
      await broadcastTick();
      return json({ ok: true, running: captureRunning.size });
    }
    const result = await saveBroadcast(a, d);
    await audit(
      a,
      "Configure broadcast",
      result.id || d.id,
      d.name || d.action,
    );
    return json(result);
  }
  if (u.pathname === "/api/transcription/run" && req.method === "POST") {
    reqEdit(a);
    await transcriptionTick();
    return json({ ok: true });
  }
  if (u.pathname === "/api/notifications/run" && req.method === "POST") {
    requireRole(a, ["Admin"]);
    await deliveryTick();
    return json({ ok: true });
  }
  if (u.pathname === "/api/transcription/retry" && req.method === "POST") {
    reqEdit(a);
    const d = await req.json(),
      job = await getRecord(d.id);
    if (!job || job.kind !== "transcription")
      throw Error("404:Transcription task not found");
    if (job.status === "Processing") throw Error("Task is processing");
    await putRecord({
      ...job,
      status: "Queued",
      attempts: 0,
      nextAttempt: new Date().toISOString(),
    });
    return json({ ok: true });
  }
  if (u.pathname === "/api/languages") {
    requireRole(a, ["Admin", "Reviewer"]);
    if (req.method === "GET")
      return json({
        benchmarks: (await allRecords())
          .filter((x) => x.kind === "benchmark")
          .map(({ text, ...x }) => x),
        results: (await allRecords()).filter((x) => x.kind === "quality"),
        configuredLanguages: (process.env.NAMLENS_ANALYSIS_LANGUAGES || "")
          .split(",")
          .filter(Boolean),
      });
    const d = await req.json();
    return json(
      d.action === "evaluate"
        ? await evaluateBenchmark(d.language)
        : await addBenchmark(d),
    );
  }
  if (u.pathname === "/api/readiness") {
    requireRole(a, ["Admin"]);
    const all = await allRecords(),
      backup = await getRecord("auto-backup");
    return json({
      version: "4.3.0",
      mode: hosted ? "Hosted" : "Local",
      signIn: await authEnabled(),
      streams: all.filter((x) => x.kind === "broadcast").length,
      ffmpeg: ffmpegAvailable(),
      speech: await speechHealth(),
      analysisQueue: all
        .filter(
          (x) =>
            x.kind === "analysisTask" &&
            !["Completed", "Skipped"].includes(x.status),
        )
        .map((x) => ({ id: x.id, status: x.status, error: x.error })),
      alerts: {
        configured:
          !!process.env.NAMLENS_ALERT_URL ||
          !!(
            process.env.NAMLENS_EMAIL_KEY &&
            process.env.NAMLENS_EMAIL_FROM &&
            process.env.NAMLENS_EMAIL_TO
          ),
        emailConfigured: !!(
          process.env.NAMLENS_EMAIL_KEY &&
          process.env.NAMLENS_EMAIL_FROM &&
          process.env.NAMLENS_EMAIL_TO
        ),
        pending: all.filter(
          (x) => x.kind === "notification" && x.delivery !== "Delivered",
        ).length,
      },
      backup,
      feeds: all
        .filter((x) => x.kind === "source" && x.url)
        .map((x) => ({
          name: x.name,
          enabled: x.enabled,
          health: x.health,
          error: x.lastError,
          lastSync: x.lastSync,
        })),
      integrations: await providerStatus(),
      quality: all.filter((x) => x.kind === "quality"),
      queued: all.filter(
        (x) => x.kind === "transcription" && x.status !== "Completed",
      ).length,
    });
  }
  if (u.pathname === "/api/backup/automatic" && req.method === "POST") {
    requireRole(a, ["Admin"]);
    return json(await automaticBackup(true));
  }
  if (u.pathname === "/api/evidence") {
    if (req.method === "POST") {
      reqEdit(a);
      const form = await req.formData();
      const item = await evidence(form.get("file") as File);
      await audit(a, "Upload evidence", item.key, item.name);
      return json(item);
    }
    const key = u.searchParams.get("key") || "";
    if (!/^[a-f0-9-]{36}$/.test(key)) throw Error("404:Evidence not found");
    const meta = await getRecord("evidence-" + key);
    if (!meta || !fs.existsSync(path.join(attachmentDir, key)))
      throw Error("404:Evidence not found");
    return new Response(fs.readFileSync(path.join(attachmentDir, key)), {
      headers: {
        "Content-Type": meta.type,
        "Content-Disposition":
          'attachment; filename="' +
          meta.name.replace(/[^a-zA-Z0-9._-]/g, "_") +
          '"',
      },
    });
  }
  if (u.pathname === "/api/feeds" && req.method === "POST") {
    requireRole(a, ["Admin"]);
    const data = await req.json();
    const result = await collectSource(data.id);
    await audit(a, "Import feed", data.id, result.count + " new stories");
    return json(result);
  }
  if (u.pathname === "/api/jobs") {
    requireRole(a, ["Admin"]);
    if (req.method === "GET")
      return json({
        settings: await getRecord("monitoring-settings"),
        runs: (await allRecords())
          .filter((x) => x.kind === "job")
          .sort((a, b) => b.date.localeCompare(a.date))
          .slice(0, 20),
      });
    const data = await req.json();
    if (data.action === "settings") {
      const old = await getRecord("monitoring-settings");
      const interval =
        data.intervalMinutes === undefined
          ? old?.intervalMinutes || 60
          : Number(data.intervalMinutes);
      if (![5, 15, 30, 60, 120, 360].includes(interval))
        throw Error("Choose a supported interval");
      await putRecord({
        ...old,
        id: "monitoring-settings",
        kind: "settings",
        paused: Boolean(data.paused),
        intervalMinutes: interval,
      });
      await audit(
        a,
        "Configure schedule",
        "automation",
        "Local monitoring interval: " + interval + " minutes",
      );
      return json({ ok: true });
    }
    return json(await runMonitoringJob(a));
  }
  if (u.pathname === "/api/integrations") {
    if (req.method === "GET") return json(await providerStatus());
    requireRole(a, ["Admin"]);
    const data = await req.json();
    if (!integrations.some((p) => p.id === data.id))
      throw Error("Unknown integration");
    if (data.action === "test") {
      const result = await testProvider(data.id);
      await audit(
        a,
        "Test integration",
        data.id,
        "Provider connection checked",
      );
      return json(result);
    }
    if (data.token) {
      if (typeof data.token !== "string" || data.token.length > 10000)
        throw Error("Invalid key");
      await saveSecret(data.id, data.token);
    }
    const old = (await getRecord("integration-" + data.id)) || {};
    await putRecord({
      ...old,
      id: "integration-" + data.id,
      kind: "settings",
      enabled: Boolean(data.enabled),
      query: String(data.query || "Namibia").slice(0, 500),
      pageId: String(data.pageId || "").slice(0, 100),
    });
    await audit(
      a,
      "Configure integration",
      data.id,
      "Connection settings updated",
    );
    return json({ ok: true });
  }
  if (u.pathname === "/api/analysis" && req.method === "POST") {
    reqEdit(a);
    const d = await req.json();
    return json(await connectedAnalysis(d.text, d.language));
  }
  if (u.pathname === "/api/transcribe" && req.method === "POST") {
    reqEdit(a);
    const form = await req.formData();
    const f = form.get("file");
    if (
      !(f instanceof File) ||
      f.size > 10485760 ||
      !/^(audio|video)\//.test(f.type)
    )
      throw Error("Provide audio/video under 10 MB");
    const selected = String(form.get("language") || "English");
    const lang = speechLanguages[selected]
      ? selected
      : Object.keys(speechLanguages).find(
          (n) => speechLanguages[n] === selected,
        );
    if (!lang) throw Error("Choose the language spoken in the recording");
    const result = await transcribeBytes(
      new Uint8Array(await f.arrayBuffer()),
      f.type,
      lang,
    );
    await audit(a, "Transcribe recording", "capture", f.name);
    return json(result);
  }
  if (u.pathname === "/api/recording" && req.method === "POST") {
    reqEdit(a);
    const d = await req.json();
    const r = await publicFetch(d.url, 30000);
    if (!r.ok) throw Error("Recording URL returned " + r.status);
    const type = r.headers.get("content-type")?.split(";")[0] || "";
    if (!/^(audio|video)\//.test(type))
      throw Error("Use a direct audio/video URL");
    const bytes = await limitedBytes(r, 10485760);
    return json(
      await evidence(
        new File(
          [bytes],
          "remote-recording." + (type.startsWith("video") ? "mp4" : "mp3"),
          { type },
        ),
      ),
    );
  }
  if (u.pathname === "/api/export") {
    const report = await getRecord(u.searchParams.get("id") || "");
    if (!report || report.kind !== "report")
      throw Error("404:Report not found");
    const format = u.searchParams.get("format");
    let bytes: any, type: string;
    if (format === "docx") {
      bytes = createDocx(report);
      type =
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    } else if (format === "xlsx") {
      bytes = createXlsx(report);
      type =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    } else if (format === "pdf") {
      bytes = await createPDF(
        report,
        fs.readFileSync(path.join(publicDir, "fonts/DejaVuSans.ttf")),
      );
      type = "application/pdf";
    } else throw Error("Choose docx, xlsx or pdf");
    await audit(a, "Export report", report.id, String(format));
    return new Response(bytes, {
      headers: {
        "Content-Type": type,
        "Content-Disposition": `attachment; filename="NamLens-${report.date}.${format}"`,
      },
    });
  }
  if (u.pathname === "/api/backup" && req.method === "GET") {
    requireRole(a, ["Admin"]);
    await audit(
      a,
      "Download backup",
      "workspace",
      "Full backup including evidence, accounts and encrypted integrations",
    );
    await putRecord({
      id: "backup-settings",
      kind: "settings",
      date: new Date().toISOString(),
    });
    const entries: any = {
      "backup.json": strToU8(
        JSON.stringify({
          format: "nmo-local-v3",
          created: new Date().toISOString(),
          records: await allRecords(),
        }),
      ),
    };
    if (fs.existsSync(path.join(dataDir, "workspace.key")))
      entries["workspace.key"] = fs.readFileSync(
        path.join(dataDir, "workspace.key"),
      );
    for (const f of fs.readdirSync(attachmentDir))
      if (/^[a-f0-9-]{36}$/.test(f))
        entries["evidence/" + f] = fs.readFileSync(path.join(attachmentDir, f));
    return new Response(zipSync(entries), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition":
          'attachment; filename="NamLens-backup-' + localDay() + '.zip"',
      },
    });
  }
  if (u.pathname === "/api/restore" && req.method === "POST") {
    requireRole(a, ["Admin"]);
    if (
      captureRunning.size ||
      (await allRecords()).some(
        (x) => x.kind === "transcription" && x.status === "Processing",
      )
    )
      throw Error("Pause streams and wait for transcription before restoring");
    if (
      (await getRecord("monitoring-job-lock")) &&
      (await getRecord("monitoring-job-lock"))?.expires >
        new Date().toISOString()
    )
      throw Error("Wait for monitoring to finish before restoring");
    const form = await req.formData(),
      file = form.get("file");
    if (!(file instanceof File) || file.size > 64 * 1024 * 1024)
      throw Error("Choose an NMO backup ZIP below 64 MB");
    const raw = Buffer.from(await file.arrayBuffer());
    let inflated = 0;
    const zip = unzipSync(raw, {
      filter: (e: any) => {
        inflated += e.originalSize;
        if (inflated > 200 * 1024 * 1024)
          throw Error("Backup expands beyond 200 MB");
        if (
          !["backup.json", "workspace.key"].includes(e.name) &&
          !/^evidence\/[a-f0-9-]{36}$/.test(e.name)
        )
          throw Error("Unexpected backup entry");
        return true;
      },
    });
    if (!zip["backup.json"]) throw Error("This is not an NMO backup");
    const backup = JSON.parse(strFromU8(zip["backup.json"]));
    if (
      backup.format !== "nmo-local-v3" ||
      !Array.isArray(backup.records) ||
      backup.records.length > 100000
    )
      throw Error("Invalid backup format");
    if (
      hosted &&
      !backup.records.some(
        (x: any) => x.id === "auth-" + owner.email && x.hash && x.salt,
      )
    )
      throw Error(
        "Hosted restore requires a password account matching the configured owner email",
      );
    const ids = new Set();
    for (const item of backup.records) {
      if (
        typeof item.id !== "string" ||
        typeof item.kind !== "string" ||
        ids.has(item.id)
      )
        throw Error("Invalid backup record");
      ids.add(item.id);
    }
    if (
      backup.records.some((x: any) => x.kind === "secret") &&
      zip["workspace.key"]?.length !== 32
    )
      throw Error("Backup encryption key missing");
    for (const x of backup.records.filter((x: any) => x.kind === "evidence"))
      if (!zip["evidence/" + x.key])
        throw Error("Backup attachment is missing");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const recovery = path.join(dataDir, "before-restore-" + stamp);
    fs.mkdirSync(recovery);
    db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    fs.copyFileSync(
      path.join(dataDir, "observatory.sqlite"),
      path.join(recovery, "observatory.sqlite"),
    );
    if (fs.existsSync(path.join(dataDir, "workspace.key")))
      fs.copyFileSync(
        path.join(dataDir, "workspace.key"),
        path.join(recovery, "workspace.key"),
      );
    fs.cpSync(attachmentDir, path.join(recovery, "evidence"), {
      recursive: true,
    });
    const staging = path.join(
      dataDir,
      "restore-staging-" + crypto.randomUUID(),
    );
    fs.mkdirSync(path.join(staging, "evidence"), { recursive: true });
    try {
      for (const [name, bytes] of Object.entries(zip))
        if (name !== "backup.json") {
          const dest = path.join(staging, name);
          fs.mkdirSync(path.dirname(dest), { recursive: true });
          fs.writeFileSync(dest, bytes as Uint8Array);
        }
      db.exec("BEGIN");
      try {
        db.exec("DELETE FROM records");
        for (const item of backup.records) await putRecord(item);
        fs.rmSync(attachmentDir, { recursive: true, force: true });
        fs.renameSync(path.join(staging, "evidence"), attachmentDir);
        fs.rmSync(path.join(dataDir, "workspace.key"), { force: true });
        if (fs.existsSync(path.join(staging, "workspace.key")))
          fs.renameSync(
            path.join(staging, "workspace.key"),
            path.join(dataDir, "workspace.key"),
          );
        db.exec("COMMIT");
      } catch (e) {
        db.exec("ROLLBACK");
        fs.rmSync(attachmentDir, { recursive: true, force: true });
        fs.cpSync(path.join(recovery, "evidence"), attachmentDir, {
          recursive: true,
        });
        fs.rmSync(path.join(dataDir, "workspace.key"), { force: true });
        if (fs.existsSync(path.join(recovery, "workspace.key")))
          fs.copyFileSync(
            path.join(recovery, "workspace.key"),
            path.join(dataDir, "workspace.key"),
          );
        throw e;
      }
    } finally {
      fs.rmSync(staging, { recursive: true, force: true });
    }
    await putRecord({
      id: "monitoring-job-lock",
      kind: "settings",
      expires: new Date(0).toISOString(),
    });
    sessions.clear();
    await loadOwner();
    await audit(
      a,
      "Restore backup",
      "workspace",
      "Prior data preserved in " + path.basename(recovery),
    );
    return json({
      ok: true,
      message:
        "Restored. Reload and sign in with the accounts from the backup.",
    });
  }
  throw Error("404:Endpoint not found");
}
const mime: any = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".wasm": "application/wasm",
  ".gz": "application/gzip",
  ".ttf": "font/ttf",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json",
  ".json": "application/json",
};
function staticResponse(name: string) {
  let decoded;
  try {
    decoded = decodeURIComponent(name);
  } catch {
    return new Response("Bad path", { status: 400 });
  }
  if (
    ["/", "/guide", "/login", "/register", "/signin-with-chatgpt"].includes(
      decoded,
    )
  )
    decoded = "/index.html";
  const target = path.resolve(publicDir, "." + decoded);
  if (
    !target.startsWith(publicDir + path.sep) ||
    !fs.existsSync(target) ||
    !fs.statSync(target).isFile()
  )
    return new Response("Not found", { status: 404 });
  return new Response(fs.readFileSync(target), {
    headers: {
      "Content-Type": mime[path.extname(target)] || "application/octet-stream",
      "Cache-Control": "no-cache",
    },
  });
}
function openBrowser(url: string) {
  if (process.env.NMO_NO_BROWSER === "1") return;
  try {
    let child;
    if (process.platform === "win32")
      child = spawn("rundll32.exe", ["url.dll,FileProtocolHandler", url], {
        stdio: "ignore",
        detached: true,
      });
    else
      child = spawn(
        process.platform === "darwin" ? "open" : "xdg-open",
        [url],
        { stdio: "ignore", detached: true },
      );
    child.on("error", () =>
      console.log("Open this address in your browser: " + url),
    );
    child.unref();
  } catch {
    console.log("Open this address in your browser: " + url);
  }
}
let runningPort = 0;
const server = http.createServer(async (incoming, out) => {
  try {
    const host = incoming.headers.host || "";
    if (hosted) {
      if (
        ![
          new URL(origin).host,
          "127.0.0.1:" + runningPort,
          "localhost:" + runningPort,
        ].includes(host)
      )
        throw Error("403:Invalid host");
    } else if (
      !["127.0.0.1:" + runningPort, "localhost:" + runningPort].includes(host)
    )
      throw Error("403:Invalid local host");
    const url = (hosted ? origin : "http://" + host) + (incoming.url || "/");
    incoming.headers["x-namlens-peer"] =
      process.env.NAMLENS_TRUST_PROXY === "1"
        ? String(
            incoming.headers["x-forwarded-for"] ||
              incoming.socket.remoteAddress,
          ).split(",")[0]
        : incoming.socket.remoteAddress;
    let body: Buffer | undefined;
    if (!["GET", "HEAD"].includes(incoming.method || "GET")) {
      const chunks: Buffer[] = [];
      let n = 0;
      for await (const chunk of incoming) {
        n += chunk.length;
        if (n > 70 * 1024 * 1024) throw Error("413:Request exceeds 70 MB");
        chunks.push(chunk);
      }
      body = Buffer.concat(chunks);
    }
    const req = new Request(url, {
      method: incoming.method,
      headers: incoming.headers as any,
      ...(body ? { body: new Uint8Array(body).buffer } : {}),
    });
    const res = await handle(req);
    out.writeHead(res.status, {
      "Cache-Control": "no-store",
      ...(hosted ? { "Strict-Transport-Security": "max-age=31536000" } : {}),
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "same-origin",
      "X-Frame-Options": "DENY",
      "Cross-Origin-Opener-Policy": "same-origin",
      "Content-Security-Policy":
        "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; media-src 'self' blob:; worker-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'",
      ...Object.fromEntries(res.headers.entries()),
    });
    if (incoming.method === "HEAD") out.end();
    else out.end(Buffer.from(await res.arrayBuffer()));
  } catch (e: any) {
    const r = apiError(e);
    out.writeHead(r.status, {
      "Content-Type": "application/json",
      "X-Content-Type-Options": "nosniff",
    });
    out.end(await r.text());
  }
});
server.requestTimeout = 120000;
async function listen(port: number) {
  return new Promise<boolean>((resolve, reject) => {
    const onError = (e: any) => {
      server.off("listening", onListen);
      if (e.code === "EADDRINUSE") resolve(false);
      else reject(e);
    };
    const onListen = () => {
      server.off("error", onError);
      runningPort = port;
      resolve(true);
    };
    server.once("error", onError);
    server.once("listening", onListen);
    server.listen(port, hosted ? "0.0.0.0" : "127.0.0.1");
  });
}
const requested = Number(process.env.PORT || process.env.NMO_PORT || 8765);
if (!Number.isInteger(requested) || requested < 1024 || requested > 65500)
  throw Error("Invalid NMO_PORT");
for (let port = requested; port < requested + (hosted ? 1 : 20); port++) {
  if (await listen(port)) break;
  try {
    const r = await fetch("http://127.0.0.1:" + port + "/api/health", {
      signal: AbortSignal.timeout(700),
    });
    const h = await r.json();
    if (h.project === project && h.app === "namlens-v4") {
      console.log("Your system is already running. Opening it.");
      openBrowser("http://127.0.0.1:" + port);
      db.close();
      process.exit(0);
    }
  } catch {}
}
if (!runningPort) throw Error("Port unavailable");
await initialise();
if (hosted) {
  if (!(await getRecord("auth-" + owner.email)))
    await putRecord({
      id: "auth-" + owner.email,
      kind: "auth",
      ...hashPassword(process.env.NAMLENS_ADMIN_PASSWORD!),
    });
  await putRecord({ id: "local-auth", kind: "settings", enabled: true });
}
await recoverCaptureJobs();
await recoverAnalysis();
console.log("\n NAM LENS — MEDIA MONITORING\n");
console.log(" READY: " + (hosted ? origin : "http://127.0.0.1:" + runningPort));
console.log(" Your records are saved automatically in the data folder.");
console.log(" Keep this window open. Press Ctrl+C to stop.\n");
if (!hosted) openBrowser("http://127.0.0.1:" + runningPort);
let schedulerBusy = false;
async function tick() {
  if (schedulerBusy) return;
  const settings = await getRecord("monitoring-settings");
  if (settings?.paused) return;
  const last = await getRecord("local-last-run");
  if (
    last?.date &&
    Date.now() - Date.parse(last.date) <
      (settings?.intervalMinutes || 60) * 60000
  )
    return;
  schedulerBusy = true;
  try {
    await putRecord({
      id: "local-last-run",
      kind: "settings",
      date: new Date().toISOString(),
    });
    await runMonitoringJob();
  } catch (e: any) {
    console.error("Monitoring:", e.message);
  } finally {
    schedulerBusy = false;
  }
}
async function maintain() {
  const results = await Promise.allSettled([
    broadcastTick(),
    transcriptionTick(),
    analysisTick(),
    deliveryTick(),
    automaticBackup(),
  ]);
  for (const result of results)
    if (result.status === "rejected")
      console.error(
        "Maintenance:",
        result.reason?.message || "Operation failed",
      );
}
const maintenanceInterval = setInterval(() => maintain(), 20000);
setTimeout(() => maintain(), 1000);
const interval = setInterval(
  () => tick().catch((e) => console.error(e.message)),
  60000,
);
setTimeout(() => tick().catch((e) => console.error(e.message)), 2500);
for (const signal of ["SIGINT", "SIGTERM"] as const)
  process.on(signal, () => {
    clearInterval(interval);
    clearInterval(maintenanceInterval);
    stopCaptures();
    server.close();
    db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    db.close();
    process.exit(0);
  });
