// Run with the app stopped and private filesystem access. Never expose as an HTTP endpoint.
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import {randomBytes,scryptSync} from 'node:crypto';
const dir=path.resolve(process.env.NMO_DATA_DIR||'data'),file=path.join(dir,'observatory.sqlite');
if(!fs.existsSync(file))throw Error('No workspace database found. Set NMO_DATA_DIR to the existing persistent data directory.');
const ownerDB=new DatabaseSync(file);let saved;try{const row=ownerDB.prepare("SELECT data FROM records WHERE id='workspace-owner'").get();saved=row?JSON.parse(row.data):null}finally{ownerDB.close()}
const email=(process.env.NAMLENS_ADMIN_EMAIL||saved?.email||'owner@namibia.local').toLowerCase(),password=randomBytes(20).toString('base64url'),salt=randomBytes(16).toString('hex');
const db=new DatabaseSync(file),date=new Date().toISOString();
const save=(id,kind,data)=>db.prepare('INSERT INTO records VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,data=excluded.data,updatedAt=excluded.updatedAt').run(id,kind,JSON.stringify(data),date);
try{db.exec('BEGIN');if(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='auth_sessions'").get())db.prepare('DELETE FROM auth_sessions WHERE email=?').run(email);save('auth-'+email,'auth',{salt,hash:scryptSync(password,salt,32).toString('hex')});save('local-auth','settings',{enabled:true});save(randomBytes(16).toString('hex'),'audit',{actor:'Filesystem administrator',role:'Admin',action:'Recover owner account',email,date,target:'owner',details:'Password reset with server-side filesystem access'});fs.writeFileSync(path.join(dir,'owner-recovery.txt'),'Owner: '+email+'\nTemporary password: '+password+'\nSign in, change the password in Settings and delete this file.\n',{mode:0o600});db.exec('COMMIT');console.log('Owner recovery complete. Read the private owner-recovery.txt in your data folder.');}catch(e){db.exec('ROLLBACK');throw e;}finally{db.close();}
