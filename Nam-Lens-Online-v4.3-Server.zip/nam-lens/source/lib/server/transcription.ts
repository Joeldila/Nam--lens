import fs from "node:fs";
import path from "node:path";
import { getRecord, putRecord, dataDir } from "./store";
import { readSecret, saveSecret } from "./secrets";
import { publicFetch, publicURL, limitedBytes } from "./network";
export const speechLanguages: Record<string, string> = {
  English: "en",
  German: "de",
  Afrikaans: "af",
  Oshiwambo: "oshiwambo",
  Oshindonga: "ndo",
  Oshikwanyama: "kua",
  Otjiherero: "her",
  Khoekhoegowab: "naq",
  Rukwangali: "kwn",
  Silozi: "loz",
  Setswana: "tsn",
  Other: "other",
};
async function config() {
  if (process.env.NAMLENS_SPEECH_URL)
    return {
      url: process.env.NAMLENS_SPEECH_URL,
      token: process.env.NAMLENS_SPEECH_TOKEN || "",
      trusted: true,
    };
  const saved = await getRecord("speech-settings");
  if (saved && !saved.enabled) return null;
  let local: any = null;
  try {
    const c = JSON.parse(
      fs.readFileSync(path.join(dataDir, "speech-connection.json"), "utf8"),
    );
    if (c.url === "http://127.0.0.1:8876") local = c;
  } catch {}
  if (saved?.enabled)
    return {
      url: saved.url,
      token:
        (await readSecret("speech")) ||
        (localURL(saved.url) ? local?.token || "" : ""),
      trusted: false,
    };
  if (local) return { ...local, trusted: false };
  return null;
}
function localURL(url: string) {
  return new URL(url).origin === "http://127.0.0.1:8876";
}
async function call(c: any, endpoint: string, options: any = {}) {
  const url = new URL(endpoint, c.url);
  const headers = { Authorization: "Bearer " + c.token, ...options.headers };
  if (c.trusted || localURL(c.url))
    return fetch(url, {
      ...options,
      headers,
      redirect: "error",
      signal: AbortSignal.timeout(options.method === "POST" ? 300000 : 4000),
    });
  return publicFetch(url, options.method === "POST" ? 300000 : 4000, {
    ...options,
    headers,
  });
}
async function health(c: any) {
  const r = await call(c, "/health");
  if (!r.ok)
    throw Error("Speech connection could not be reached (" + r.status + ")");
  const j: any = JSON.parse(
    Buffer.from(await limitedBytes(r, 50000)).toString(),
  );
  return {
    loaded: !!j.loaded,
    provider: String(j.provider || "Connected speech engine").slice(0, 120),
    languages: Array.isArray(j.languages)
      ? j.languages.filter((x: any) => typeof x === "string").slice(0, 30)
      : ["en", "af", "de"],
    experimental: Array.isArray(j.experimental) ? j.experimental : [],
  };
}
export async function configureSpeech(d: any) {
  if (d.action === "disconnect") {
    await putRecord({
      id: "speech-settings",
      kind: "settings",
      enabled: false,
    });
    return { ok: true };
  }
  const url = String(d.url || "").trim();
  if (!localURL(url)) publicURL(url);
  if (d.token) {
    if (typeof d.token !== "string" || d.token.length > 10000)
      throw Error("Invalid connection key");
    await saveSecret("speech", d.token);
  }
  await putRecord({
    id: "speech-settings",
    kind: "settings",
    url,
    enabled: true,
  });
  const c = await config();
  const result = await health(c);
  return { ok: true, ...result };
}
export async function speechStatus() {
  let c = await config(),
    h: any = null,
    error = "";
  if (c)
    try {
      h = await health(c);
    } catch (e: any) {
      error = e.message;
    }
  const dg = await getRecord("integration-deepgram"),
    hasDeepgram = !!dg?.enabled && !!(await readSecret("deepgram"));
  return {
    configured: !!c || hasDeepgram,
    connected: !!h || hasDeepgram,
    url: c?.url || "http://127.0.0.1:8876",
    status: h
      ? h.loaded
        ? "Ready"
        : "Ready; first recording loads the model"
      : hasDeepgram
        ? "Deepgram connected"
        : c
          ? "Speech engine unavailable"
          : "No AI speech connection",
    error,
    languages: Object.entries(speechLanguages).map(([name, code]) => ({
      name,
      code,
      available: h
        ? h.languages.includes(code)
        : hasDeepgram && ["en", "af", "de"].includes(code),
      experimental: !!h?.experimental.includes(code),
      provider: h?.provider || (hasDeepgram ? "Deepgram" : ""),
    })),
  };
}
export async function transcribeBytes(
  bytes: Uint8Array,
  type: string,
  language: string,
) {
  const code = speechLanguages[language];
  if (!code) throw Error("Choose the language spoken in the recording");
  let r: Response,
    provider = "",
    experimental = false;
  const c = await config();
  if (c) {
    const h = await health(c);
    if (!h.languages.includes(code))
      throw Error(
        language +
          " does not have an AI engine connected yet. Listen and enter its transcript in Language studio.",
      );
    const form = new FormData();
    form.append(
      "file",
      new File([new Uint8Array(bytes)], "recording.media", { type }),
    );
    form.append("language", code);
    const encoded = new Response(form);
    r = await call(c, "/transcribe", {
      method: "POST",
      headers: { "Content-Type": encoded.headers.get("content-type")! },
      body: new Uint8Array(await encoded.arrayBuffer()),
    });
    provider = h.provider;
    experimental = h.experimental.includes(code);
  } else {
    const cfg = await getRecord("integration-deepgram"),
      token = await readSecret("deepgram");
    if (!cfg?.enabled || !token || !["en", "af", "de"].includes(code))
      throw Error(
        "No AI speech engine is connected for " +
          language +
          ". You can still listen and enter a transcript.",
      );
    r = await fetch(
      "https://api.deepgram.com/v1/listen?model=nova-3&smart_format=true&diarize=true&language=" +
        code,
      {
        method: "POST",
        headers: { Authorization: "Token " + token, "Content-Type": type },
        body: new Uint8Array(bytes),
        signal: AbortSignal.timeout(90000),
      },
    );
    provider = "Deepgram";
  }
  if (!r.ok)
    throw Error(
      "The speech engine could not process this recording (" +
        r.status +
        "). Try a shorter clip or enter the transcript.",
    );
  const j: any = JSON.parse(
      Buffer.from(await limitedBytes(r, 2000000)).toString(),
    ),
    alt = j.results?.channels?.[0]?.alternatives?.[0],
    text = String(j.text || alt?.transcript || "").trim();
  if (!text) throw Error("No speech detected. Try a clearer recording.");
  const segments = (Array.isArray(j.segments) ? j.segments : [])
    .slice(0, 1000)
    .filter(
      (s: any) =>
        Number.isFinite(s.start) &&
        Number.isFinite(s.end) &&
        s.start >= 0 &&
        s.end >= s.start,
    )
    .map((s: any) => ({
      start: s.start,
      end: s.end,
      text: String(s.text || "").slice(0, 6000),
    }));
  return {
    text: text.slice(0, 60000),
    confidence: typeof alt?.confidence === "number" ? alt.confidence : null,
    words: (alt?.words || []).slice(0, 10000),
    segments,
    provider,
    experimental,
    language,
    reviewed: false,
  };
}
export async function speechHealth() {
  const s = await speechStatus();
  return { configured: s.configured, status: s.status, error: s.error };
}
