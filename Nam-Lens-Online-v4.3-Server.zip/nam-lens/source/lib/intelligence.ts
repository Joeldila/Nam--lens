export function summarise(text: string, max = 480) {
  const clean = text.replace(/\s+/g, " ").trim();
  const first =
    clean
      .match(/[^.!?]+[.!?]+(?:\s|$)/g)
      ?.slice(0, 3)
      .join(" ") || clean;
  return first.length > max ? first.slice(0, max - 1) + "…" : first;
}
export function tagEntities(story: any, entities: any[]) {
  const text = (story.title + " " + story.body).toLowerCase();
  return entities
    .filter((e) =>
      [e.name, ...(e.aliases || "").split(",")]
        .filter(Boolean)
        .some((n) => text.includes(n.trim().toLowerCase())),
    )
    .map((e) => e.name);
}
const stops = new Set(
  "the a an and of to in for on with at by from as is are over new local after".split(
    " ",
  ),
);
function words(s: string) {
  return new Set(
    s
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[^a-z0-9 ]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !stops.has(w)),
  );
}
export function duplicateGroups(stories: any[]) {
  const parent = stories.map((_, i) => i);
  const root = (i: number): number =>
    parent[i] === i ? i : (parent[i] = root(parent[i]));
  for (let i = 0; i < stories.length; i++)
    for (let j = i + 1; j < stories.length; j++) {
      if (
        Math.abs(Date.parse(stories[i].date) - Date.parse(stories[j].date)) >
        7 * 86400000
      )
        continue;
      const a = words(stories[i].title),
        b = words(stories[j].title);
      if (a.size < 3 || b.size < 3) continue;
      const common = [...a].filter((w) => b.has(w)).length;
      const sim = common / (a.size + b.size - common);
      if (sim >= 0.65) parent[root(j)] = root(i);
    }
  const out: Record<string, any[]> = {};
  stories.forEach((s, i) => {
    const r = root(i);
    (out[r] ??= []).push(s);
  });
  return Object.values(out)
    .filter((g) => g.length > 1)
    .map((g) => ({
      id: g.map((s) => s.id).sort()[0],
      title: g[0].title,
      stories: g,
      sources: new Set(g.map((s) => s.source)).size,
    }));
}
export function topicTrends(stories: any[], now = Date.now()) {
  const fresh = stories.filter(
    (s) =>
      !s.sample &&
      now - Date.parse(s.date) >= 0 &&
      now - Date.parse(s.date) < 86400000,
  );
  const previous = stories.filter(
    (s) =>
      !s.sample &&
      now - Date.parse(s.date) >= 86400000 &&
      now - Date.parse(s.date) < 7 * 86400000,
  );
  const topics = [...new Set(fresh.map((s) => s.topic))];
  return topics
    .map((topic) => {
      const current = fresh.filter((s) => s.topic === topic).length;
      const baseline = previous.filter((s) => s.topic === topic).length / 6;
      return {
        topic,
        current,
        baseline: Number(baseline.toFixed(2)),
        change: baseline
          ? Math.round(((current - baseline) / baseline) * 100)
          : null,
        emerging: current >= 3 && (baseline === 0 || current >= baseline * 2),
      };
    })
    .sort((a, b) => b.current - a.current);
}
export function enrich(story: any, entities: any[] = []) {
  return {
    ...story,
    summary: story.summary?.trim() || summarise(story.body || ""),
    entities: tagEntities(story, entities),
    institutions: Array.isArray(story.institutions)
      ? story.institutions
      : (story.institutions || "")
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean),
    approval: story.approval || "Draft",
  };
}
export function namibiaDay(date: string | Date = new Date()) {
  return new Date(date).toLocaleDateString("en-CA", {
    timeZone: "Africa/Windhoek",
  });
}
export function reportRecords(stories: any[], date: string) {
  return stories.filter((s) => namibiaDay(s.date) === date);
}
export function buildBriefing(stories: any[], date: string) {
  const selected = reportRecords(stories, date).map((s) => ({ ...s }));
  const parts = [
    `NAM LENS\nDAILY MONITORING REPORT — ${date}\n`,
    `${selected.length} records; ${new Set(selected.map((s) => s.source)).size} sources; ${selected.filter((s) => s.sample).length} fictional samples.\nSentiment: ${["Positive", "Negative", "Neutral", "Unclassified"].map((k) => `${k} ${selected.filter((s) => s.sentiment === k).length}`).join(" | ")}.\n`,
    ...selected.map(
      (s, i) =>
        `${i + 1}. ${s.sample ? "[FICTIONAL SAMPLE] " : ""}${s.title}\n${s.channel} | ${s.source} | ${s.language} | ${s.region}\n${s.channel === "Print" ? "Page: " + (s.pageNumber || "Not recorded") : ["Radio", "Television"].includes(s.channel) ? `Programme: ${s.programme || "Not recorded"} | Presenter: ${s.presenter || "Not recorded"} | Time: ${s.broadcastTime || "Not recorded"}` : "Link: " + (s.url || "Not recorded")}\nSummary: ${s.summary || summarise(s.body)}\nQuoted source: ${s.quotedPerson || "Not recorded"}${s.quotedRole ? " — " + s.quotedRole : ""} | Statement: ${s.statementType || "Not recorded"}\nInstitutions: ${(s.institutions || []).join(", ") || "Not recorded"}\nSentiment: ${s.sentiment} | Priority: ${s.risk} | Verification: ${s.verification} | Approval: ${s.approval || "Draft"}\nRecommendation: ${s.recommendation || "No recommendation recorded"}\nAnalyst notes: ${s.notes || "None"}\n`,
    ),
    `METHOD: Recorded media coverage only. English/Afrikaans/German lexicon suggestions and any connected model output require human review. Other languages are unclassified unless reviewed. Duplicate groupings and trend flags are suggestions. Criticism is not evidence of misinformation. Samples are fictional.`,
  ];
  return {
    title: "Daily monitoring report",
    date,
    created: new Date().toISOString(),
    content: parts.join("\n"),
    items: selected,
    count: selected.length,
    samples: selected.filter((s) => s.sample).length,
    approval: "Draft",
  };
}
