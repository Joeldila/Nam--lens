# Nam Lens 4.3: online preparation status

The original server app is prepared for shared online hosting, with persistent accounts, hashed saved login sessions, background monitoring and public-feed addresses for The Namibian and NBC Digital News. Hosted-mode tests passed; exact source-processing transport limits are in HOSTED-TEST-RESULTS.md.

No Render service has been created, no public URL has been verified and no hosting charges have been incurred. The Render account is not connected in this conversation. A privately stored deployable image and cost approval are also required for the selected no-GitHub route.

The local 4.2 app remains separate. Speech-model, live-station, restricted social-account and delivery connections remain their own setup steps. The optional Oshiwambo model is experimental.

See ONLINE-SETUP.txt, HOSTED-TEST-RESULTS.md and TEST-RESULTS.md.
