import React from "react";
import { createRoot } from "react-dom/client";
import Home from "./app/page";
import Boot from "./components/boot";
createRoot(document.getElementById("root")!).render(
  <Boot>
    <Home />
  </Boot>,
);
