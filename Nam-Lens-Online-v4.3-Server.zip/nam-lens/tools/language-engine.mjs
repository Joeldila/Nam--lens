import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {spawn,spawnSync} from 'node:child_process';import {randomBytes} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');process.chdir(root);
const dataDir=path.resolve(process.env.NMO_DATA_DIR||'data');fs.mkdirSync(dataDir,{recursive:true});
let python=null;
for(const [cmd,args] of [['py',['-3']],['python3',[]],['python',[]]]){const r=spawnSync(cmd,[...args,'-c','import sys;print(sys.version_info.major,sys.version_info.minor)'],{encoding:'utf8'});if(r.status===0&&/^3 (10|11|12)\s*$/.test(r.stdout)){python={cmd,args};break;}}
if(!python){console.error('This optional language engine needs Python 3.10, 3.11 or 3.12. Install Python 3.12 from https://www.python.org/downloads/ and run this file again. The main Nam Lens app works without it.');process.exit(1)}
const venv=path.join(root,'.language-env'),exe=path.join(venv,process.platform==='win32'?'Scripts/python.exe':'bin/python');
async function run(cmd,args,env={}){await new Promise((resolve,reject)=>{const child=spawn(cmd,args,{stdio:'inherit',env:{...process.env,...env}});child.on('error',reject);child.on('exit',c=>c===0?resolve():reject(Error('Language engine stopped. See the message above.')));process.on('SIGINT',()=>child.kill('SIGINT'))})}
try{
 if(!fs.existsSync(exe))await run(python.cmd,[...python.args,'-m','venv',venv]);
 const marker=path.join(venv,'namlens-ready-v42');
 if(!fs.existsSync(marker)){console.log('Installing the optional AI engine. The first setup needs internet, disk space and may take several minutes.');await run(exe,['-m','pip','install','--index-url','https://download.pytorch.org/whl/cpu','torch>=2.6,<3']);await run(exe,['-m','pip','install','-r',path.join(root,'speech-worker/requirements.txt')]);fs.writeFileSync(marker,'4.2')}
 const configPath=path.join(dataDir,'speech-connection.json');let config;try{config=JSON.parse(fs.readFileSync(configPath,'utf8'))}catch{config={url:'http://127.0.0.1:8876',token:randomBytes(32).toString('hex')}}fs.writeFileSync(configPath,JSON.stringify(config),{mode:0o600});
 console.log('Nam Lens language engine is opening. Keep this window open. The experimental Oshiwambo model downloads on first use and needs fluent-speaker review.');
 await run(exe,['-m','uvicorn','app:app','--app-dir',path.join(root,'speech-worker'),'--host','127.0.0.1','--port','8876'],{ORT_DISABLE_TELEMETRY:'1',HF_HUB_DISABLE_TELEMETRY:'1',NAMLENS_SPEECH_TOKEN:config.token,NAMLENS_OSHIWAMBO_EXPERIMENT:'1',HF_HOME:path.join(dataDir,'speech-models')});
}catch(e){console.error(e.message);process.exitCode=1}
