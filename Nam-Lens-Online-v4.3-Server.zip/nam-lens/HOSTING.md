# Host Nam Lens online

This package runs the same prebuilt app locally or on a host. You do not need to install its JavaScript packages or run a framework build. Hosting is a separate operation that requires your own account. This updated edition is not currently deployed to an external host.

Prices below were checked against official provider pages on 11 October 2026, in USD. Taxes, a purchased domain, API usage, extra storage and bandwidth are additional where applicable. These are starting configurations, not guarantees of national-scale recording capacity.

| Route | Starting cost | What it suits |
|---|---:|---|
| Oracle Cloud Always Free eligible ARM server | US$0 within its allocation | Possible free pilot with persistent storage. Availability is not guaranteed; account verification, server setup and ARM worker validation are required. Idle instances may be reclaimed. |
| Render Starter + a 5 GB persistent disk | US$8.25/month ($7 + $1.25) | Simple hosted dashboard, shared accounts, RSS, reports and external speech APIs. 512 MB RAM is not suitable for the bundled local speech worker; substantial capture needs more capacity. |
| DigitalOcean Basic 2 CPU / 4 GB / 80 GB | US$24/month | Starting pilot for app, FFmpeg and limited local speech processing. Measure throughput, storage and reliability before extending coverage. |

Render's free web service cannot preserve this app's SQLite database and evidence files across restarts. It also sleeps after inactivity. Use a persistent paid disk for real records. Do not select a Static Site service: this app has a backend and scheduled jobs.

## Straightforward managed setup: Render

1. Create a private GitHub repository and upload the contents of the **nam-lens** folder. `Dockerfile`, `render.yaml`, `server.mjs` and `public` must be at the repository root. Upload extracted files, not the ZIP. Never upload a runtime `data` folder or a real `.env` file. The GitHub browser uploader has file limits; the supplied prebuilt files are below its individual 25 MB limit.
2. Sign in at https://render.com and choose **New > Blueprint**. Connect that repository and select its `render.yaml`.
3. Render asks for `NAMLENS_ADMIN_EMAIL` and `NAMLENS_ADMIN_PASSWORD`. Use your own email and a strong password of at least 12 characters. These are this app's credentials, not your email account password.
4. Review the Starter service and 5 GB disk charges, then deploy. This creates a paid service when you confirm it on Render. The app automatically uses Render's HTTPS URL and port. No custom domain is required.
5. Open the exact service URL displayed by Render. Sign in with the owner email and password you entered. In Service status, check sign-in, the database snapshot and connection results.
6. Add source feeds and enabled provider keys in the app. A source is operational only after an import/test succeeds. Broadcast desk accepts direct HTTPS streams and HLS playlists, not a website page or a YouTube watch link.

A fresh hosted workspace contains a source directory, but no fictional news stories. Two public news feeds are initially enabled in hosted mode; their actual access depends on the host/network and is shown in source health. Local mode starts with labelled illustrative stories and disabled public feeds.

For a custom domain later, set `NAMLENS_PUBLIC_URL` to the exact HTTPS URL, redeploy, and configure that domain through Render. Only the configured origin and loopback health requests are accepted. Keep one web instance: independent replicas must not share this SQLite store.

The owner password environment variable only creates a missing owner account. After changing the password in the app, use the new password. Changing the hosting variable alone does not overwrite an existing account. To reset a forgotten password, stop the app and use `node hosting/reset-owner.mjs` against its persistent data, or use the included maintenance container command documented below.

## Full recording pilot: Ubuntu VPS + Docker

This route has more server administration than Render. The package's Docker image includes FFmpeg automatically. The application still needs working station stream URLs and a supported speech service.

1. Create a suitable Ubuntu server at your chosen host. On Oracle choose an Always Free eligible shape/allocation and verify it shows free eligibility before creating it. Read the capacity and reclamation limits in the official documentation. ARM speech dependencies have not been tested here.
2. Install Docker Engine and the Docker Compose plugin using https://docs.docker.com/engine/install/ubuntu/.
3. Point a domain's DNS A record to the server's public IP. Make ports 80 and 443 reachable in the host's network rules and Ubuntu firewall. The app and speech worker ports stay private. A domain may have a separate yearly charge.
4. Copy the extracted **nam-lens** folder to the server and open a terminal in that folder. Run:

   ```bash
   node hosting/configure.mjs
   ```

   This asks for the domain and owner email, generates a strong initial password and creates `.env`. Retrieve the password privately from that file. If Node is not installed on the host, copy `.env.example` to `.env` and enter the domain, HTTPS URL, owner email, owner password and a random speech token manually. The app itself uses Node inside Docker.

5. Start:

   ```bash
   docker compose up -d --build
   ```

6. Open `https://` followed by your actual domain. Caddy obtains the HTTPS certificate automatically when the domain resolves correctly and its required ports are reachable. Use your configured owner account.
7. Inspect startup failures with `docker compose logs app` or `docker compose logs https`. Do not post logs containing credentials publicly.

Never expose port 8765 or speech port 8000 directly. There is one app process, persistent named volumes and automatic container restart after server restarts. Do not run `docker compose down -v`: that deletes the data volumes.

### Optional local speech worker

1. In `.env` add `NAMLENS_SPEECH_URL=http://speech:8000`. Keep the generated `NAMLENS_SPEECH_TOKEN`.
2. Run:

   ```bash
   docker compose --profile speech up -d --build
   ```

The first transcription downloads a Whisper model and can take longer. The default tiny model trades accuracy for lower cost and must be evaluated with representative recordings. The worker currently enables English, Afrikaans and German only. It is private, authenticated and processes one recording at a time. It is not a validated engine for all Namibian languages. The actual model download, Docker build and ARM execution were not verified in this session.

For managed transcription instead, leave `NAMLENS_SPEECH_URL` unset and connect Deepgram in Integrations. Provider charges apply separately. Review the provider's current language/plan support.

### Notifications outside the browser

Set `NAMLENS_ALERT_URL` to a public HTTPS webhook belonging to your notification service. Optionally set `NAMLENS_ALERT_TOKEN`. The app posts JSON:

```json
{"id":"notification-id","app":"Nam Lens","type":"Priority signal","title":"Story headline","date":"ISO timestamp","storyId":"story-id"}
```

Use an adapter if a service such as Telegram, email or Slack requires a different request schema. A generic webhook does not automatically send email or SMS. Direct crisis email is also implemented through Resend: set `NAMLENS_EMAIL_KEY`, a verified `NAMLENS_EMAIL_FROM`, and 1–10 comma-separated authorised recipients in `NAMLENS_EMAIL_TO` on the host. Retries use provider idempotency keys, and each channel records acceptance separately. Provider acceptance does not prove inbox arrival. SMS still requires a suitable webhook adapter. Do not put secrets in a public repository. It retries failed deliveries up to five times and records the result. Its receiver should deduplicate on `id`; delivery is at least once. Browser pop-ups still need an open page and browser permission.

### Language service and accuracy

An administrator can connect an independent language service using `NAMLENS_ANALYSIS_URL`, `NAMLENS_ANALYSIS_TOKEN` and comma-separated `NAMLENS_ANALYSIS_LANGUAGES`. It accepts JSON `{text,language}` and returns `{sentiment,confidence}`. Allowed sentiment values are Positive, Negative, Neutral or Unclassified.

New RSS/social stories and completed transcripts are queued for connected sentiment analysis when their language has a configured service. The queue retries failures, resumes after restarts, and preserves analyst-reviewed/approved stories and edits made while the service is responding. Set `NAMLENS_AUTO_ANALYSIS=0` to disable automatic provider usage.

This connection does not create a language model. You need an actual supported model/service and independently labelled examples from fluent reviewers. Import those in Language quality and measure performance before accepting its output. The current evaluation uses up to 30 examples, reports agreement and confusion counts, and explicitly marks small samples and connection failures. More diverse testing is needed for deployment decisions. The template JSON illustrates syntax only; it is not a real reference dataset.

## Backups, recovery and migration

Daily snapshots retain three copies of the database, encryption key and original evidence in `/data/backups`. They protect against some accidental edits; they are on the same host and do not protect against host/disk loss. Download the app's full backup ZIP to another location regularly. Automatic recordings expire according to each stream's retention; story text and analysis remain.

Local app: preserve the entire `data` folder. For moving this app to a host, enable an owner password locally using the same owner email that you will configure on the host, then download a full backup ZIP and restore it in the hosted Workspace. Hosted restore refuses a backup lacking the configured owner's password account. Pause streams and wait for running collection/transcription before restoring.

The earlier hosted Sites app is a separate system. CSV export/import can transfer its stories, but does not migrate its evidence, accounts or saved briefing snapshots. No automatic migration of that earlier hosted database was performed.

## Owner password recovery

For a local install with the server stopped:

```bash
node hosting/reset-owner.mjs
```

For the Docker app, stop it, then use the same persistent volume and environment:

```bash
docker compose stop app
docker compose run --rm -it app node hosting/reset-owner.mjs
docker compose up -d app
```

This generates a temporary owner password, writes it to a private `owner-recovery.txt` in the data folder, and preserves records. Read that file privately, sign in, change the password in Workspace, then delete the file. In the Docker command, the reset script must be present in the image (included). No reset is available to an unauthenticated web visitor.

## Official sources

- Render pricing: https://render.com/pricing
- Render service pricing snapshot: https://render.com/pricing?trk=article-ssr-frontend-pulse_little-text-block
- Render free limits: https://render.com/docs/free
- Render disks: https://render.com/docs/disks
- Render environment defaults: https://render.com/docs/environment-variables
- DigitalOcean prices: https://www.digitalocean.com/pricing/droplets
- Oracle Always Free limits: https://docs.oracle.com/en-us/iaas/Content/FreeTier/freetier_topic-Always_Free_Resources.htm
- Faster Whisper: https://github.com/SYSTRAN/faster-whisper
- Deepgram language support: https://developers.deepgram.com/docs/models-languages-overview

- Resend send-email API: https://resend.com/docs/api-reference/emails/send-email

## Version 4.2 account migration

This update remains a local app until you deliberately deploy it. A static
file drop alone does not provide its database, accounts or background workers.
Use the existing Node server with persistent storage when preparing hosting.
For an existing workspace, set NAMLENS_ADMIN_EMAIL to its actual owner email
before moving the saved data to the hosted server. Preserve the database,
workspace key and evidence directory, and make a full backup first.
New public registrations are pending until an administrator approves them.
The optional speech worker must stay private and use a connection key. Enable
NAMLENS_OSHIWAMBO_EXPERIMENT=1 only for the documented experimental model;
its news/dialect accuracy is not established. Speech model downloads, memory,
CPU use and service availability must be considered separately from the main app.
