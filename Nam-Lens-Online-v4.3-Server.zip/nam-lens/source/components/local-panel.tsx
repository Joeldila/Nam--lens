import React, { useEffect, useState } from "react";
export default function LocalPanel({
  session,
  notice,
  refresh,
}: {
  session: any;
  notice: (s: string) => void;
  refresh: () => Promise<void>;
}) {
  const [settings, setSettings] = useState<any>(null),
    [busy, setBusy] = useState(false);
  async function load() {
    const r = await fetch("/api/local");
    if (r.ok) setSettings(await r.json());
  }
  useEffect(() => {
    load();
  }, []);
  async function post(url: string, data: any) {
    setBusy(true);
    try {
      const r = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }),
        j = await r.json();
      if (!r.ok) throw Error(j.error);
      await load();
      await refresh();
      notice("Settings saved");
      return true;
    } catch (e: any) {
      notice(e.message);
      return false;
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="two-col section-gap">
      <section className="panel settings-card">
        <h3>Your account</h3>
        <dl>
          <dt>Name</dt>
          <dd>{session?.name}</dd>
          <dt>Email</dt>
          <dd>{session?.email}</dd>
          <dt>Access</dt>
          <dd>{session?.role}</dd>
          <dt>Version</dt>
          <dd>{settings?.version}</dd>
        </dl>
        <a className="button backup-link" href="/guide">
          Open user guide
        </a>
      </section>
      {session?.role === "Admin" && (
        <>
          <section className="panel settings-card">
            <h3>Backup & restore</h3>
            <a className="primary backup-link" href="/api/backup">
              Download full backup
            </a>
            <p className="fine-print">
              Last backup:{" "}
              {settings?.lastBackup
                ? new Date(settings.lastBackup).toLocaleString("en-GB")
                : "No backup saved yet"}
              .
            </p>
            <label className="button">
              Restore a backup
              <input
                aria-label="Restore a backup"
                type="file"
                className="hidden-file"
                accept=".zip"
                disabled={busy}
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (
                    !file ||
                    !window.confirm(
                      "Replace the workspace with this backup? Its existing contents will be kept in a recovery copy.",
                    )
                  )
                    return;
                  setBusy(true);
                  try {
                    const fd = new FormData();
                    fd.append("file", file);
                    const r = await fetch("/api/restore", {
                        method: "POST",
                        body: fd,
                      }),
                      j = await r.json();
                    if (!r.ok) throw Error(j.error);
                    location.assign("/");
                  } catch (e: any) {
                    notice(e.message);
                  } finally {
                    setBusy(false);
                  }
                }}
              />
            </label>
          </section>
          <section className="panel settings-card">
            <h3>Owner password</h3>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const form = e.currentTarget,
                  fd = new FormData(form);
                if (fd.get("password") !== fd.get("confirm")) {
                  notice("Your passwords do not match");
                  return;
                }
                if (
                  await post("/api/local", {
                    action: "password",
                    password: fd.get("password"),
                  })
                )
                  form.reset();
              }}
            >
              <label>
                New password
                <input
                  aria-label="New password"
                  name="password"
                  type="password"
                  required
                  minLength={8}
                  maxLength={200}
                  autoComplete="new-password"
                />
              </label>
              <label>
                Confirm password
                <input
                  aria-label="Confirm password"
                  name="confirm"
                  type="password"
                  required
                  minLength={8}
                  maxLength={200}
                  autoComplete="new-password"
                />
              </label>
              <button className="primary" disabled={busy}>
                Update password
              </button>
            </form>
          </section>
          <section className="panel settings-card">
            <h3>Scheduled news collection</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                post("/api/jobs", {
                  action: "settings",
                  paused: settings?.schedule?.paused || false,
                  intervalMinutes: Number(
                    new FormData(e.currentTarget).get("minutes"),
                  ),
                });
              }}
            >
              <label>
                Check for new stories
                <select
                  aria-label="Check for new stories"
                  name="minutes"
                  key={settings?.schedule?.intervalMinutes}
                  defaultValue={settings?.schedule?.intervalMinutes || 60}
                >
                  {[5, 15, 30, 60, 120, 360].map((n) => (
                    <option key={n} value={n}>
                      Every {n} minutes
                    </option>
                  ))}
                </select>
              </label>
              <button className="primary" disabled={busy}>
                Save interval
              </button>
            </form>
            <button
              className="button"
              disabled={busy}
              onClick={() =>
                post("/api/jobs", {
                  action: "settings",
                  paused: !settings?.schedule?.paused,
                  intervalMinutes: settings?.schedule?.intervalMinutes || 60,
                })
              }
            >
              {settings?.schedule?.paused
                ? "Resume collection"
                : "Pause collection"}
            </button>
          </section>
        </>
      )}
    </div>
  );
}
