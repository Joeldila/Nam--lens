@echo off
cd /d "%~dp0"
node tools\language-engine.mjs
if errorlevel 1 pause
