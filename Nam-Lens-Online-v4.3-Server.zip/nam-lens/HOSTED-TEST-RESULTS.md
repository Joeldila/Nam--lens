# Online preparation checks — Nam Lens 4.3

Checked 15 October 2026 Namibia time. This is an online deployment candidate; no Render service has been created and no live URL has been returned.

Passed:
- Fresh hosted workspace has no fictional story records.
- Owner credentials are required; anonymous workspace access is rejected.
- New registrations cannot self-assign access and wait for owner approval.
- Secure, HttpOnly session cookies are issued in hosted mode.
- Session tokens are stored as hashes, separately from user-facing records.
- Saved online sessions and stories survive restart; logout revokes the saved session.
- Current publisher feed responses were retrieved from The Namibian and NBC Digital News. The import/storage processing saved 12 and 10 stories respectively, and a second import added no duplicates.
- Existing local core account/report/backup checks passed again for this server edition.

The test environment permits proxy-assisted internet requests but does not provide direct public DNS lookup for the application's pinned network client. Therefore hosted processing tests used a **test-only transport adapter reading the freshly retrieved publisher responses**. This does not establish live outbound collection from an actual Render host. The released server retains its original network restrictions; the test adapter and publisher data are excluded from the deliverable.

The original 4.2 browser/layout, migration and optional speech checks are documented in TEST-RESULTS.md. No new claim of indigenous-language accuracy, universal device compatibility, Docker execution or public deployment is made.

The remaining deployment steps are: connect the hosting account, provide a privately stored deployable image (or an authorised source route), approve the hosting charges, deploy, and verify the actual host's news import, registration, persistent storage and source-specific connections.
