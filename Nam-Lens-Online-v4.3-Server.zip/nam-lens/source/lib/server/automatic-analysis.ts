import { createHash } from "node:crypto";
import { allRecords, getRecord, putRecord, insertRecord } from "./store";
import { connectedAnalysis } from "./quality";
import { audit, serviceActor } from "./access";

const modelLanguages = [
  "English",
  "German",
  "Arabic",
  "French",
  "Hindi",
  "Italian",
  "Spanish",
  "Portuguese",
];
let busy = false;
function fingerprint(story: any) {
  return createHash("sha256")
    .update(JSON.stringify([story.title, story.body, story.language]))
    .digest("hex");
}
async function available(language: string) {
  if (process.env.NAMLENS_AUTO_ANALYSIS === "0") return false;
  if (
    process.env.NAMLENS_ANALYSIS_URL &&
    (process.env.NAMLENS_ANALYSIS_LANGUAGES || "")
      .split(",")
      .map((x) => x.trim())
      .includes(language)
  )
    return true;
  return (
    modelLanguages.includes(language) &&
    Boolean(
      (await getRecord("integration-huggingface"))?.enabled &&
      (await getRecord("secret-huggingface")),
    )
  );
}
export async function queueAnalysis(story: any) {
  if (
    story.sample ||
    story.reviewed ||
    story.approval === "Approved" ||
    !story.body?.trim() ||
    !(await available(story.language))
  )
    return;
  const hash = fingerprint(story),
    id = "analysis-" + story.id + "-" + hash;
  if (await getRecord(id)) return;
  await insertRecord({
    id,
    kind: "analysisTask",
    storyId: story.id,
    fingerprint: hash,
    status: "Queued",
    attempts: 0,
    date: new Date().toISOString(),
    nextAttempt: new Date().toISOString(),
  });
}
export async function analysisTick() {
  if (busy || process.env.NAMLENS_AUTO_ANALYSIS === "0") return;
  busy = true;
  try {
    const task = (await allRecords()).find(
      (x) =>
        x.kind === "analysisTask" &&
        ["Queued", "Retry"].includes(x.status) &&
        Date.parse(x.nextAttempt) <= Date.now(),
    );
    if (!task) return;
    const story = await getRecord(task.storyId);
    if (
      !story ||
      story.reviewed ||
      story.approval === "Approved" ||
      fingerprint(story) !== task.fingerprint
    ) {
      await putRecord({
        ...task,
        status: "Skipped",
        detail: "Story removed, changed or reviewed",
      });
      return;
    }
    if (!(await available(story.language))) return;
    await putRecord({ ...task, status: "Processing" });
    try {
      const result = await connectedAnalysis(
        (story.title + " " + story.body).slice(0, 60000),
        story.language,
      );
      // Re-read after the network request: a reviewer may have edited or approved it.
      const latest = await getRecord(task.storyId);
      if (
        !latest ||
        latest.reviewed ||
        latest.approval === "Approved" ||
        fingerprint(latest) !== task.fingerprint
      ) {
        await putRecord({
          ...task,
          status: "Skipped",
          detail: "Story changed while analysis was running",
        });
        return;
      }
      await putRecord({
        ...latest,
        ...result,
        automaticAnalysisAt: new Date().toISOString(),
      });
      await putRecord({
        ...task,
        status: "Completed",
        completedAt: new Date().toISOString(),
        error: "",
      });
      await audit(
        serviceActor,
        "Analyse collected story",
        story.id,
        result.analysisMethod + "; analyst review required",
      );
    } catch (e: any) {
      const attempts = task.attempts + 1;
      await putRecord({
        ...task,
        status: attempts >= 3 ? "Needs attention" : "Retry",
        attempts,
        error: e.message,
        nextAttempt: new Date(Date.now() + attempts * 60000).toISOString(),
      });
    }
  } finally {
    busy = false;
  }
}
export async function recoverAnalysis() {
  for (const task of (await allRecords()).filter(
    (x) => x.kind === "analysisTask" && x.status === "Processing",
  ))
    await putRecord({
      ...task,
      status: "Retry",
      nextAttempt: new Date().toISOString(),
    });
}
